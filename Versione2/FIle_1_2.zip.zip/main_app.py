# main_app.py

import sys
import threading
import cv2
import json
import logging
import time
from datetime import datetime
import numpy as np
import subprocess
import re
import requests
import base64
import simpleaudio as sa
import wave
import os
from io import BytesIO
import speech_recognition as sr

# Import delle costanti e impostazioni di default
from setup_generici.constants import DEFAULT_SETTINGS, WINDOW_WIDTH, WINDOW_HEIGHT, CONFIG_DIALOG_WIDTH, CONFIG_DIALOG_HEIGHT, WIDGET_MIN_HEIGHT, DEFAULT_FONT_SIZE, DEFAULT_PENSIERINI_FONT_SIZE, SETTINGS_FILE, LOG_FILE

# Import del monitoraggio CPU e temperatura
from CPU_Check_Temperature.cpu_monitor import CPUMonitor

# Import del gestore lettura vocale
from TTS_to_READING.text_reader import TextReaderManager

# Import delle funzioni per eventi mouse
from EVENT_MOUSE.mouse_events import (
    handle_draggable_mouse_press,
    handle_draggable_mouse_move,
    show_draggable_context_menu,
    handle_main_window_resize,
    handle_main_window_drag_enter,
    handle_main_window_drop,
    handle_main_window_event_filter
)

# Import del gestore scorciatoie tastiera
from EVENT_KEYBOARD.keyboard_shortcuts import KeyboardShortcutsManager
from PyQt6.QtCore import (
    QThread, pyqtSignal, QTimer, Qt, QMimeData, QPoint, QObject, QSize,
    QPropertyAnimation, QRect, QEvent, QBuffer, QIODevice, QDir
)
from PyQt6.QtGui import QImage, QPixmap, QDrag, QCursor, QIcon, QPainter, QPen, QColor, QFont, QShortcut, QKeySequence
from PyQt6.QtWidgets import (
    QApplication, QMainWindow, QWidget, QVBoxLayout, QSizePolicy,
    QLabel, QPushButton, QHBoxLayout, QComboBox, QLineEdit, QFrame, QGridLayout,
    QDialog, QTextEdit, QTabWidget, QCheckBox, QSlider, QRadioButton,
    QTableWidget, QTableWidgetItem, QMessageBox, QHeaderView, QStackedWidget,
    QScrollArea, QSpacerItem, QGroupBox, QMenu, QColorDialog, QFileDialog,
    QInputDialog, QToolButton
)

# Importazione dei moduli
# Import moduli locali
from Video.visual_background import VideoThread
from AI.ollama_manager import OllamaThread, OllamaModelsThread
from TTS_To_Text.tts_manager import TTSThread, VOCI_DI_SISTEMA
from Audio.speech_recognition_manager import SpeechRecognitionThread

# ==============================================================================
# Inizializzazione e Configurazione Globale
# ==============================================================================

# VOCI_DI_SISTEMA è ora importata da tts_manager.py

# ==============================================================================
# CONFIGURAZIONE GLOBALE
# ==============================================================================

class AppConfig:
    """Classe per la gestione della configurazione dell'applicazione."""

    # Costanti importate da setup_generici/constants.py
    WINDOW_WIDTH = WINDOW_WIDTH
    WINDOW_HEIGHT = WINDOW_HEIGHT
    CONFIG_DIALOG_WIDTH = CONFIG_DIALOG_WIDTH
    CONFIG_DIALOG_HEIGHT = CONFIG_DIALOG_HEIGHT
    WIDGET_MIN_HEIGHT = WIDGET_MIN_HEIGHT
    DEFAULT_FONT_SIZE = DEFAULT_FONT_SIZE
    DEFAULT_PENSIERINI_FONT_SIZE = DEFAULT_PENSIERINI_FONT_SIZE
    SETTINGS_FILE = SETTINGS_FILE
    LOG_FILE = LOG_FILE
    DEFAULT_SETTINGS = DEFAULT_SETTINGS

    @classmethod
    def load_settings(cls):
        """Carica le impostazioni dal file."""
        try:
            if os.path.exists(cls.SETTINGS_FILE):
                with open(cls.SETTINGS_FILE, 'r', encoding='utf-8') as f:
                    return {**cls.DEFAULT_SETTINGS, **json.load(f)}
            return cls.DEFAULT_SETTINGS.copy()
        except Exception as e:
            logging.error(f"Errore nel caricamento delle impostazioni: {e}")
            return cls.DEFAULT_SETTINGS.copy()

    @classmethod
    def save_settings(cls, settings):
        """Salva le impostazioni su file."""
        try:
            with open(cls.SETTINGS_FILE, 'w', encoding='utf-8') as f:
                json.dump(settings, f, indent=4, ensure_ascii=False)
            logging.info("Impostazioni salvate con successo")
        except Exception as e:
            logging.error(f"Errore nel salvataggio delle impostazioni: {e}")

# ==============================================================================
# Classi per la gestione dei Thread asincroni (NON visivi)
# ==============================================================================

class CPUMonitor(QThread):
    """Thread per il monitoraggio dell'utilizzo della CPU e temperatura."""

    cpu_warning = pyqtSignal(str)  # Segnale per avvisi CPU alta
    cpu_critical = pyqtSignal(str)  # Segnale per CPU critica
    temperature_warning = pyqtSignal(str)  # Segnale per avvisi temperatura alta
    temperature_critical = pyqtSignal(str)  # Segnale per temperatura critica

    def __init__(self, settings, parent=None):
        super().__init__(parent)
        self.settings = settings


# ==============================================================================
# Classi per la gestione dei Thread asincroni (NON visivi)
# ==============================================================================

# Le classi SpeechRecognitionThread e TTSThread sono state spostate nei rispettivi moduli

# ==============================================================================
# Componenti UI Custom
# ==============================================================================

class DraggableTextWidget(QFrame):
    def __init__(self, text, settings, parent=None):
        super().__init__(parent)
        self.setFrameShape(QFrame.Shape.StyledPanel)
        self.setFrameShadow(QFrame.Shadow.Raised)
        self.setMinimumHeight(60)
        self.setStyleSheet("""
            QFrame {
                background: rgba(255, 255, 255, 0.7);
                border-radius: 15px;
                margin: 5px;
                color: black;
            }
            QPushButton {
                background-color: rgba(0, 0, 0, 0.2);
                border: 1px solid rgba(0, 0, 0, 0.3);
                border-radius: 12px;
                padding: 5px 10px;
                color: white;
                font-weight: bold;
            }
            QPushButton:hover {
                background-color: rgba(0, 0, 0, 0.3);
            }
            QLabel {
                color: black;
            }
        """)

        self.tts_thread = None
        self.is_reading = False
        self.settings = settings
        self.original_text = text

        layout = QHBoxLayout(self)
        self.text_label = QLabel(text)
        self.text_label.setStyleSheet("font-weight: bold; font-size: 12px;")
        self.text_label.setWordWrap(True)
        self.text_label.setContextMenuPolicy(Qt.ContextMenuPolicy.CustomContextMenu)
        self.text_label.customContextMenuRequested.connect(self.show_context_menu)

        layout.addWidget(self.text_label, 1)

        button_layout = QVBoxLayout()
        self.read_button = QPushButton("🔊")
        self.read_button.setFixedSize(25, 25)
        self.read_button.setToolTip("Leggi testo")
        self.read_button.clicked.connect(self.toggle_read_text)

        self.delete_button = QPushButton("❌")
        self.delete_button.setFixedSize(25, 25)
        self.delete_button.setToolTip("Elimina")
        self.delete_button.clicked.connect(self.delete_self)

        button_layout.addWidget(self.read_button)
        button_layout.addWidget(self.delete_button)
        layout.addLayout(button_layout)

        self.setAcceptDrops(True)
        self.start_pos = None

    def show_context_menu(self, pos):
        """Mostra il menu contestuale per il widget."""
        context_menu = QMenu(self)
        edit_action = context_menu.addAction("Modifica Testo")
        action = context_menu.exec(self.mapToGlobal(pos))
        if action == edit_action:
            new_text, ok = QInputDialog.getMultiLineText(self, "Modifica Testo", "Modifica il contenuto del widget:", self.text_label.text())
            if ok:
                self.text_label.setText(new_text)

    def mousePressEvent(self, event):
        """Gestisce l'evento di pressione del mouse per iniziare il trascinamento."""
        if event.button() == Qt.MouseButton.LeftButton:
            self.start_pos = event.pos()

    def mouseMoveEvent(self, event):
        """Gestisce il movimento del mouse per il trascinamento."""
        if event.buttons() == Qt.MouseButton.LeftButton and self.start_pos:
            distance = (event.pos() - self.start_pos).manhattanLength()
            if distance > QApplication.startDragDistance():
                drag = QDrag(self)
                mime = QMimeData()
                mime.setText(self.text_label.text())
                drag.setMimeData(mime)
                drag.setPixmap(self.grab())
                drag.exec(Qt.DropAction.CopyAction) # Usa CopyAction per duplicare il testo



    def delete_self(self):
        """Rimuove il widget dall'interfaccia."""
        if self.is_reading:
            self.stop_reading()
        self.setParent(None)
        self.deleteLater()




class LogEmitter(QObject):
    """Oggetto QObject per emettere segnali di log."""
    new_record = pyqtSignal(str)
    error_occurred = pyqtSignal()

class TextEditLogger(logging.Handler):
    """Handler di logging personalizzato che emette segnali a un QTextEdit."""
    def __init__(self, log_emitter, parent=None):
        super().__init__()
        self.log_emitter = log_emitter
        self.setFormatter(logging.Formatter('%(asctime)s - %(levelname)s - %(message)s'))

    def emit(self, record):
        msg = self.format(record)
        self.log_emitter.new_record.emit(msg)
        if record.levelno >= logging.ERROR:
            self.log_emitter.error_occurred.emit()

# ==============================================================================
# Dialogo di configurazione
# ==============================================================================

class ConfigurationDialog(QDialog):
    def __init__(self, parent=None, settings=None):
        super().__init__(parent)
        self.setWindowTitle("⚙️ Menu di Configurazione")
        self.setModal(True)
        self.resize(1000, 700) # Resized to be larger
        self.settings = settings or {}

        self.setup_ui()
        self.load_settings()
        self.ollama_models_thread = OllamaModelsThread()
        self.ollama_models_thread.models_list.connect(self.update_ollama_models)
        self.ollama_models_thread.error_occurred.connect(self.on_ollama_models_error)
        self.ollama_models_thread.start()

    def setup_ui(self):
        """Configura l'interfaccia utente del dialogo."""
        layout = QVBoxLayout(self)

        # Tab Widget
        self.tab_widget = QTabWidget()
        self.setup_ai_tab()
        self.setup_ui_tab()
        self.setup_tts_tab()
        self.setup_gestures_tab()
        self.setup_empathy_tab()
        self.setup_library_tab()
        self.setup_data_tab()
        layout.addWidget(self.tab_widget)

        # Pulsanti Applica e Chiudi in basso
        bottom_button_layout = QHBoxLayout()
        bottom_button_layout.addStretch(1)

        apply_btn = QPushButton("Applica ✅")
        apply_btn.setStyleSheet("background-color: #4CAF50; color: white;")
        apply_btn.clicked.connect(self.apply_changes)
        bottom_button_layout.addWidget(apply_btn)

        close_menu_btn = QPushButton("Chiudi ➡️")
        close_menu_btn.clicked.connect(self.reject)
        bottom_button_layout.addWidget(close_menu_btn)

        layout.addLayout(bottom_button_layout)

    def setup_ai_tab(self):
        """Configura il tab per le impostazioni dell'IA."""
        ai_widget = QWidget()
        layout = QVBoxLayout(ai_widget)

        ai_group = QGroupBox("Selezione AI")
        ai_layout = QVBoxLayout(ai_group)
        self.ollama_model_combo = QComboBox()
        self.ollama_model_combo.addItem("Caricamento modelli...")
        ai_layout.addWidget(QLabel("Modello Ollama:"))
        ai_layout.addWidget(self.ollama_model_combo)

        test_ollama_btn = QPushButton("Testa Connessione & Modelli")
        test_ollama_btn.clicked.connect(self.test_ollama_connection)
        ai_layout.addWidget(test_ollama_btn)

        self.ollama_status_label = QLabel("Stato: In attesa di caricamento...")
        self.ollama_status_label.setStyleSheet("color: #4a90e2;")
        ai_layout.addWidget(self.ollama_status_label)
        layout.addWidget(ai_group)

        trigger_group = QGroupBox("Trigger per AI")
        trigger_layout = QVBoxLayout(trigger_group)
        trigger_layout.addWidget(QLabel("Imposta una parola d'ordine per inviare il testo all'AI:"))
        self.ai_trigger_input = QLineEdit("++++")
        trigger_layout.addWidget(self.ai_trigger_input)
        layout.addWidget(trigger_group)

        layout.addStretch()
        self.tab_widget.addTab(ai_widget, "Configurazione AI")

    def setup_ui_tab(self):
        """Configura il tab per le impostazioni dell'UI."""
        ui_widget = QWidget()
        layout = QVBoxLayout(ui_widget)

        button_colors_group = QGroupBox("Colori Pulsanti Principali")
        colors_grid = QGridLayout(button_colors_group)

        self.add_btn_color = QPushButton("Inserisci testo")
        self.add_btn_color.clicked.connect(lambda: self.open_color_dialog(self.add_btn_color))
        colors_grid.addWidget(self.add_btn_color, 0, 0)

        self.ai_btn_color = QPushButton("🧠 AI")
        self.ai_btn_color.clicked.connect(lambda: self.open_color_dialog(self.ai_btn_color))
        colors_grid.addWidget(self.ai_btn_color, 0, 1)

        self.voice_btn_color = QPushButton("🎤 Voce")
        self.voice_btn_color.clicked.connect(lambda: self.open_color_dialog(self.voice_btn_color))
        colors_grid.addWidget(self.voice_btn_color, 0, 2)

        self.hands_btn_color = QPushButton("✋ Mani")
        self.hands_btn_color.clicked.connect(lambda: self.open_color_dialog(self.hands_btn_color))
        colors_grid.addWidget(self.hands_btn_color, 1, 0)

        self.face_btn_color = QPushButton("😊 Faccia")
        self.face_btn_color.clicked.connect(lambda: self.open_color_dialog(self.face_btn_color))
        colors_grid.addWidget(self.face_btn_color, 1, 1)

        self.clean_btn_color = QPushButton("🧹 Pulisci")
        self.clean_btn_color.clicked.connect(lambda: self.open_color_dialog(self.clean_btn_color))
        colors_grid.addWidget(self.clean_btn_color, 2, 0)

        self.options_btn_color = QPushButton("⚙️ Opzioni")
        self.options_btn_color.clicked.connect(lambda: self.open_color_dialog(self.options_btn_color))
        colors_grid.addWidget(self.options_btn_color, 3, 0)

        self.log_btn_color = QPushButton("📊 Log")
        self.log_btn_color.clicked.connect(lambda: self.open_color_dialog(self.log_btn_color))
        colors_grid.addWidget(self.log_btn_color, 3, 1)

        layout.addWidget(button_colors_group)

        layout.addStretch()
        self.tab_widget.addTab(ui_widget, "Comportamento & UI")

    def setup_tts_tab(self):
        """Configura il tab per la sintesi vocale."""
        tts_widget = QWidget()
        layout = QVBoxLayout(tts_widget)

        tts_config_group = QGroupBox("Sintesi Vocale (TTS)")
        tts_config_layout = QVBoxLayout(tts_config_group)

        tts_config_layout.addWidget(QLabel("Qualità Voce:"))
        self.tts_voice_combo = QComboBox()
        voice_names = [voice['name'] for voice in VOCI_DI_SISTEMA]
        self.tts_voice_combo.addItems(voice_names)
        tts_config_layout.addWidget(self.tts_voice_combo)

        advanced_params_group = QGroupBox("Parametri avanzati")
        advanced_params_layout = QGridLayout(advanced_params_group)

        advanced_params_layout.addWidget(QLabel("Velocità (0.5 - 2.0):"), 0, 0)
        self.speed_slider = QSlider(Qt.Orientation.Horizontal)
        self.speed_slider.setRange(50, 200)
        self.speed_slider.setValue(100)
        self.speed_label = QLabel("1.0x")
        self.speed_slider.valueChanged.connect(lambda value: self.speed_label.setText(f"{value/100:.1f}x"))
        advanced_params_layout.addWidget(self.speed_slider, 0, 1)
        advanced_params_layout.addWidget(self.speed_label, 0, 2)

        advanced_params_layout.addWidget(QLabel("Intonazione (0.5 - 2.0):"), 1, 0)
        self.pitch_slider = QSlider(Qt.Orientation.Horizontal)
        self.pitch_slider.setRange(50, 200)
        self.pitch_slider.setValue(100)
        self.pitch_label = QLabel("1.0x")
        self.pitch_slider.valueChanged.connect(lambda value: self.pitch_label.setText(f"{value/100:.1f}x"))
        advanced_params_layout.addWidget(self.pitch_slider, 1, 1)
        advanced_params_layout.addWidget(self.pitch_label, 1, 2)

        tts_config_layout.addWidget(advanced_params_group)

        test_group = QGroupBox("Prova la Sintesi Vocale")
        test_layout = QVBoxLayout(test_group)
        self.tts_test_text = QTextEdit()
        self.tts_test_text.setPlaceholderText("Inserisci qui il testo da testare...")
        self.tts_test_text.setText("Questo è un esempio di sintesi vocale in italiano")
        test_layout.addWidget(self.tts_test_text)

        self.test_tts_button = QPushButton("Prova Sintesi Vocale 🔊")
        self.test_tts_button.clicked.connect(self.test_tts)
        test_layout.addWidget(self.test_tts_button)

        tts_config_layout.addWidget(test_group)
        layout.addWidget(tts_config_group)

        layout.addStretch()
        self.tab_widget.addTab(tts_widget, "Sintesi Vocale")

    def setup_gestures_tab(self):
        """Configura il tab per i gesti e i suoni."""
        gestures_widget = QWidget()
        layout = QVBoxLayout(gestures_widget)

        layout.addWidget(QLabel("Riconoscimento Vocale"))
        layout.addWidget(QLabel("Seleziona la lingua per il microfono:"))
        self.language_combo = QComboBox()
        self.language_combo.addItems(["Italiano", "English", "Français", "Deutsch"])
        layout.addWidget(self.language_combo)

        layout.addWidget(QLabel("Riconoscimento Gesti Mano"))
        layout.addWidget(QLabel("Timeout per la selezione (in ms):"))
        self.timeout_input = QLineEdit("500")
        layout.addWidget(self.timeout_input)

        hand_color_group = QGroupBox("Rilevamento Mani")
        hand_color_layout = QHBoxLayout(hand_color_group)
        self.hand_color_label = QLabel("Colore mano:")
        hand_color_layout.addWidget(self.hand_color_label)
        self.hand_color_picker_btn = QPushButton("Scegli Colore...")
        self.hand_color_picker_btn.clicked.connect(self.choose_hand_color)
        hand_color_layout.addWidget(self.hand_color_picker_btn)
        layout.addWidget(hand_color_group)

        layout.addStretch()
        self.tab_widget.addTab(gestures_widget, "Gesti & Suoni")

    def setup_empathy_tab(self):
        """Configura il tab per le impostazioni di empatia."""
        empathy_widget = QWidget()
        layout = QVBoxLayout(empathy_widget)

        face_recognition_group = QGroupBox("Riconoscimento Facciale (Genitore Empatico)")
        face_layout = QVBoxLayout(face_recognition_group)
        face_layout.addWidget(QLabel("Attiva la funzione d'emergenza \"genitore empatico\":"))
        self.face_recognition_cb = QCheckBox("Abilita")
        face_layout.addWidget(self.face_recognition_cb)

        layout.addWidget(face_recognition_group)
        layout.addStretch()
        self.tab_widget.addTab(empathy_widget, "Genitore Empatico")

    def check_status_of_libraries(self):
        """Verifica se le librerie e i moduli essenziali sono installati e caricabili."""
        status = {}
        # Controlla le librerie di terze parti
        status['ollama'] = self._check_import('requests') and self._check_import('json')
        status['PyQt6'] = self._check_import('PyQt6.QtWidgets')
        status['OpenCV'] = self._check_import('cv2')
        status['SpeechRecognition'] = self._check_import('speech_recognition')
        status['simpleaudio'] = self._check_import('simpleaudio')

        # Controlla i moduli personalizzati
        status['visual_background'] = self._check_import('visual_background')
        status['ollama_manager'] = self._check_import('ollama_manager')
        status['tts_manager'] = self._check_import('tts_manager')
        status['speech_recognition_manager'] = self._check_import('speech_recognition_manager')

        return status

    def _check_import(self, module_name):
        """Funzione helper per controllare se un modulo può essere importato."""
        try:
            __import__(module_name)
            return True
        except ImportError:
            return False

    def setup_library_tab(self):
        """Configura il tab per la gestione delle librerie."""
        library_widget = QWidget()
        layout = QVBoxLayout(library_widget)
        self.library_table = QTableWidget()
        self.library_table.setColumnCount(3)
        self.library_table.setHorizontalHeaderLabels(["Libreria/Modulo", "Stato", "Azione"])
        self.library_table.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.Stretch)
        self.library_table.setSelectionBehavior(QTableWidget.SelectionBehavior.SelectRows)
        self.library_table.setEditTriggers(QTableWidget.EditTrigger.NoEditTriggers)

        libraries_to_check = {
            "Ollama": "ollama", # Ollama è un servizio, ma usiamo la sua API (requests) per la verifica
            "PyQt6": "PyQt6",
            "OpenCV": "cv2",
            "SpeechRecognition": "speech_recognition",
            "simpleaudio": "simpleaudio",
            "visual_background": "visual_background",
            "ollama_manager": "ollama_manager",
            "tts_manager": "tts_manager",
            "speech_recognition_manager": "speech_recognition_manager",
        }

        library_statuses = self.check_status_of_libraries()

        self.library_table.setRowCount(len(libraries_to_check))
        for row, (name, _) in enumerate(libraries_to_check.items()):
            status = library_statuses.get(name.lower().replace(' ', '_'), False) # normalizza il nome per la chiave
            status_text = "Installata ✅" if status else "Non installata ❌"
            status_color = QColor(0, 150, 0) if status else QColor(200, 0, 0)

            name_item = QTableWidgetItem(name)
            self.library_table.setItem(row, 0, name_item)

            status_item = QTableWidgetItem(status_text)
            status_item.setForeground(status_color)
            self.library_table.setItem(row, 1, status_item)

            action_button = QPushButton("Apri Docs")
            action_button.clicked.connect(
                lambda checked, lib=name: self.handle_library_action(lib, "Apri Docs")
            )
            self.library_table.setCellWidget(row, 2, action_button)

        layout.addWidget(self.library_table)
        layout.addStretch()
        self.tab_widget.addTab(library_widget, "Gestione Librerie")

    def setup_data_tab(self):
        """Configura il tab per la gestione dei dati."""
        data_widget = QWidget()
        layout = QVBoxLayout(data_widget)

        data_group = QGroupBox("Gestione Dati e Log")
        data_layout = QVBoxLayout(data_group)

        self.download_logs_btn = QPushButton("Scarica i log emozioni")
        self.download_logs_btn.clicked.connect(self.download_logs)
        data_layout.addWidget(self.download_logs_btn)

        data_layout.addStretch()
        layout.addWidget(data_group)
        layout.addStretch()

        self.tab_widget.addTab(data_widget, "Gestione Dati")

    def update_ollama_models(self, model_names):
        """Aggiorna il QComboBox con i modelli Ollama disponibili."""
        self.ollama_model_combo.clear()
        if model_names:
            self.ollama_model_combo.addItems(model_names)
            self.ollama_status_label.setText("Stato: Connesso")
            self.ollama_status_label.setStyleSheet("color: #4CAF50;")
        else:
            self.ollama_model_combo.addItem("Nessun modello trovato.")
            self.ollama_status_label.setText("Stato: Nessun modello trovato.")
            self.ollama_status_label.setStyleSheet("color: orange;")

    def on_ollama_models_error(self, message):
        """Gestisce gli errori durante il recupero dei modelli Ollama."""
        self.ollama_model_combo.clear()
        self.ollama_model_combo.addItem("Errore di caricamento")
        self.ollama_status_label.setText(f"Stato: {message}")
        self.ollama_status_label.setStyleSheet("color: red;")
        QMessageBox.warning(self, "Errore Ollama", message)

    def load_settings(self):
        """Carica le impostazioni attuali dal file settings.json."""
        if os.path.exists("setup_generici/settings.json"):
            try:
                with open("setup_generici/settings.json", "r") as f:
                    self.settings = json.load(f)
                self.update_ui_from_settings()
            except Exception as e:
                logging.error(f"Errore nel caricare le impostazioni: {e}")
                self.settings = {}

    def update_ui_from_settings(self):
        """Aggiorna i widget del dialogo con le impostazioni caricate."""
        self.ollama_model_combo.setCurrentText(self.settings.get('ollama_model', 'gemma:2b'))
        default_voice = self.settings.get('tts_voice', 'it-IT')
        if default_voice == 'Zephyr':
            default_voice = 'it-IT'
        self.tts_voice_combo.setCurrentText(default_voice)
        self.face_recognition_cb.setChecked(self.settings.get('face_recognition', False))
        self.timeout_input.setText(str(self.settings.get('timeout', 500)))

        lang_code = self.settings.get('language', 'it-IT')
        lang_map = {'it-IT': 'Italiano', 'en-US': 'English', 'fr-FR': 'Français', 'de-DE': 'Deutsch'}
        if lang_code in lang_map:
            self.language_combo.setCurrentText(lang_map[lang_code])

        self.add_btn_color.setStyleSheet(f"background-color: {self.settings.get('add_btn_color', '#4a90e2')};")
        self.ai_btn_color.setStyleSheet(f"background-color: {self.settings.get('ai_btn_color', '#4a90e2')};")
        self.hands_btn_color.setStyleSheet(f"background-color: {self.settings.get('hands_btn_color', '#4a90e2')};")
        self.face_btn_color.setStyleSheet(f"background-color: {self.settings.get('face_btn_color', '#4a90e2')};")
        self.clean_btn_color.setStyleSheet(f"background-color: {self.settings.get('clean_btn_color', '#4a90e2')};")
        self.options_btn_color.setStyleSheet(f"background-color: {self.settings.get('options_btn_color', '#4a90e2')};")
        self.log_btn_color.setStyleSheet(f"background-color: {self.settings.get('log_btn_color', '#4a90e2')};")
        self.voice_btn_color.setStyleSheet(f"background-color: {self.settings.get('voice_btn_color', '#4a90e2')};")

    def _get_button_color(self, button, default_color):
        """
        Estrae il colore di sfondo da un QPushButton in modo sicuro.
        Se non trova il colore, restituisce il valore di default.
        """
        style_sheet = button.styleSheet()
        match = re.search(r'background-color: (.+?);', style_sheet)
        if match:
            return match.group(1).strip()
        return default_color

    def get_settings(self):
        """Restituisce le impostazioni correnti dai widget in modo robusto."""
        lang_map = {'Italiano': 'it-IT', 'English': 'en-US', 'Français': 'fr-FR', 'Deutsch': 'de-DE'}

        settings = {
            'ollama_model': self.ollama_model_combo.currentText(),
            'tts_voice': self.tts_voice_combo.currentText(),
            'face_recognition': self.face_recognition_cb.isChecked(),
            'timeout': int(self.timeout_input.text()),
            'language': lang_map.get(self.language_combo.currentText(), 'it-IT'),

            'add_btn_color': self._get_button_color(self.add_btn_color, '#4a90e2'),
            'ai_btn_color': self._get_button_color(self.ai_btn_color, '#4a90e2'),
            'hands_btn_color': self._get_button_color(self.hands_btn_color, '#4a90e2'),
            'face_btn_color': self._get_button_color(self.face_btn_color, '#4a90e2'),
            'clean_btn_color': self._get_button_color(self.clean_btn_color, '#4a90e2'),
            'options_btn_color': self._get_button_color(self.options_btn_color, '#4a90e2'),
            'log_btn_color': self._get_button_color(self.log_btn_color, '#4a90e2'),
            'voice_btn_color': self._get_button_color(self.voice_btn_color, '#4a90e2'),
        }
        return settings

    def apply_changes(self):
        """Applica le modifiche del dialogo e le salva nel file."""
        self.settings = self.get_settings()
        try:
            AppConfig.save_settings(self.settings)
            QMessageBox.information(
                self,
                "Impostazioni Applicate",
                "Le modifiche sono state applicate con successo."
            )
        except Exception as e:
            QMessageBox.critical(
                self,
                "Errore di salvataggio",
                f"Si è verificato un errore durante il salvataggio delle impostazioni:\n{e}"
            )
        if hasattr(self.parent(), 'apply_settings'):
            self.parent().apply_settings(self.settings)
        self.accept()

    def test_tts(self):
        """Prova la sintesi vocale con i parametri correnti."""
        text = self.tts_test_text.toPlainText()
        if not text:
            QMessageBox.warning(self, "Attenzione", "Inserisci del testo per la prova.")
            return

        voice = self.tts_voice_combo.currentText()
        speed = self.speed_slider.value() / 100
        pitch = self.pitch_slider.value() / 100

        tts_thread = TTSThread(text, engine_name='pyttsx3', voice_or_lang=voice, speed=speed, pitch=pitch)
        tts_thread.start()

    def test_ollama_connection(self):
        """Testa la connessione a Ollama."""
        QMessageBox.information(
            self,
            "Test Connessione Ollama",
            "Funzionalità di test da implementare."
        )

    def download_logs(self):
        """Scarica i log su un file di testo."""
        file_path, _ = QFileDialog.getSaveFileName(
            self,
            "Scarica Log",
            os.path.join(os.getcwd(), "saved_data", "log_emozioni.txt"),
            "File di testo (*.txt);;Tutti i file (*)"
        )

        if file_path:
            try:
                # Per ora, non abbiamo un log persistente, quindi salviamo un placeholder.
                # In una versione più avanzata, leggeremmo da un file di log effettivo.
                with open(file_path, 'w', encoding='utf-8') as f:
                    f.write("Log temporaneo salvato. Implementare un sistema di log persistente per una funzionalità completa.")
                QMessageBox.information(
                    self,
                    "Salvataggio Log",
                    f"I log sono stati salvati correttamente in:\n{file_path}"
                )
            except Exception as e:
                QMessageBox.critical(
                    self,
                    "Errore di salvataggio",
                    f"Si è verificato un errore durante il salvataggio dei log:\n{e}"
                )

    def open_color_dialog(self, button):
        """Apre un selettore di colori per i pulsanti."""
        color = QColorDialog.getColor()
        if color.isValid():
            button.setStyleSheet(f"background-color: {color.name()};")

    def choose_hand_color(self):
        """Sceglie il colore della mano per il rilevamento."""
        QMessageBox.information(
            self,
            "Selettore Colore Mano",
            "Funzionalità da implementare per la calibrazione del colore."
        )

    def handle_library_action(self, library, action):
        """Gestisce le azioni per le librerie."""
        QMessageBox.information(
            self,
            f"Azione Libreria",
            f"Azione '{action}' richiesta per la libreria '{library}'."
        )

# ==============================================================================
# Classe Principale dell'Applicazione
# ==============================================================================

class MainWindow(QMainWindow):
    """
    La classe principale dell'applicazione, che gestisce l'interfaccia utente.
    """
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Assistente per Dislessia")
        self.setGeometry(100, 100, 1400, 800)
        self.settings = {}
        self.ollama_thread = None

        # Variabili per tracciare il contenuto corrente nella colonna C
        self.current_media_widget = None
        self.current_media_path = None
        self.current_media_type = None

        # Configurazione logging migliorata
        logging.basicConfig(
            level=logging.INFO,
            format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
            handlers=[
                logging.FileHandler(AppConfig.LOG_FILE),
                logging.StreamHandler()
            ]
        )
        self.logger = logging.getLogger(__name__)

        # Carica le impostazioni all'avvio
        self.load_settings()

        # Inizializza il sistema di rilevamento
        self.initialize_detection_system()

        # Inizializza il monitoraggio CPU
        self.initialize_cpu_monitor()

        # Applica il tema al caricamento (un solo tema ora)
        self.setStyleSheet(self.load_theme())

        # Widget per lo sfondo video
        self.video_background_label = QLabel(self)
        self.video_background_label.setGeometry(self.rect())
        self.video_background_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.video_background_label.setStyleSheet("background-color: black;")

        self.central_widget = QWidget(self)
        self.central_widget.setStyleSheet("background-color: rgba(0, 0, 0, 0);")
        self.setCentralWidget(self.central_widget)

        self.main_layout = QVBoxLayout(self.central_widget)

        # Sezione in alto: Opzioni e Salva su file
        self.top_buttons_layout = QHBoxLayout()
        self.btn_options = QPushButton("⚙️ Opzioni")
        self.top_buttons_layout.addWidget(self.btn_options)
        self.top_buttons_layout.addStretch(1)
        self.btn_save_file = QPushButton("💾 Salva su file")
        self.top_buttons_layout.addWidget(self.btn_save_file)
        self.main_layout.addLayout(self.top_buttons_layout)

        # Sezione centrale: Le 3 colonne
        self.center_layout = QHBoxLayout()

        # Colonna A: Contenuti pensieri creativi (era Pensierini)
        self.pensierini_frame = QFrame()
        self.pensierini_frame.setFrameShape(QFrame.Shape.StyledPanel)
        self.pensierini_frame.setFrameShadow(QFrame.Shadow.Raised)
        self.pensierini_frame.setStyleSheet("background-color: rgba(255, 255, 255, 0.5); border-radius: 15px;")
        self.pensierini_layout = QVBoxLayout(self.pensierini_frame)
        pensierini_label = QLabel("📝 Contenuti pensieri creativi (A)")
        pensierini_label.setStyleSheet("font-weight: bold; font-size: 16px; color: black; background: transparent;")
        self.draggable_widgets_scroll = QScrollArea()
        self.draggable_widgets_scroll.setWidgetResizable(True)
        self.draggable_widgets_content = QWidget()
        self.draggable_widgets_layout = QVBoxLayout(self.draggable_widgets_content)
        self.draggable_widgets_layout.setAlignment(Qt.AlignmentFlag.AlignTop)
        self.draggable_widgets_scroll.setWidget(self.draggable_widgets_content)
        self.pensierini_layout.addWidget(pensierini_label)
        self.pensierini_layout.addWidget(self.draggable_widgets_scroll)
        self.center_layout.addWidget(self.pensierini_frame, 1)

        # Colonna B: Area di Lavoro (centrale)
        self.work_area_main_frame = QFrame()
        self.work_area_main_frame.setFrameShape(QFrame.Shape.StyledPanel)
        self.work_area_main_frame.setFrameShadow(QFrame.Shadow.Raised)
        self.work_area_main_frame.setStyleSheet("background-color: rgba(255, 255, 255, 0.7); border-radius: 15px;")
        self.work_area_main_layout = QVBoxLayout(self.work_area_main_frame)
        work_area_main_label = QLabel("🎯 Area di Lavoro (B)")
        work_area_main_label.setStyleSheet("font-weight: bold; font-size: 16px; color: black; background: transparent;")

        # Scroll area per la colonna B (stesso layout della colonna A)
        self.work_area_main_scroll = QScrollArea()
        self.work_area_main_scroll.setWidgetResizable(True)
        self.work_area_main_scroll.setAcceptDrops(True)
        self.work_area_main_scroll.setStyleSheet("""
            QScrollArea {
                background-color: transparent;
                border: none;
            }
        """)

        # Widget contenitore per gli elementi trascinabili nella colonna B
        self.work_area_main_content = QWidget()
        self.work_area_main_content.setAcceptDrops(True)
        self.work_area_main_layout_b = QVBoxLayout(self.work_area_main_content)
        self.work_area_main_layout_b.setAlignment(Qt.AlignmentFlag.AlignTop)
        self.work_area_main_layout_b.setSpacing(10)

        # Aggiungi un widget di testo iniziale come placeholder
        self.work_area_main_text_widget = DraggableTextWidget("Trascina qui i 'pensierini' per elaborare il testo...", self.settings)
        self.work_area_main_text_widget.setStyleSheet("""
            QFrame {
                background-color: rgba(255, 255, 255, 0.8);
                border: 2px dashed #4a90e2;
                border-radius: 10px;
                margin: 5px;
                color: #666;
                font-style: italic;
            }
        """)
        self.work_area_main_layout_b.addWidget(self.work_area_main_text_widget)

        self.work_area_main_scroll.setWidget(self.work_area_main_content)

        # Installa event filter per gestire il drag and drop
        self.work_area_main_scroll.installEventFilter(self)
        self.work_area_main_content.installEventFilter(self)

        self.work_area_main_layout.addWidget(work_area_main_label)
        self.work_area_main_layout.addWidget(self.work_area_main_scroll)
        self.center_layout.addWidget(self.work_area_main_frame, 2)

        # Colonna C: Dettagli (era Colonna 1)
        self.work_area_left_frame = QFrame()
        self.work_area_left_frame.setFrameShape(QFrame.Shape.StyledPanel)
        self.work_area_left_frame.setFrameShadow(QFrame.Shadow.Raised)
        self.work_area_left_frame.setStyleSheet("background-color: rgba(255, 255, 255, 0.7); border-radius: 15px;")
        self.work_area_left_layout = QVBoxLayout(self.work_area_left_frame)
        work_area_left_label = QLabel("📋 Dettagli (C)")
        work_area_left_label.setStyleSheet("font-weight: bold; font-size: 16px; color: black; background: transparent;")
        self.work_area_left_text_edit = QTextEdit()
        self.work_area_left_text_edit.setPlaceholderText("Inizia a scrivere o a registrare qui...")
        self.work_area_left_text_edit.setStyleSheet("background-color: transparent; border: none;")
        self.work_area_left_layout.addWidget(work_area_left_label)
        self.work_area_left_layout.addWidget(self.work_area_left_text_edit)
        self.center_layout.addWidget(self.work_area_left_frame, 1)

        self.main_layout.addLayout(self.center_layout, 1)

        # Sezione in basso: Pulsanti di controllo e log
        self.bottom_container_layout = QVBoxLayout()

        # Layout per i pulsanti di controllo
        self.bottom_buttons_layout = QHBoxLayout()
        self.btn_add_widget = QPushButton("Inserisci testo")
        self.btn_add_media = QPushButton("📎 Aggiungi Media")
        self.btn_voice = QPushButton("🎤 Voce") # New voice button
        self.btn_ai = QPushButton("🧠 AI")
        self.btn_hands = QPushButton("✋ Mani ❌")
        self.btn_face = QPushButton("😊 Faccia ❌")
        self.btn_clean = QPushButton("🧹 Pulisci")

        self.bottom_buttons_layout.addWidget(self.btn_add_widget)
        self.bottom_buttons_layout.addWidget(self.btn_add_media)
        self.bottom_buttons_layout.addWidget(self.btn_voice) # Add new button here
        self.bottom_buttons_layout.addWidget(self.btn_ai)
        self.bottom_buttons_layout.addWidget(self.btn_hands)
        self.bottom_buttons_layout.addWidget(self.btn_face)
        self.bottom_buttons_layout.addWidget(self.btn_clean)
        self.bottom_buttons_layout.addStretch(1)

        self.bottom_container_layout.addLayout(self.bottom_buttons_layout)

        # Layout per l'input di testo e il log terminale
        self.input_log_layout = QHBoxLayout()

        # Input per i "pensierini"
        self.input_field = QLineEdit()
        self.input_field.setPlaceholderText("Scrivi un nuovo 'pensierino' e premi Invio...")
        self.input_field.returnPressed.connect(self.add_text_to_pensierini)
        self.input_log_layout.addWidget(self.input_field, 1)

        # Pulsante per il log
        self.log_button_layout = QVBoxLayout()
        self.btn_log = QPushButton("📊 Mostra Log")
        self.btn_log.setCheckable(True)
        self.btn_log.setEnabled(True) # Always enabled now
        self.btn_log.clicked.connect(self.toggle_log_visibility)
        self.log_button_layout.addWidget(self.btn_log)
        self.input_log_layout.addLayout(self.log_button_layout)

        self.bottom_container_layout.addLayout(self.input_log_layout)

        self.log_text_edit = QTextEdit()
        self.log_text_edit.setReadOnly(True)
        self.log_text_edit.setStyleSheet("background-color: #2e2e2e; color: #ffffff; font-family: monospace;")
        self.log_text_edit.setMinimumHeight(150)
        self.log_text_edit.hide() # Nascosto di default
        self.bottom_container_layout.addWidget(self.log_text_edit)

        self.main_layout.addLayout(self.bottom_container_layout)

        self.log_emitter = LogEmitter()
        self.log_emitter.new_record.connect(self.log_text_edit.append)
        self.log_emitter.error_occurred.connect(self.on_log_error)
        self.handler = TextEditLogger(self.log_emitter)
        logging.getLogger().addHandler(self.handler)

        # Connessione dei segnali
        self.btn_options.clicked.connect(self.open_settings)
        self.btn_add_media.clicked.connect(self.handle_add_media_button)
        self.btn_ai.clicked.connect(self.handle_ai_button)
        self.btn_voice.clicked.connect(self.handle_voice_button) # Connect the new button
        self.btn_hands.clicked.connect(self.handle_hands_button)
        self.btn_face.clicked.connect(self.handle_face_button)
        self.btn_clean.clicked.connect(self.handle_clean_button)
        self.btn_save_file.clicked.connect(self.save_to_file)
        self.btn_add_widget.clicked.connect(self.add_text_from_input_field) # Use a new method

        # Implementazione dei tasti rapidi
        self.shortcut_save = QShortcut(QKeySequence("Ctrl+S"), self)
        self.shortcut_save.activated.connect(self.save_to_file)

        self.shortcut_open = QShortcut(QKeySequence("Ctrl+O"), self)
        self.shortcut_open.activated.connect(self.open_file)

        self.shortcut_log = QShortcut(QKeySequence(Qt.Key.Key_F12), self)
        self.shortcut_log.activated.connect(self.toggle_log_visibility)

        # Thread per il video
        self.video_thread = VideoThread()
        self.video_thread.change_pixmap_signal.connect(self.update_video_frame)
        self.video_thread.status_signal.connect(self.update_video_status)
        self.video_thread.start()

        # Thread per il riconoscimento vocale
        self.speech_rec_thread = None

        # Applica le impostazioni iniziali ai thread
        self.apply_settings(self.settings)

        # Log di avvio completato
        self.logger.info("Applicazione DSA avviata con successo")
        self.logger.info(f"Versione configurazione: {len(AppConfig.DEFAULT_SETTINGS)} impostazioni disponibili")

    def safe_call(self, obj, method_name, *args, **kwargs):
        """Chiama un metodo in modo sicuro."""
        if obj is None:
            return None
        try:
            method = getattr(obj, method_name, None)
            if method and callable(method):
                return method(*args, **kwargs)
        except Exception as e:
            logging.error(f"Errore nella chiamata sicura di {method_name}: {e}")
        return None

    def resizeEvent(self, event):
        """Re-implementa resizeEvent per ridimensionare lo sfondo video."""
        self.video_background_label.setGeometry(self.rect())
        super().resizeEvent(event)

    def dragEnterEvent(self, event):
        """Permette il drop se i dati sono di tipo testo."""
        if event.mimeData().hasText():
            event.acceptProposedAction()

    def dropEvent(self, event):
        """Gestisce il drop del testo nell'area di lavoro principale."""
        if event.mimeData().hasText():
            text_to_append = event.mimeData().text()
            # Crea un nuovo widget trascinabile nella colonna B
            new_widget = DraggableTextWidget(text_to_append, self.settings)
            self.work_area_main_layout_b.addWidget(new_widget)
            event.acceptProposedAction()

    def eventFilter(self, obj, event):
        """Gestisce gli eventi di drag and drop per la colonna B."""
        if obj == self.work_area_main_scroll or obj == self.work_area_main_content:
            if event.type() == QEvent.Type.DragEnter:
                if event.mimeData().hasText():
                    # Mostra il bordo tratteggiato durante il trascinamento
                    self.work_area_main_scroll.setStyleSheet("""
                        QScrollArea {
                            background-color: transparent;
                            border: 3px dashed #4CAF50;
                            border-radius: 15px;
                        }
                    """)
                    event.acceptProposedAction()
                    return True
            elif event.type() == QEvent.Type.Drop:
                if event.mimeData().hasText():
                    text_to_append = event.mimeData().text()
                    # Crea un nuovo widget trascinabile nella colonna B
                    new_widget = DraggableTextWidget(text_to_append, self.settings)
                    self.work_area_main_layout_b.addWidget(new_widget)

                    # Ripristina il bordo normale dopo il drop
                    self.work_area_main_scroll.setStyleSheet("""
                        QScrollArea {
                            background-color: transparent;
                            border: none;
                        }
                    """)
                    event.acceptProposedAction()
                    return True
            elif event.type() == QEvent.Type.DragLeave:
                # Ripristina il bordo normale quando il trascinamento lascia l'area
                self.work_area_main_scroll.setStyleSheet("""
                    QScrollArea {
                        background-color: transparent;
                        border: none;
                    }
                """)
                return True

        return super().eventFilter(obj, event)



    def load_settings(self):
        """Carica le impostazioni all'avvio dell'applicazione."""
        try:
            self.settings = AppConfig.load_settings()
            self.logger.info("Impostazioni caricate con successo")
        except Exception as e:
            self.logger.error(f"Errore nel caricare le impostazioni: {e}")
            self.settings = AppConfig.DEFAULT_SETTINGS.copy()

    def apply_settings(self, settings):
        """Applica le impostazioni caricate ai thread e all'UI."""
        self.settings = settings

        # Applica impostazioni al video thread
        self.video_thread.face_detection_enabled = self.settings.get('face_recognition', False)
        self.video_thread.hand_detection_enabled = self.settings.get('hand_recognition', False)

        # Applica impostazioni ai pulsanti
        self.btn_add_widget.setStyleSheet(f"background-color: {self.settings.get('add_btn_color', '#4a90e2')}; color: white;")
        self.btn_ai.setStyleSheet(f"background-color: {self.settings.get('ai_btn_color', '#4a90e2')}; color: white;")
        self.btn_voice.setStyleSheet(f"background-color: {self.settings.get('voice_btn_color', '#4a90e2')}; color: white;")
        self.btn_hands.setStyleSheet(f"background-color: {self.settings.get('hands_btn_color', '#4a90e2')}; color: white;")
        self.btn_face.setStyleSheet(f"background-color: {self.settings.get('face_btn_color', '#4a90e2')}; color: white;")
        self.btn_clean.setStyleSheet(f"background-color: {self.settings.get('clean_btn_color', '#4a90e2')}; color: white;")
        self.btn_options.setStyleSheet(f"background-color: {self.settings.get('options_btn_color', '#4a90e2')}; color: white;")
        self.btn_log.setStyleSheet(f"background-color: {self.settings.get('log_btn_color', '#4a90e2')}; color: white;")

        # Aggiorna lo stato visivo dei pulsanti di toggle
        self.update_button_state(self.btn_hands, self.video_thread.hand_detection_enabled, "Mani")
        self.update_button_state(self.btn_face, self.video_thread.face_detection_enabled, "Faccia")

        logging.info("Impostazioni aggiornate e applicate.")

    def load_theme(self):
        """Carica un tema CSS da un file (un solo tema ora)."""
        return """
            QMainWindow {
                background-color: #f0f0f0;
            }
            QPushButton {
                border-radius: 10px;
                padding: 10px;
                font-weight: bold;
            }
            QPushButton:hover {
                background-color: #5a9df7;
            }
            QPushButton[checkable=true][checked=false] {
                background-color: #95a5a6;
            }
            QTextEdit, QLineEdit {
                border-radius: 15px;
                padding: 10px;
                background-color: white;
                font-size: 14px;
            }
            QFrame {
                border: none;
            }
        """

    def update_button_state(self, button, is_enabled, name):
        """Aggiorna lo stato visivo di un pulsante di toggle."""
        icon_status = "✅" if is_enabled else "❌"
        button.setText(f"{button.text().split()[0]} {name} {icon_status}")
        if is_enabled:
            button.setStyleSheet("background-color: #4CAF50; color: white;")
        else:
            color_name = f'{name.lower().split()[0]}_btn_color'
            button.setStyleSheet(f"background-color: {self.settings.get(color_name, '#4a90e2')}; color: white;")

    def open_settings(self):
        """Apre il dialogo di configurazione."""
        dialog = ConfigurationDialog(self, settings=self.settings)
        dialog.exec()

    def on_log_error(self):
        """Gestisce un errore di logging per mostrare il log terminale."""
        if not self.log_text_edit.isVisible():
            self.toggle_log_visibility()

    def add_text_from_input_field(self):
        """
        Aggiunge un nuovo "pensierino" all'area usando il testo dal campo di input.
        """
        text = self.input_field.text().strip()
        if text:
            new_widget = DraggableTextWidget(text, self.settings)
            self.draggable_widgets_layout.addWidget(new_widget)
            self.input_field.clear()

    def add_text_to_pensierini(self):
        """
        Aggiunge il testo dal campo di input alla colonna dei pensierini.
        """
        text = self.input_field.text().strip()
        if text:
            new_widget = DraggableTextWidget(text, self.settings)
            self.draggable_widgets_layout.addWidget(new_widget)
            self.input_field.clear()

    def update_video_frame(self, image):
        """Aggiorna il frame del video con l'immagine passata."""
        if isinstance(image, QPixmap):
            pixmap = image
        else:
            pixmap = QPixmap.fromImage(image)
        scaled_pixmap = pixmap.scaled(
            self.video_background_label.size(), Qt.AspectRatioMode.KeepAspectRatioByExpanding, Qt.TransformationMode.SmoothTransformation
        )
        self.video_background_label.setPixmap(scaled_pixmap)

    def update_video_status(self, message):
        """Aggiorna lo stato del video."""
        self.video_background_label.setText(message)

    def save_to_file(self):
        """
        Salva il contenuto dell'area di lavoro (B) e dei "pensierini" (A)
        in un file .txt dopo aver chiesto all'utente il percorso.
        """
        # Contenuto della Colonna B (Area di Lavoro) - ora da widget trascinabili
        work_area_texts = []
        for i in range(self.work_area_main_layout_b.count()):
            item = self.work_area_main_layout_b.itemAt(i)
            if item and item.widget() and hasattr(item.widget(), 'text_label'):
                work_area_texts.append(item.widget().text_label.text())
        work_area_text_combined = "\n\n".join(work_area_texts)

        # Contenuto della Colonna A (Contenuti pensieri creativi)
        pensierini_texts = []
        for i in range(self.draggable_widgets_layout.count()):
            item = self.draggable_widgets_layout.itemAt(i)
            if item and item.widget() and hasattr(item.widget(), 'text_label'):
                pensierini_texts.append(item.widget().text_label.text())
        pensierini_text_combined = "\n".join(pensierini_texts)

        combined_text = (
            "Contenuti pensieri creativi (A):\n"
            "------------------------------------\n"
            f"{pensierini_text_combined}\n\n"
            "Area di Lavoro (B):\n"
            "------------------------------------\n"
            f"{work_area_text_combined}"
        )

        file_path, _ = QFileDialog.getSaveFileName(
            self,
            "Salva i contenuti",
            os.path.join(os.getcwd(), "saved_data", "contenuti_salvati.txt"),
            "File di testo (*.txt);;Tutti i file (*)"
        )

        if file_path:
            try:
                with open(file_path, 'w', encoding='utf-8') as f:
                    f.write(combined_text)

                QMessageBox.information(
                    self,
                    "Salvataggio completato",
                    f"I contenuti sono stati salvati correttamente in:\n{file_path}"
                )
            except Exception as e:
                QMessageBox.critical(
                    self,
                    "Errore di salvataggio",
                    f"Si è verificato un errore durante il salvataggio del file:\n{e}"
                )

    def open_file(self):
        """Apre un file di testo e carica il suo contenuto nell'area di lavoro principale."""
        file_path, _ = QFileDialog.getOpenFileName(
            self,
            "Apri un file",
            os.getcwd(),
            "File di testo (*.txt);;Tutti i file (*)"
        )
        if file_path:
            try:
                with open(file_path, 'r', encoding='utf-8') as f:
                    content = f.read()
                    # Rimuovi il widget placeholder e aggiungi il contenuto come nuovo widget
                    if self.work_area_main_layout_b.count() > 0:
                        # Rimuovi il primo widget (placeholder)
                        first_item = self.work_area_main_layout_b.itemAt(0)
                        if first_item and first_item.widget():
                            first_item.widget().deleteLater()

                    # Aggiungi il contenuto come nuovo widget trascinabile
                    content_widget = DraggableTextWidget(content, self.settings)
                    self.work_area_main_layout_b.insertWidget(0, content_widget)

                QMessageBox.information(
                    self,
                    "File Aperto",
                    f"Contenuto del file caricato nell'area di lavoro."
                )
            except Exception as e:
                QMessageBox.critical(
                    self,
                    "Errore di apertura",
                    f"Si è verificato un errore durante l'apertura del file:\n{e}"
                )

    def toggle_log_visibility(self):
        """Mostra o nasconde il log terminale."""
        is_visible = self.log_text_edit.isVisible()
        self.log_text_edit.setVisible(not is_visible)
        self.btn_log.setText("📊 Nascondi Log" if not is_visible else "📊 Mostra Log")

    def handle_ai_button(self):
        """
        Gestisce il click del pulsante AI. Prende il testo dal pensierino corrente
        o dall'area di lavoro, lo invia a Ollama e gestisce la risposta.
        """
        # Prima prova a prendere il testo dal pensierino corrente (se disponibile)
        prompt = ""
        if hasattr(self, 'input_field') and self.input_field.text().strip():
            # Se c'è testo nel campo input, usalo
            prompt = self.input_field.text().strip()
        elif hasattr(self, 'work_area_left_text_edit'):
            # Altrimenti prendi dall'area di lavoro
            prompt = self.work_area_left_text_edit.toPlainText().strip()
        else:
            # Prendi il testo dai widget trascinabili nella colonna B
            work_area_texts = []
            for i in range(self.work_area_main_layout_b.count()):
                item = self.work_area_main_layout_b.itemAt(i)
                if item and item.widget() and hasattr(item.widget(), 'text_label'):
                    work_area_texts.append(item.widget().text_label.text())
            prompt = "\n\n".join(work_area_texts).strip()

        if not prompt:
            QMessageBox.warning(self, "Attenzione", "Nessun testo trovato. Scrivi un pensierino o inserisci del testo nell'area di lavoro prima di usare l'AI.")
            return

        self.btn_ai.setEnabled(False)
        original_text = self.btn_ai.text()
        self.btn_ai.setText("🧠 AI (In Caricamento...)")

        # Ottieni il modello selezionato dalla lista AI (salvato nelle impostazioni)
        selected_model = self.settings.get('ollama_model', 'gemma:2b')

        # Se il modello salvato non è disponibile, usa un modello più piccolo che richiede meno memoria
        if selected_model not in ['llava:7b', 'llama2:7b', 'codellama:7b', 'mistral:7b', 'phi:3b', 'gemma:2b', 'tinyllama:latest', 'qwen2.5-coder:3b', 'codegemma:2b']:
            selected_model = 'gemma:2b'  # Fallback sicuro con meno memoria

        # Salva la scelta AI per la prossima volta
        self.settings['selected_ai_model'] = selected_model
        AppConfig.save_settings(self.settings)

        self.logger.info(f"Invio richiesta AI con modello: {selected_model}")
        self.ollama_thread = OllamaThread(prompt, model=selected_model)
        self.ollama_thread.ollama_response.connect(self.on_ollama_response)
        self.ollama_thread.ollama_error.connect(self.on_ollama_error)
        self.ollama_thread.finished.connect(lambda: self.on_ollama_finished(original_text))
        self.ollama_thread.start()

    def on_ollama_response(self, response):
        """Gestisce la risposta di Ollama."""
        # Aggiunge un "pensierino" con i primi 20 caratteri della risposta
        summary_text = response[:20] + "..." if len(response) > 20 else response
        new_widget = DraggableTextWidget(summary_text, self.settings)
        self.draggable_widgets_layout.addWidget(new_widget)

        # Aggiunge la risposta completa all'area di lavoro principale (colonna B)
        ai_response_widget = DraggableTextWidget(f"--- Risposta AI ---\n{response}", self.settings)
        self.work_area_main_layout_b.addWidget(ai_response_widget)

    def on_ollama_error(self, message):
        """Gestisce gli errori della richiesta a Ollama."""
        QMessageBox.critical(self, "Errore AI", message)
        logging.error(f"Errore Ollama: {message}")

    def on_ollama_finished(self, original_text):
        """Riabilita il pulsante e ripristina il testo originale quando il thread finisce."""
        self.btn_ai.setEnabled(True)
        self.btn_ai.setText(original_text)

    def handle_voice_button(self):
        """Avvia il riconoscimento vocale quando si clicca il pulsante voce."""
        self.btn_voice.setEnabled(False)
        self.btn_voice.setText("🎤 In ascolto...")

        # Utilizza il modello Vosk selezionato invece del lang_code
        vosk_model = self.settings.get('vosk_model', 'vosk-model-it-0.22')

        # Se il modello non è configurato, selezionalo automaticamente in base alla lingua
        if not vosk_model or vosk_model == 'auto':
            lang_code = self.settings.get('language', 'it-IT')
            vosk_model = self.get_vosk_model_for_language(lang_code)
            # Salva la selezione automatica
            self.settings['vosk_model'] = vosk_model
            with open("setup_generici/settings.json", "w", encoding='utf-8') as f:
                json.dump(self.settings, f, indent=4, ensure_ascii=False)

        # Verifica che il modello esista
        model_path = os.path.join("vosk_models", vosk_model)
        if not os.path.exists(model_path):
            QMessageBox.warning(self, "Modello Vosk Mancante",
                f"Il modello Vosk '{vosk_model}' non è stato trovato.\n\n"
                f"Percorso cercato: {model_path}\n\n"
                "Assicurati di aver scaricato il modello dalla sezione 'Controllo Librerie'.\n\n"
                f"Modelli disponibili:\n"
                f"• vosk-model-it-0.22 (Italiano completo)\n"
                f"• vosk-model-small-it-0.22 (Italiano piccolo)\n"
                f"• vosk-model-small-en-us-0.15 (Inglese)")
            self.btn_voice.setEnabled(True)
            self.btn_voice.setText("🎤 Voce")
            return

        self.speech_rec_thread = SpeechRecognitionThread(vosk_model)
        self.speech_rec_thread.recognized_text.connect(self.on_voice_recognized)
        self.speech_rec_thread.recognition_error.connect(self.on_voice_error)
        self.speech_rec_thread.finished.connect(lambda: self.btn_voice.setEnabled(True))
        self.speech_rec_thread.start()

        logging.info(f"Riconoscimento vocale avviato con modello: {vosk_model}")

    def show_status_message(self, message, error=False):
        """Mostra un messaggio di stato."""
        try:
            # Per ora, mostriamo il messaggio nei log
            if error:
                logging.error(f"Status: {message}")
            else:
                logging.info(f"Status: {message}")
        except Exception as e:
            logging.error(f"Errore nella visualizzazione messaggio: {e}")

    def initialize_detection_system(self):
        """Inizializza il sistema di rilevamento basato sulle impostazioni."""
        try:
            detection_system = self.settings.get('detection_system', 'opencv')

            if detection_system == 'opencv':
                # Inizializza OpenCV per il rilevamento
                try:
                    from Video.opencv.opencv_recognizer import OpenCVRecognizer
                    self.hand_detector = OpenCVRecognizer()
                    self.face_detector = OpenCVRecognizer()  # Usa la stessa classe per entrambi
                    logging.info("Sistema di rilevamento OpenCV inizializzato")
                except ImportError:
                    logging.warning("OpenCV detector non disponibile, rilevamento disabilitato")
                    self.hand_detector = None
                    self.face_detector = None

            elif detection_system == 'mediapipe':
                # Inizializza MediaPipe per il rilevamento
                try:
                    from Video.mediapipe.mediapipe_detector import MediaPipeHandDetector
                    self.hand_detector = MediaPipeHandDetector()
                    self.face_detector = None  # MediaPipe non ha rilevamento facciale in questo file
                    logging.info("Sistema di rilevamento MediaPipe inizializzato")
                except ImportError:
                    logging.warning("MediaPipe detector non disponibile, uso OpenCV come fallback")
                    try:
                        from Video.opencv.opencv_recognizer import OpenCVRecognizer
                        self.hand_detector = OpenCVRecognizer()
                        self.face_detector = OpenCVRecognizer()
                        logging.info("Sistema di rilevamento OpenCV inizializzato (fallback)")
                    except ImportError:
                        logging.warning("Nessun sistema di rilevamento disponibile")
                        self.hand_detector = None
                        self.face_detector = None
            else:
                logging.warning(f"Sistema di rilevamento '{detection_system}' non riconosciuto, uso OpenCV")
                try:
                    from Video.opencv.opencv_recognizer import OpenCVRecognizer
                    self.hand_detector = OpenCVRecognizer()
                    self.face_detector = OpenCVRecognizer()
                    logging.info("Sistema di rilevamento OpenCV inizializzato")
                except ImportError:
                    logging.warning("OpenCV detector non disponibile, rilevamento disabilitato")
                    self.hand_detector = None
                    self.face_detector = None

        except Exception as e:
            logging.error(f"Errore nell'inizializzazione del sistema di rilevamento: {e}")
            # Fallback a rilevamento disabilitato
            self.hand_detector = None
            self.face_detector = None

    def initialize_cpu_monitor(self):
        """Inizializza il monitoraggio della CPU."""
        try:
            self.cpu_monitor = CPUMonitor(self.settings, self)

            # Connetti i segnali
            self.cpu_monitor.cpu_warning.connect(self.on_cpu_warning)
            self.cpu_monitor.cpu_critical.connect(self.on_cpu_critical)
            self.cpu_monitor.temperature_warning.connect(self.on_temperature_warning)
            self.cpu_monitor.temperature_critical.connect(self.on_temperature_critical)

            # Avvia il monitoraggio
            self.cpu_monitor.start()

            logging.info("Monitoraggio CPU inizializzato")

        except Exception as e:
            logging.error(f"Errore nell'inizializzazione del monitoraggio CPU: {e}")
            self.cpu_monitor = None

    def on_cpu_warning(self, message):
        """Gestisce gli avvisi di CPU alta."""
        logging.warning(f"Avviso CPU: {message}")

        # Mostra un messaggio all'utente
        QMessageBox.warning(self, "Avviso CPU Alta",
                          f"L'applicazione sta utilizzando molta CPU:\n\n{message}\n\n"
                          "Considera di chiudere alcune applicazioni o riavviare il sistema.")

    def on_cpu_critical(self, message):
        """Gestisce situazioni critiche di CPU."""
        logging.critical(f"CPU Critica: {message}")

        # Mostra un messaggio critico all'utente
        QMessageBox.critical(self, "CPU Critica - Terminazione",
                           f"L'applicazione ha superato i limiti di CPU consentiti:\n\n{message}\n\n"
                           "L'applicazione verrà terminata per proteggere il sistema.")

    def on_temperature_warning(self, message):
        """Gestisce gli avvisi di temperatura alta."""
        logging.warning(f"Avviso Temperatura: {message}")

        # Mostra un messaggio di avviso all'utente
        QMessageBox.warning(self, "Avviso Temperatura Alta",
                          f"La temperatura del processore è elevata:\n\n{message}\n\n"
                          "Considera di:\n"
                          "• Chiudere altre applicazioni\n"
                          "• Migliorare la ventilazione\n"
                          "• Controllare le ventole del sistema")

    def on_temperature_critical(self, message):
        """Gestisce situazioni critiche di temperatura."""
        logging.critical(f"Temperatura Critica: {message}")

        # Mostra un messaggio critico all'utente
        QMessageBox.critical(self, "Temperatura Critica - Terminazione",
                           f"La temperatura del processore è CRITICAMENTE alta:\n\n{message}\n\n"
                           "L'applicazione verrà terminata per proteggere l'hardware.")

    def get_vosk_model_for_language(self, language_code):
        """
        Restituisce il modello Vosk appropriato per la lingua selezionata.
        """
        model_mapping = {
            'it-IT': 'vosk-model-it-0.22',
            'it': 'vosk-model-it-0.22',
            'en-US': 'vosk-model-small-en-us-0.15',
            'en': 'vosk-model-small-en-us-0.15',
            'es-ES': 'vosk-model-small-en-us-0.15',  # Fallback to English
            'fr-FR': 'vosk-model-small-en-us-0.15',  # Fallback to English
            'de-DE': 'vosk-model-small-en-us-0.15'   # Fallback to English
        }

        return model_mapping.get(language_code, 'vosk-model-it-0.22')

    def check_vosk_models_availability(self):
        """
        Verifica quali modelli Vosk sono disponibili e restituisce una lista.
        """
        available_models = []
        vosk_models_dir = "vosk_models"

        if os.path.exists(vosk_models_dir):
            for item in os.listdir(vosk_models_dir):
                item_path = os.path.join(vosk_models_dir, item)
                if os.path.isdir(item_path):
                    available_models.append(item)

        return available_models

    def on_voice_recognized(self, text):
        """Riceve il testo riconosciuto e lo inserisce nell'area di dettaglio."""
        self.work_area_left_text_edit.append(text)
        self.btn_voice.setText("🎤 Voce")

    def on_voice_error(self, message):
        """Mostra un messaggio di errore in caso di fallimento del riconoscimento vocale."""
        QMessageBox.warning(self, "Riconoscimento Vocale", message)
        self.btn_voice.setText("🎤 Voce")

    def handle_hands_button(self):
        """Gestisce il click del pulsante Rilevamento Mani."""
        try:
            # Attiva/disattiva il rilevamento mani
            current_enabled = self.settings.get('hand_detection', True)
            new_enabled = not current_enabled

            self.settings['hand_detection'] = new_enabled

            # Salva le impostazioni
            with open("setup_generici/settings.json", "w", encoding='utf-8') as f:
                json.dump(self.settings, f, indent=4, ensure_ascii=False)

            # Aggiorna l'interfaccia
            if new_enabled:
                if hasattr(self, 'btn_hands'):
                    self.btn_hands.setText("✋ Mani ✅")
                self.show_status_message("Rilevamento mani attivato")
            else:
                if hasattr(self, 'btn_hands'):
                    self.btn_hands.setText("✋ Mani ❌")
                self.show_status_message("Rilevamento mani disattivato")

            logging.info(f"Rilevamento mani: {'attivato' if new_enabled else 'disattivato'}")

        except Exception as e:
            logging.error(f"Errore nel pulsante mani: {e}")

    def handle_face_button(self):
        """Gestisce il click del pulsante Rilevamento Faccia."""
        try:
            # Attiva/disattiva il rilevamento faccia
            current_enabled = self.settings.get('face_detection', True)
            new_enabled = not current_enabled

            self.settings['face_detection'] = new_enabled

            # Salva le impostazioni
            with open("setup_generici/settings.json", "w", encoding='utf-8') as f:
                json.dump(self.settings, f, indent=4, ensure_ascii=False)

            # Aggiorna l'interfaccia
            if new_enabled:
                if hasattr(self, 'btn_face'):
                    self.btn_face.setText("😊 Faccia ✅")
                self.show_status_message("Rilevamento faccia attivato")
            else:
                if hasattr(self, 'btn_face'):
                    self.btn_face.setText("😊 Faccia ❌")
                self.show_status_message("Rilevamento faccia disattivato")

            logging.info(f"Rilevamento faccia: {'attivato' if new_enabled else 'disattivato'}")

        except Exception as e:
            logging.error(f"Errore nel pulsante faccia: {e}")

    def handle_add_media_button(self):
        """Gestisce il pulsante Aggiungi Media per selezionare file e inserirli direttamente nella colonna A (Pensierini)."""
        file_path, _ = QFileDialog.getOpenFileName(
            self,
            "Seleziona Media",
            "",
            "Tutti i file (*);;File di testo (*.txt *.md *.py *.js *.html *.css);;Immagini (*.png *.jpg *.jpeg *.gif *.bmp *.svg *.pdf)"
        )

        if file_path:
            self.add_media_to_pensierini(file_path)

    def display_media_in_column_c(self, file_path):
        """Visualizza il contenuto del file nella colonna C."""
        try:
            # Determina il tipo di file
            file_name = os.path.basename(file_path)
            file_extension = os.path.splitext(file_path)[1].lower()

            # Pulisce la colonna C prima di mostrare il nuovo contenuto
            self.clear_column_c()

            if file_extension in ['.txt', '.md', '.py', '.js', '.html', '.css', '.json', '.xml']:
                # File di testo - mostra in un editor di sola lettura
                with open(file_path, 'r', encoding='utf-8') as f:
                    content = f.read()

                # Crea un widget di testo in sola lettura
                text_viewer = QTextEdit()
                text_viewer.setPlainText(content)
                text_viewer.setReadOnly(True)
                text_viewer.setStyleSheet("""
                    QTextEdit {
                        background-color: #f8f9fa;
                        border: 1px solid #dee2e6;
                        border-radius: 5px;
                        font-family: 'Consolas', 'Monaco', 'Courier New', monospace;
                        font-size: 12px;
                        line-height: 1.4;
                    }
                """)

                # Aggiungi il widget alla colonna C
                self.work_area_left_layout.addWidget(text_viewer)

                # Salva il riferimento per poterlo rimuovere dopo
                self.current_media_widget = text_viewer
                self.current_media_path = file_path
                self.current_media_type = 'text'

            elif file_extension in ['.png', '.jpg', '.jpeg', '.gif', '.bmp', '.svg']:
                # Immagini - anteprima al 25% della qualità
                image_label = QLabel()
                pixmap = QPixmap(file_path)

                # Riduci la qualità al 25% delle dimensioni originali
                original_width = pixmap.width()
                original_height = pixmap.height()
                new_width = int(original_width * 0.25)
                new_height = int(original_height * 0.25)

                # Se le nuove dimensioni sono troppo piccole, mantieni un minimo
                if new_width < 50:
                    new_width = 50
                if new_height < 50:
                    new_height = 50

                # Ridimensiona l'immagine con qualità ridotta
                scaled_pixmap = pixmap.scaled(new_width, new_height, Qt.AspectRatioMode.KeepAspectRatio, Qt.TransformationMode.FastTransformation)

                image_label.setPixmap(scaled_pixmap)
                image_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
                image_label.setStyleSheet("""
                    QLabel {
                        background-color: #f8f9fa;
                        border: 1px solid #dee2e6;
                        border-radius: 5px;
                        padding: 10px;
                    }
                """)

                # Aggiungi informazioni sul file
                info_label = QLabel(f"🖼️ {file_name}\n[Anteprima 25% qualità - Originale: {original_width}x{original_height}]")
                info_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
                info_label.setStyleSheet("font-size: 10px; color: #666; margin-top: 5px;")

                # Contenitore per immagine e info
                container = QWidget()
                layout = QVBoxLayout(container)
                layout.addWidget(image_label)
                layout.addWidget(info_label)

                # Aggiungi il widget alla colonna C
                self.work_area_left_layout.addWidget(container)

                # Salva il riferimento per poterlo rimuovere dopo
                self.current_media_widget = container
                self.current_media_path = file_path
                self.current_media_type = 'image'

            elif file_extension == '.pdf':
                # Per i PDF, mostra un messaggio informativo
                pdf_label = QLabel(f"📄 PDF: {os.path.basename(file_path)}\n\nIl contenuto PDF non può essere visualizzato direttamente.\nUsa un visualizzatore PDF esterno per vedere il contenuto.")
                pdf_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
                pdf_label.setStyleSheet("""
                    QLabel {
                        background-color: #f8f9fa;
                        border: 1px solid #dee2e6;
                        border-radius: 5px;
                        padding: 20px;
                        font-size: 14px;
                        color: #6c757d;
                    }
                """)

                self.work_area_left_layout.addWidget(pdf_label)
                self.current_media_widget = pdf_label
                self.current_media_path = file_path
                self.current_media_type = 'pdf'

            else:
                # File non supportato
                error_label = QLabel(f"❌ Tipo di file non supportato: {file_extension}\n\nFile: {os.path.basename(file_path)}")
                error_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
                error_label.setStyleSheet("""
                    QLabel {
                        background-color: #f8d7da;
                        border: 1px solid #f5c6cb;
                        border-radius: 5px;
                        padding: 20px;
                        font-size: 14px;
                        color: #721c24;
                    }
                """)

                self.work_area_left_layout.addWidget(error_label)
                self.current_media_widget = error_label
                self.current_media_path = file_path
                self.current_media_type = 'unsupported'

            # Aggiungi un pulsante per spostare il contenuto nella colonna A
            move_to_pensierini_btn = QPushButton("➡️ Sposta in Pensierini")
            move_to_pensierini_btn.clicked.connect(lambda: self.move_media_to_pensierini())
            move_to_pensierini_btn.setStyleSheet("""
                QPushButton {
                    background-color: #28a745;
                    color: white;
                    border: none;
                    border-radius: 5px;
                    padding: 8px 15px;
                    font-weight: bold;
                }
                QPushButton:hover {
                    background-color: #218838;
                }
            """)
            self.work_area_left_layout.addWidget(move_to_pensierini_btn)

        except Exception as e:
            QMessageBox.critical(self, "Errore", f"Errore nel caricamento del file:\n{str(e)}")

    def clear_column_c(self):
        """Pulisce il contenuto della colonna C."""
        # Rimuovi tutti i widget dalla colonna C tranne il label del titolo
        while self.work_area_left_layout.count() > 1:  # Mantiene il label del titolo
            item = self.work_area_left_layout.itemAt(1)
            if item and item.widget():
                item.widget().deleteLater()

        # Resetta le variabili di stato
        self.current_media_widget = None
        self.current_media_path = None
        self.current_media_type = None

    def add_media_to_pensierini(self, file_path):
        """Aggiunge un file media direttamente nella colonna A (Pensierini) con anteprima a bassa qualità."""
        try:
            file_name = os.path.basename(file_path)
            file_extension = os.path.splitext(file_path)[1].lower()

            if file_extension in ['.txt', '.md', '.py', '.js', '.html', '.css', '.json', '.xml']:
                # File di testo - mostra anteprima del contenuto
                with open(file_path, 'r', encoding='utf-8') as f:
                    content = f.read()
                    # Limita il contenuto a 500 caratteri per l'anteprima
                    preview_content = content[:500] + "..." if len(content) > 500 else content

                media_text = f"📄 {file_name}\n\n{preview_content}\n\n📎 {file_name}"

            elif file_extension in ['.png', '.jpg', '.jpeg', '.gif', '.bmp', '.svg']:
                # Immagini - crea anteprima al 25% della qualità
                pixmap = QPixmap(file_path)

                # Riduci la qualità al 25% delle dimensioni originali
                original_width = pixmap.width()
                original_height = pixmap.height()
                new_width = int(original_width * 0.25)
                new_height = int(original_height * 0.25)

                # Se le nuove dimensioni sono troppo piccole, mantieni un minimo
                if new_width < 50:
                    new_width = 50
                if new_height < 50:
                    new_height = 50

                scaled_pixmap = pixmap.scaled(new_width, new_height, Qt.AspectRatioMode.KeepAspectRatio, Qt.TransformationMode.FastTransformation)

                media_text = f"🖼️ {file_name}\n\n[Anteprima 25% qualità - Dimensioni originali: {original_width}x{original_height}]\n\n📎 {file_name}"

            elif file_extension == '.pdf':
                # PDF - mostra informazioni sul documento
                try:
                    # Usa subprocess per ottenere informazioni sul PDF con pdftotext o simili
                    import subprocess
                    try:
                        # Prova a estrarre testo dalla prima pagina
                        result = subprocess.run(['pdftotext', '-l', '1', file_path, '-'],
                                              capture_output=True, text=True, timeout=10)
                        if result.returncode == 0 and result.stdout.strip():
                            preview_text = result.stdout.strip()[:300] + "..." if len(result.stdout.strip()) > 300 else result.stdout.strip()
                        else:
                            preview_text = "[Impossibile estrarre anteprima testo]"
                    except (subprocess.TimeoutExpired, FileNotFoundError):
                        preview_text = "[pdftotext non disponibile]"

                    media_text = f"📕 {file_name}\n\n[Prima pagina PDF]\n{preview_text}\n\n📎 {file_name}"

                except Exception:
                    media_text = f"📕 {file_name}\n\n[Anteprima PDF non disponibile]\n\n📎 {file_name}"

            else:
                # File non supportato
                media_text = f"📎 {file_name}\n\n[File non supportato per anteprima]\n\n📎 {file_name}"

            # Crea un nuovo widget trascinabile nella colonna A con il nome in basso a destra
            new_widget = DraggableTextWidget(media_text, self.settings)
            self.draggable_widgets_layout.addWidget(new_widget)

            logging.info(f"File '{file_name}' aggiunto ai Pensierini con anteprima")

        except Exception as e:
            logging.error(f"Errore nell'aggiungere il file ai Pensierini: {e}")
            QMessageBox.critical(self, "Errore", f"Errore nel caricamento del file:\n{str(e)}")

    def move_media_to_pensierini(self):
        """Sposta il contenuto corrente della colonna C nella colonna A (Pensierini)."""
        if hasattr(self, 'current_media_path') and self.current_media_path:
            self.add_media_to_pensierini(self.current_media_path)

    def handle_clean_button(self):
        """Pulisce il campo di input in basso e l'area di dettaglio (C)."""
        self.clear_column_c()
        self.input_field.clear()
        QMessageBox.information(self, "Pulisci", "L'area di input e la colonna 'Dettagli' sono state pulite.")

    def closeEvent(self, event):
        """Gestisce la chiusura dell'applicazione."""
        logging.getLogger().removeHandler(self.handler)

        # Ferma tutti i thread in modo sicuro
        if hasattr(self, 'video_thread') and self.video_thread:
            if self.video_thread.isRunning():
                self.video_thread.stop()
                if not self.video_thread.wait(3000):  # Timeout di 3 secondi
                    logging.warning("VideoThread non terminato entro il timeout")

        if hasattr(self, 'speech_rec_thread') and self.speech_rec_thread:
            if self.speech_rec_thread.isRunning():
                self.speech_rec_thread.stop()
                if not self.speech_rec_thread.wait(3000):
                    logging.warning("SpeechRecognitionThread non terminato entro il timeout")

        tts_thread = getattr(self, 'tts_thread', None)
        if tts_thread and tts_thread.isRunning():
            tts_thread.stop()
            if not tts_thread.wait(3000):
                logging.warning("TTSThread non terminato entro il timeout")

        # Ferma il monitoraggio CPU
        if hasattr(self, 'cpu_monitor') and self.cpu_monitor:
            if self.cpu_monitor.isRunning():
                self.cpu_monitor.stop()
                if not self.cpu_monitor.wait(3000):
                    logging.warning("CPUMonitor non terminato entro il timeout")

        event.accept()

# ==============================================================================
# Funzione Principale per l'Esecuzione
# ==============================================================================
def main():
    """Funzione principale per avviare l'applicazione."""
    # Creazione della directory per il salvataggio dei file, se non esiste
    if not os.path.exists("saved_data"):
        os.makedirs("saved_data")

    app = QApplication(sys.argv)
    app.setApplicationName("Assistente per Dislessia")
    app.setOrganizationName("DSA Helper")

    try:
        app.setWindowIcon(QIcon("icon.png"))
    except Exception as e:
        logging.warning(f"Impossibile caricare 'icon.png': {e}")

    window = MainWindow()
    window.show()
    sys.exit(app.exec())

if __name__ == '__main__':
    main()
