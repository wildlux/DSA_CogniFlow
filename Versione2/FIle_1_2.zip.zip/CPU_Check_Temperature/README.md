# CPU_Check_Temperature - Monitoraggio CPU e Temperatura

Questo modulo gestisce il monitoraggio dell'utilizzo della CPU e della temperatura del processore per l'applicazione DSA.

## Funzionalità

### Monitoraggio CPU
- **Controllo continuo**: Monitora l'utilizzo della CPU ogni 5 secondi (configurabile)
- **Soglie configurabili**: Soglia di allarme al 95% (configurabile)
- **Durata minima**: Attesa di 30 secondi prima di segnalare problemi (configurabile)
- **Segnali di sistema**: Invia SIGTERM, SIGKILL o SIGUSR1 in caso di sovraccarico

### Monitoraggio Temperatura
- **Supporto multi-piattaforma**:
  - **Linux**: Lettura diretta da `/sys/class/thermal/thermal_zone*/temp`
  - **Windows**: Utilizzo di WMI (se disponibile)
  - **psutil**: Sensori integrati del sistema
- **Soglie di sicurezza**:
  - Avviso a 80°C (configurabile)
  - Critico a 90°C (configurabile)
  - Durata minima di 60 secondi prima dell'avviso

### Configurazione
Le impostazioni sono salvate in `setup_generici/settings.json`:

```json
{
    "cpu_monitoring_enabled": true,
    "cpu_threshold_percent": 95.0,
    "cpu_high_duration_seconds": 30,
    "cpu_check_interval_seconds": 5,
    "cpu_signal_type": "SIGTERM",
    "temperature_monitoring_enabled": true,
    "temperature_threshold_celsius": 80.0,
    "temperature_high_duration_seconds": 60,
    "temperature_critical_threshold": 90.0
}
```

## Utilizzo

```python
from CPU_Check_Temperature.cpu_monitor import CPUMonitor

# Inizializzazione
cpu_monitor = CPUMonitor(settings, parent=self)

# Connessione segnali
cpu_monitor.cpu_warning.connect(self.on_cpu_warning)
cpu_monitor.cpu_critical.connect(self.on_cpu_critical)
cpu_monitor.temperature_warning.connect(self.on_temperature_warning)
cpu_monitor.temperature_critical.connect(self.on_temperature_critical)

# Avvio monitoraggio
cpu_monitor.start()

# Arresto
cpu_monitor.stop()
```

## Segnali Emessi

- `cpu_warning`: Avviso di CPU alta
- `cpu_critical`: CPU critica - terminazione immediata
- `temperature_warning`: Avviso di temperatura elevata
- `temperature_critical`: Temperatura critica - terminazione immediata

## Sicurezza

- **Protezione hardware**: Previene il surriscaldamento del processore
- **Gestione errori**: Funziona anche senza sensori di temperatura
- **Logging completo**: Registra tutte le attività per il debug
- **Chiusura sicura**: Ferma correttamente tutti i thread

## Dipendenze

- **psutil**: Raccomandato per monitoraggio CPU e temperatura
- **wmi**: Opzionale per Windows (migliora la lettura temperatura)
- **PyQt6**: Per i segnali e il threading

Il modulo è progettato per essere robusto e funzionare anche in sistemi con sensori limitati.