# ===========================================
# ASSISTENTE DSA - APPLICAZIONE PRINCIPALE
# ===========================================
# Versione rifattorizzata e ottimizzata dell'applicazione DSA
# Autore: Sistema DSA
# Data: 2025
# ===========================================

import sys
import json
import logging
import os

# Import PyQt6
from PyQt6.QtCore import Qt, QObject, pyqtSignal
from PyQt6.QtWidgets import (
    QApplication, QMainWindow, QWidget, QVBoxLayout, QLabel,
    QPushButton, QHBoxLayout, QComboBox, QLineEdit, QGridLayout,
    QDialog, QTextEdit, QTabWidget, QMessageBox, QGroupBox,
    QInputDialog, QSlider, QScrollArea
)
from PyQt6.QtGui import (
    QImage, QPixmap, QDrag, QCursor, QIcon, QPainter, QPen, QColor,
    QFont, QShortcut, QKeySequence
)


# Import moduli locali (con fallback per evitare errori di import)
try:
    from setup_generici.safe_qt_wrapper import SafeQtWrapper
except ImportError:
    SafeQtWrapper = None

try:
    from UI.draggable_text_widget import DraggableTextWidget
except ImportError:
    DraggableTextWidget = None

# Configurazione logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('app.log'),
        logging.StreamHandler(sys.stdout)
    ]
)
logger = logging.getLogger(__name__)


# ===========================================
# CONFIGURAZIONE GLOBALE
# ===========================================

class AppConfig:
    """Classe per la gestione della configurazione dell'applicazione."""

    # Costanti dell'applicazione
    WINDOW_WIDTH = 1200
    WINDOW_HEIGHT = 800
    CONFIG_DIALOG_WIDTH = 1000
    CONFIG_DIALOG_HEIGHT = 700
    WIDGET_MIN_HEIGHT = 60
    DEFAULT_FONT_SIZE = 12
    DEFAULT_PENSIERINI_FONT_SIZE = 10

    # File di configurazione
    SETTINGS_FILE = "settings.json"
    LOG_FILE = "app.log"

    # Impostazioni di default
    DEFAULT_SETTINGS = {
        'theme': 'Chiaro',
        'main_font_family': 'Arial',
        'main_font_size': DEFAULT_FONT_SIZE,
        'pensierini_font_family': 'Arial',
        'pensierini_font_size': DEFAULT_PENSIERINI_FONT_SIZE,
        'hand_detection_system': 'Auto (Migliore)',
        'face_detection_system': 'Auto (Migliore)',
        'gesture_system': 'Auto (Migliore)',
        'hand_confidence': 50,
        'face_confidence': 50,
        'show_hand_landmarks': True,
        'show_expressions': True,
        'detect_glasses': True,
        'gesture_timeout': 3,
        'gesture_sensitivity': 5,
        'gpu_system': 'Auto (Migliore)',
        'gpu_memory_limit': 80,
        'gpu_filters': True,
        'interface_language': 'Italiano',
        'tts_language': 'it-IT',
        'tts_engine': 'pyttsx3',
        'tts_speed': 1.0,
        'tts_pitch': 1.0,
        'ai_trigger': '++++'
    }

    @classmethod
    def load_settings(cls):
        """Carica le impostazioni dal file."""
        try:
            if os.path.exists(cls.SETTINGS_FILE):
                with open(cls.SETTINGS_FILE, 'r', encoding='utf-8') as f:
                    return {**cls.DEFAULT_SETTINGS, **json.load(f)}
            return cls.DEFAULT_SETTINGS.copy()
        except Exception as e:
            logger.error(f"Errore nel caricamento delle impostazioni: {e}")
            return cls.DEFAULT_SETTINGS.copy()

    @classmethod
    def save_settings(cls, settings):
        """Salva le impostazioni su file."""
        try:
            with open(cls.SETTINGS_FILE, 'w', encoding='utf-8') as f:
                json.dump(settings, f, indent=4, ensure_ascii=False)
            logger.info("Impostazioni salvate con successo")
        except Exception as e:
            logger.error(f"Errore nel salvataggio delle impostazioni: {e}")

# ===========================================
# EMITTER PER LOG
# ===========================================


class LogEmitter(QObject):
    """Oggetto QObject per emettere segnali di log."""
    new_record = pyqtSignal(str)
    error_occurred = pyqtSignal()

class TextEditLogger(logging.Handler):
    """Handler di logging personalizzato che emette segnali a un QTextEdit."""
    def __init__(self, log_emitter, parent=None):
        super().__init__()
        self.log_emitter = log_emitter
        self.setFormatter(logging.Formatter('%(asctime)s - %(levelname)s - %(message)s'))

    def emit(self, record):
        msg = self.format(record)
        self.log_emitter.new_record.emit(msg)
        if record.levelno >= logging.ERROR:
            self.log_emitter.error_occurred.emit()

# ===========================================
# DIALOGO DI CONFIGURAZIONE
# ===========================================

class ConfigurationDialog(QDialog):
    """Dialogo per la configurazione dell'applicazione."""

    def __init__(self, parent=None, settings=None):
        super().__init__(parent)
        self.setWindowTitle("⚙️ Menu di Configurazione")
        self.setModal(True)
        self.resize(AppConfig.CONFIG_DIALOG_WIDTH, AppConfig.CONFIG_DIALOG_HEIGHT)

        self.settings = settings or AppConfig.load_settings()
        self.vosk_downloader_thread = None
        self.tts_test_thread = None
        self.logger = logging.getLogger(__name__)

        # Inizializzazione delle variabili UI per evitare errori
        # Queste verranno create nei metodi setup_*

        self.setup_ui()
        self.load_settings()

        # Thread per i modelli Ollama (commentato per ora)
        # self.ollama_models_thread = OllamaModelsThread()
        # self.ollama_models_thread.models_list.connect(self.update_ollama_models)
        # self.ollama_models_thread.error_occurred.connect(self.on_ollama_models_error)
        # self.ollama_models_thread.start()

    def safe_getattr(self, obj, attr, default=None):
        """Ottiene un attributo in modo sicuro."""
        if obj is None:
            return default
        try:
            return getattr(obj, attr, default)
        except Exception:
            return default

    def safe_call(self, obj, method_name, *args, **kwargs):
        """Chiama un metodo in modo sicuro."""
        if obj is None:
            return None
        try:
            method = getattr(obj, method_name, None)
            if method and callable(method):
                return method(*args, **kwargs)
        except Exception:
            pass
        return None

    def setup_ui(self):
        """Configura l'interfaccia utente del dialogo."""
        layout = QVBoxLayout(self)

        # Tab Widget
        self.tab_widget = QTabWidget()

        # Tabs
        self.setup_ai_tab()
        self.setup_detection_tab()
        self.setup_interface_tab()
        self.setup_system_tab()

        layout.addWidget(self.tab_widget)

        # Pulsanti
        bottom_layout = QHBoxLayout()
        bottom_layout.addStretch(1)

        apply_btn = QPushButton("Applica ✅")
        apply_btn.setStyleSheet("background-color: #4CAF50; color: white;")
        apply_btn.clicked.connect(self.apply_changes)
        bottom_layout.addWidget(apply_btn)

        close_btn = QPushButton("Chiudi ➡️")
        close_btn.clicked.connect(self.reject)
        bottom_layout.addWidget(close_btn)

        layout.addLayout(bottom_layout)

    def setup_ai_tab(self):
        """Configura il tab per le impostazioni dell'IA."""
        ai_widget = QWidget()
        layout = QVBoxLayout(ai_widget)

        # Modello Ollama
        ai_group = QGroupBox("Selezione AI")
        ai_layout = QVBoxLayout(ai_group)
        self.ollama_model_combo = QComboBox()
        self.ollama_model_combo.addItem("Caricamento modelli...")
        ai_layout.addWidget(QLabel("Modello Ollama:"))
        ai_layout.addWidget(self.ollama_model_combo)

        test_btn = QPushButton("Testa Connessione & Modelli")
        test_btn.clicked.connect(self.test_ollama_connection)
        ai_layout.addWidget(test_btn)

        self.ollama_status_label = QLabel("Stato: In attesa di caricamento...")
        self.ollama_status_label.setStyleSheet("color: #4a90e2;")
        ai_layout.addWidget(self.ollama_status_label)
        layout.addWidget(ai_group)

        # Trigger AI
        trigger_group = QGroupBox("Trigger per AI")
        trigger_layout = QVBoxLayout(trigger_group)
        trigger_layout.addWidget(QLabel("Imposta una parola d'ordine per inviare il testo all'AI:"))
        self.ai_trigger_input = QLineEdit(self.settings.get('ai_trigger', '++++'))
        trigger_layout.addWidget(self.ai_trigger_input)
        layout.addWidget(trigger_group)

        layout.addStretch()
        self.tab_widget.addTab(ai_widget, "Configurazione AI")

    def setup_detection_tab(self):
        """Configura il tab per il rilevamento avanzato."""
        detection_widget = QWidget()
        layout = QVBoxLayout(detection_widget)

        title_label = QLabel("🎯 Rilevamento Avanzato")
        title_label.setStyleSheet("font-size: 18px; font-weight: bold; color: #2c3e50; margin-bottom: 10px;")
        layout.addWidget(title_label)

        # Sezione mani
        hand_group = QGroupBox("🤏 Rilevamento Mani")
        hand_layout = QVBoxLayout(hand_group)

        hand_layout.addWidget(QLabel("🎯 Sistema di rilevamento mani:"))
        self.hand_detection_system = QComboBox()
        self.hand_detection_system.addItems(['MediaPipe (Avanzato)', 'Legacy (Base)', 'Auto (Migliore)'])
        self.hand_detection_system.setCurrentText(self.settings.get('hand_detection_system', 'Auto (Migliore)'))
        hand_layout.addWidget(self.hand_detection_system)

        # Parametri mani
        hand_params_layout = QGridLayout()
        hand_params_layout.addWidget(QLabel("📏 Confidenza minima:"), 0, 0)
        self.hand_confidence = QSlider(Qt.Orientation.Horizontal)
        self.hand_confidence.setRange(1, 100)
        self.hand_confidence.setValue(self.settings.get('hand_confidence', 50))
        self.hand_confidence_label = QLabel(f"{self.hand_confidence.value()}%")
        self.hand_confidence.valueChanged.connect(lambda v: self.hand_confidence_label.setText(f"{v}%"))
        hand_params_layout.addWidget(self.hand_confidence, 0, 1)
        hand_params_layout.addWidget(self.hand_confidence_label, 0, 2)

        hand_layout.addLayout(hand_params_layout)
        layout.addWidget(hand_group)

        # Pulsanti
        buttons_layout = QHBoxLayout()
        apply_btn = QPushButton("💾 Salva Impostazioni")
        apply_btn.clicked.connect(self.apply_detection_settings)
        buttons_layout.addWidget(apply_btn)
        buttons_layout.addStretch()
        layout.addLayout(buttons_layout)

        layout.addStretch()
        self.tab_widget.addTab(detection_widget, "🎯 Rilevamento")

    def setup_interface_tab(self):
        """Configura il tab per l'interfaccia."""
        interface_widget = QWidget()
        layout = QVBoxLayout(interface_widget)

        title_label = QLabel("🎨 Interfaccia e Personalizzazione")
        title_label.setStyleSheet("font-size: 18px; font-weight: bold; color: #2c3e50; margin-bottom: 10px;")
        layout.addWidget(title_label)

        # Tema
        appearance_group = QGroupBox("🎭 Aspetto Interfaccia")
        appearance_layout = QVBoxLayout(appearance_group)

        appearance_layout.addWidget(QLabel("🎨 Tema dell'applicazione:"))
        self.theme_selector = QComboBox()
        self.theme_selector.addItems(['Chiaro', 'Scuro', 'Automatico'])
        self.theme_selector.setCurrentText(self.settings.get('theme', 'Chiaro'))
        appearance_layout.addWidget(self.theme_selector)

        layout.addWidget(appearance_group)

        # Pulsanti
        buttons_layout = QHBoxLayout()
        apply_btn = QPushButton("💾 Salva Impostazioni")
        apply_btn.clicked.connect(self.apply_interface_settings)
        buttons_layout.addWidget(apply_btn)
        buttons_layout.addStretch()
        layout.addLayout(buttons_layout)

        layout.addStretch()
        self.tab_widget.addTab(interface_widget, "🎨 Interfaccia")

    def setup_system_tab(self):
        """Configura il tab per il sistema."""
        system_widget = QWidget()
        layout = QVBoxLayout(system_widget)

        title_label = QLabel("⚙️ Sistema e Librerie")
        title_label.setStyleSheet("font-size: 18px; font-weight: bold; color: #2c3e50; margin-bottom: 10px;")
        layout.addWidget(title_label)

        # GPU
        gpu_group = QGroupBox("🚀 Accelerazione GPU")
        gpu_layout = QVBoxLayout(gpu_group)

        gpu_layout.addWidget(QLabel("🎯 Sistema GPU:"))
        self.gpu_system = QComboBox()
        self.gpu_system.addItems(['Auto (Migliore)', 'NVIDIA CUDA', 'AMD ROCm', 'CPU'])
        self.gpu_system.setCurrentText(self.settings.get('gpu_system', 'Auto (Migliore)'))
        gpu_layout.addWidget(self.gpu_system)

        layout.addWidget(gpu_group)

        # Pulsanti
        buttons_layout = QHBoxLayout()
        apply_btn = QPushButton("💾 Salva Impostazioni")
        apply_btn.clicked.connect(self.apply_system_settings)
        buttons_layout.addWidget(apply_btn)
        buttons_layout.addStretch()
        layout.addLayout(buttons_layout)

        layout.addStretch()
        self.tab_widget.addTab(system_widget, "⚙️ Sistema")

    def load_settings(self):
        """Carica le impostazioni nei controlli dell'interfaccia."""
        try:
            # Carica le impostazioni nei controlli
            self.ai_trigger_input.setText(self.settings.get('ai_trigger', '++++'))
            logger.info("Impostazioni caricate nell'interfaccia")
        except Exception as e:
            logger.error(f"Errore nel caricamento delle impostazioni: {e}")

    def apply_changes(self):
        """Applica tutte le modifiche alle impostazioni."""
        try:
            # Salva le impostazioni
            self.settings['ai_trigger'] = self.ai_trigger_input.text()
            AppConfig.save_settings(self.settings)
            QMessageBox.information(self, "Impostazioni Salvate", "✅ Impostazioni salvate con successo!")
        except Exception as e:
            QMessageBox.critical(self, "Errore", f"❌ Errore nel salvataggio: {str(e)}")

    def apply_detection_settings(self):
        """Applica le impostazioni di rilevamento."""
        try:
            if hasattr(self, 'hand_detection_system') and self.hand_detection_system:
                self.settings['hand_detection_system'] = self.hand_detection_system.currentText()
            if hasattr(self, 'hand_confidence') and self.hand_confidence:
                self.settings['hand_confidence'] = self.hand_confidence.value()
            AppConfig.save_settings(self.settings)
            QMessageBox.information(self, "Impostazioni Salvate", "✅ Impostazioni di rilevamento salvate!")
        except Exception as e:
            QMessageBox.critical(self, "Errore", f"❌ Errore nel salvataggio: {str(e)}")

    def apply_interface_settings(self):
        """Applica le impostazioni di interfaccia."""
        try:
            if hasattr(self, 'theme_selector') and self.theme_selector:
                self.settings['theme'] = self.safe_call(self.theme_selector, 'currentText') or 'Chiaro'
            AppConfig.save_settings(self.settings)
            QMessageBox.information(self, "Impostazioni Salvate", "✅ Impostazioni di interfaccia salvate!")
        except Exception as e:
            QMessageBox.critical(self, "Errore", f"❌ Errore nel salvataggio: {str(e)}")

    def apply_system_settings(self):
        """Applica le impostazioni di sistema."""
        try:
            if hasattr(self, 'gpu_system') and self.gpu_system:
                self.settings['gpu_system'] = self.safe_call(self.gpu_system, 'currentText') or 'Auto (Migliore)'
            AppConfig.save_settings(self.settings)
            QMessageBox.information(self, "Impostazioni Salvate", "✅ Impostazioni di sistema salvate!")
        except Exception as e:
            QMessageBox.critical(self, "Errore", f"❌ Errore nel salvataggio: {str(e)}")

    def update_ollama_models(self, models):
        """Aggiorna la lista dei modelli Ollama."""
        try:
            self.ollama_model_combo.clear()
            if models:
                self.ollama_model_combo.addItems(models)
                self.ollama_status_label.setText("✅ Modelli caricati con successo")
                self.ollama_status_label.setStyleSheet("color: #27ae60;")
            else:
                self.ollama_model_combo.addItem("Nessun modello disponibile")
                self.ollama_status_label.setText("⚠️ Nessun modello trovato")
                self.ollama_status_label.setStyleSheet("color: #f39c12;")
        except Exception as e:
            logger.error(f"Errore nell'aggiornamento dei modelli Ollama: {e}")

    def on_ollama_models_error(self, error_message):
        """Gestisce gli errori nel caricamento dei modelli Ollama."""
        try:
            self.ollama_status_label.setText(f"❌ Errore: {error_message}")
            self.ollama_status_label.setStyleSheet("color: #e74c3c;")
            logger.error(f"Errore modelli Ollama: {error_message}")
        except Exception as e:
            logger.error(f"Errore nella gestione dell'errore Ollama: {e}")

    def test_ollama_connection(self):
        """Testa la connessione e i modelli Ollama."""
        try:
            QMessageBox.information(self, "Test Ollama", "Funzionalità di test da implementare")
        except Exception as e:
            logger.error(f"Errore nel test Ollama: {e}")

# ===========================================
# FINESTRA PRINCIPALE
# ===========================================

class MainWindow(QMainWindow):
    """Finestra principale dell'applicazione DSA."""

    def __init__(self):
        super().__init__()
        self.logger = logging.getLogger(__name__)
        self.settings = AppConfig.load_settings()

        # Thread e componenti
        self.video_thread = None
        self.ollama_thread = None
        self.speech_thread = None
        self.tts_thread = None

        # Componenti UI
        self.log_emitter = LogEmitter()
        self.log_text = QTextEdit()
        self.text_widgets = []

        # Area di lavoro principale
        self.work_area = QTextEdit()
        self.work_area.setPlaceholderText("Area di lavoro principale - inserisci qui il tuo testo...")

        # Variabili per la gestione vocale
        self.is_listening = False
        self.speech_rec_thread = None

        # Variabili per l'AI
        self.ollama_thread = None

        self.setup_ui()
        self.setup_connections()
        self.load_settings()

        self.logger.info("Applicazione DSA avviata")

    def safe_call(self, obj, method_name, *args, **kwargs):
        """Chiama un metodo in modo sicuro."""
        if obj is None:
            return None
        try:
            method = getattr(obj, method_name, None)
            if method and callable(method):
                return method(*args, **kwargs)
        except Exception:
            pass
        return None

    def setup_ui(self):
        """Configura l'interfaccia utente principale."""
        self.setWindowTitle("🎯 Assistente DSA - Sistema Avanzato")
        self.setGeometry(100, 100, AppConfig.WINDOW_WIDTH, AppConfig.WINDOW_HEIGHT)

        # Widget centrale
        central_widget = QWidget()
        self.setCentralWidget(central_widget)
        main_layout = QVBoxLayout(central_widget)

        # Barra degli strumenti
        toolbar_layout = QHBoxLayout()

        # Pulsanti principali
        self.add_button = QPushButton("📝 Inserisci testo")
        self.add_button.clicked.connect(self.add_text_widget)
        toolbar_layout.addWidget(self.add_button)

        self.ai_button = QPushButton("🧠 AI")
        self.ai_button.clicked.connect(self.handle_ai_button)
        toolbar_layout.addWidget(self.ai_button)

        self.voice_button = QPushButton("🎤 Voce")
        self.voice_button.clicked.connect(self.handle_voice_button)
        toolbar_layout.addWidget(self.voice_button)

        self.hands_button = QPushButton("✋ Mani")
        self.hands_button.clicked.connect(self.handle_hands_button)
        toolbar_layout.addWidget(self.hands_button)

        self.face_button = QPushButton("😊 Faccia")
        self.face_button.clicked.connect(self.handle_face_button)
        toolbar_layout.addWidget(self.face_button)

        self.clean_button = QPushButton("🧹 Pulisci")
        self.clean_button.clicked.connect(self.handle_clean_button)
        toolbar_layout.addWidget(self.clean_button)

        self.options_button = QPushButton("⚙️ Opzioni")
        self.options_button.clicked.connect(self.open_settings)
        toolbar_layout.addWidget(self.options_button)

        toolbar_layout.addStretch()
        main_layout.addLayout(toolbar_layout)

        # Area di lavoro
        self.workspace_area = QScrollArea()
        self.workspace_widget = QWidget()
        self.workspace_layout = QVBoxLayout(self.workspace_widget)
        self.workspace_area.setWidget(self.workspace_widget)
        self.workspace_area.setWidgetResizable(True)
        main_layout.addWidget(self.workspace_area)

        # Aggiungi l'area di lavoro principale
        self.work_area_group = QGroupBox("📝 Area di Lavoro")
        work_layout = QVBoxLayout(self.work_area_group)
        work_layout.addWidget(self.work_area)
        main_layout.addWidget(self.work_area_group)

        # Area di log
        log_group = QGroupBox("📊 Log del Sistema")
        log_layout = QVBoxLayout(log_group)
        log_layout.addWidget(self.log_text)
        main_layout.addWidget(log_group)

        # Setup logging
        self.log_handler = TextEditLogger(self.log_emitter)
        logging.getLogger().addHandler(self.log_handler)
        self.log_emitter.new_record.connect(self.append_log)

    def setup_connections(self):
        """Configura le connessioni tra componenti."""
        try:
            # Connessioni per i thread
            if self.video_thread:
                self.video_thread.frame_ready.connect(self.update_video_frame)
                self.video_thread.error_occurred.connect(self.on_video_error)

            if self.ollama_thread:
                self.ollama_thread.response_ready.connect(self.on_ai_response)
                self.ollama_thread.error_occurred.connect(self.on_ai_error)

            if self.speech_thread:
                self.speech_thread.text_recognized.connect(self.on_voice_recognized)
                self.speech_thread.error_occurred.connect(self.on_voice_error)

            logger.info("Connessioni configurate")
        except Exception as e:
            logger.error(f"Errore nella configurazione delle connessioni: {e}")

    def load_settings(self):
        """Carica le impostazioni dell'applicazione."""
        try:
            self.settings = AppConfig.load_settings()
            self.logger.info("Impostazioni caricate")
        except Exception as e:
            self.logger.error(f"Errore nel caricamento delle impostazioni: {e}")

    def add_text_widget(self):
        """Aggiunge un nuovo widget di testo trascinabile."""
        try:
            text, ok = QInputDialog.getText(self, "Nuovo Pensierino", "Inserisci il testo:")
            if ok and text:
                if DraggableTextWidget:
                    widget = DraggableTextWidget(text, self.settings)
                    self.workspace_layout.addWidget(widget)
                    self.text_widgets.append(widget)
                    self.logger.info(f"Nuovo widget di testo aggiunto: {text[:50]}...")
                else:
                    self.logger.error("DraggableTextWidget non disponibile")
        except Exception as e:
            self.logger.error(f"Errore nell'aggiunta del widget di testo: {e}")

    def handle_ai_button(self):
        """Gestisce il pulsante AI."""
        try:
            # Verifica se Ollama è configurato
            if not self.settings.get('ollama_model'):
                QMessageBox.information(self, "Configurazione AI",
                    "Per utilizzare l'AI, configura prima un modello Ollama nelle impostazioni.\n\n"
                    "1. Apri Impostazioni (⚙️)\n"
                    "2. Vai su 'Configurazione AI'\n"
                    "3. Seleziona un modello Ollama\n"
                    "4. Salva le impostazioni")
                return

            # Ottieni il testo dall'area di lavoro
            if hasattr(self, 'work_area') and self.work_area:
                text_result = self.safe_call(self.work_area, 'toPlainText', '')
                text = str(text_result).strip() if text_result else ""
            else:
                text = ""

            if not text:
                QMessageBox.information(self, "Testo Mancante",
                    "Inserisci del testo nell'area di lavoro per elaborarlo con l'AI.")
                return

            # Invia il testo all'AI
            self.process_with_ai(text)

        except Exception as e:
            self.logger.error(f"Errore nel pulsante AI: {e}")
            QMessageBox.critical(self, "Errore AI", f"Errore nell'elaborazione AI:\n{str(e)}")

    def handle_voice_button(self):
        """Gestisce il pulsante Voce per registrazione e trascrizione."""
        try:
            if hasattr(self, 'is_listening') and self.is_listening:
                # Ferma la registrazione
                self.stop_voice_recording()
            else:
                # Avvia la registrazione
                self.start_voice_recording()

        except Exception as e:
            self.logger.error(f"Errore nel pulsante voce: {e}")
            QMessageBox.critical(self, "Errore Voce", f"Errore nel sistema vocale:\n{str(e)}")

    def handle_hands_button(self):
        """Gestisce il pulsante Mani."""
        try:
            self.logger.info("Pulsante Mani premuto")
            # Implementazione da completare
        except Exception as e:
            self.logger.error(f"Errore nel pulsante Mani: {e}")

    def handle_face_button(self):
        """Gestisce il pulsante Faccia."""
        try:
            self.logger.info("Pulsante Faccia premuto")
            # Implementazione da completare
        except Exception as e:
            self.logger.error(f"Errore nel pulsante Faccia: {e}")

    def handle_clean_button(self):
        """Gestisce il pulsante Pulisci."""
        try:
            self.logger.info("Pulsante Pulisci premuto")
            # Implementazione da completare
        except Exception as e:
            self.logger.error(f"Errore nel pulsante Pulisci: {e}")

    def open_settings(self):
        """Apre il dialogo delle impostazioni."""
        try:
            dialog = ConfigurationDialog(self, self.settings)
            if dialog.exec():
                self.settings = dialog.settings
                self.load_settings()
                self.logger.info("Impostazioni aggiornate")
        except Exception as e:
            self.logger.error(f"Errore nell'apertura delle impostazioni: {e}")

    def append_log(self, message):
        """Aggiunge un messaggio al log."""
        try:
            self.log_text.append(message)
            # Scroll automatico alla fine
            scrollbar = self.log_text.verticalScrollBar()
            if scrollbar:
                scrollbar.setValue(scrollbar.maximum())
        except Exception as e:
            print(f"Errore nell'aggiunta del log: {e}")

    def update_video_frame(self, frame):
        """Aggiorna il frame video."""
        try:
            # Implementazione da completare
            pass
        except Exception as e:
            self.logger.error(f"Errore nell'aggiornamento del frame video: {e}")

    def on_video_error(self, message):
        """Gestisce gli errori del video."""
        try:
            self.logger.error(f"Errore video: {message}")
        except Exception as e:
            self.logger.error(f"Errore nella gestione dell'errore video: {e}")

    def on_ai_response(self, response):
        """Gestisce la risposta dell'AI."""
        try:
            # Aggiungi la risposta all'area di lavoro
            if hasattr(self, 'work_area') and self.work_area:
                current_text_result = self.safe_call(self.work_area, 'toPlainText', '')
                current_text = str(current_text_result) if current_text_result else ""
                if current_text:
                    new_text = current_text + f"\n\n🤖 Risposta AI:\n{response}"
                else:
                    new_text = f"🤖 Risposta AI:\n{response}"

                self.safe_call(self.work_area, 'setText', new_text)

            self.show_status_message(f"Risposta AI ricevuta: {response[:50]}...")
            self.logger.info(f"Risposta AI: {response[:100]}...")

        except Exception as e:
            self.logger.error(f"Errore nella risposta AI: {e}")

    def on_ai_error(self, message):
        """Gestisce gli errori dell'AI."""
        try:
            self.logger.error(f"Errore AI: {message}")
            self.show_status_message(f"Errore AI: {message}", error=True)

        except Exception as e:
            self.logger.error(f"Errore nella gestione dell'errore AI: {e}")

    def on_voice_recognized(self, text):
        """Gestisce il testo riconosciuto dalla voce."""
        try:
            # Aggiungi il testo all'area di lavoro
            if hasattr(self, 'work_area') and self.work_area:
                current_text_result = self.safe_call(self.work_area, 'toPlainText', '')
                current_text = str(current_text_result) if current_text_result else ""
                if current_text:
                    new_text = current_text + f"\n\n🎤 Testo Riconosciuto:\n{str(text)}"
                else:
                    new_text = f"🎤 Testo Riconosciuto:\n{str(text)}"

                self.safe_call(self.work_area, 'setText', new_text)

            # Mostra notifica
            self.show_status_message(f"Testo riconosciuto: {text[:50]}...")

            self.logger.info(f"Testo riconosciuto: {text}")

        except Exception as e:
            self.logger.error(f"Errore nella gestione testo riconosciuto: {e}")

    def on_voice_error(self, message):
        """Gestisce gli errori del riconoscimento vocale."""
        try:
            self.logger.error(f"Errore riconoscimento vocale: {message}")
            self.show_status_message(f"Errore vocale: {message}", error=True)

        except Exception as e:
            self.logger.error(f"Errore nella gestione errore vocale: {e}")

    def closeEvent(self, a0):
        """Gestisce la chiusura dell'applicazione."""
        try:
            # Ferma tutti i thread in modo sicuro
            if self.video_thread and hasattr(self.video_thread, 'isRunning') and self.video_thread.isRunning():
                if hasattr(self.video_thread, 'stop'):
                    self.video_thread.stop()
            if self.ollama_thread and hasattr(self.ollama_thread, 'isRunning') and self.ollama_thread.isRunning():
                if hasattr(self.ollama_thread, 'stop'):
                    self.ollama_thread.stop()
            if hasattr(self, 'speech_thread') and self.speech_thread and hasattr(self.speech_thread, 'isRunning') and self.speech_thread.isRunning():
                if hasattr(self.speech_thread, 'stop'):
                    self.speech_thread.stop()

            # Salva le impostazioni
            AppConfig.save_settings(self.settings)

            self.logger.info("Applicazione chiusa correttamente")
            if a0:
                a0.accept()
        except Exception as e:
            self.logger.error(f"Errore nella chiusura dell'applicazione: {e}")
            if a0:
                a0.accept()

    def process_with_ai(self, text):
        """Elabora il testo con l'AI."""
        try:
            from ollama_manager import OllamaThread

            # Avvia il thread AI
            self.ollama_thread = OllamaThread(text, self.settings.get('ollama_model', ''))
            # Connetti i segnali in modo sicuro
            if hasattr(self.ollama_thread, 'response_ready'):
                self.ollama_thread.response_ready.connect(self.on_ai_response)
            if hasattr(self.ollama_thread, 'error_occurred'):
                self.ollama_thread.error_occurred.connect(self.on_ai_error)
            # Avvia il thread
            if hasattr(self.ollama_thread, 'start'):
                self.ollama_thread.start()

            self.logger.info(f"Elaborazione AI avviata per testo: {text[:50]}...")

        except Exception as e:
            self.logger.error(f"Errore nell'elaborazione AI: {e}")
            QMessageBox.critical(self, "Errore AI", f"Errore nell'elaborazione AI:\n{str(e)}")

    def start_voice_recording(self):
        """Avvia la registrazione vocale."""
        try:
            from speech_recognition_manager import SpeechRecognitionThread

            # Verifica che sia configurato un modello Vosk
            vosk_model = self.settings.get('vosk_model', '')
            if not vosk_model:
                QMessageBox.information(self, "Configurazione Vocale",
                    "Per utilizzare il riconoscimento vocale, configura prima un modello Vosk:\n\n"
                    "1. Apri Impostazioni (⚙️)\n"
                    "2. Vai su '🎤 Voce'\n"
                    "3. Seleziona un modello Vosk\n"
                    "4. Salva le impostazioni")
                return

            # Avvia il thread di riconoscimento
            self.speech_rec_thread = SpeechRecognitionThread(vosk_model)
            # Connetti i segnali in modo sicuro
            if hasattr(self.speech_rec_thread, 'recognized_text'):
                self.speech_rec_thread.recognized_text.connect(self.on_voice_recognized)
            if hasattr(self.speech_rec_thread, 'error_occurred'):
                self.speech_rec_thread.error_occurred.connect(self.on_voice_error)
            if hasattr(self.speech_rec_thread, 'stopped_by_silence'):
                self.speech_rec_thread.stopped_by_silence.connect(self.on_voice_stopped)

            # Avvia il thread
            if hasattr(self.speech_rec_thread, 'start'):
                self.speech_rec_thread.start()
            self.is_listening = True
            if hasattr(self, 'voice_button'):
                self.voice_button.setText("🎤 Registrazione... (clicca per fermare)")
                self.voice_button.setStyleSheet("background-color: #e74c3c; color: white;")

            self.logger.info("Registrazione vocale avviata")

        except Exception as e:
            self.logger.error(f"Errore nell'avvio registrazione: {e}")
            QMessageBox.critical(self, "Errore", f"Impossibile avviare la registrazione:\n{str(e)}")

    def stop_voice_recording(self):
        """Ferma la registrazione vocale."""
        try:
            if self.speech_rec_thread and hasattr(self.speech_rec_thread, 'isRunning') and self.speech_rec_thread.isRunning():
                if hasattr(self.speech_rec_thread, 'stop'):
                    self.speech_rec_thread.stop()
                self.speech_rec_thread = None

            self.is_listening = False
            if hasattr(self, 'voice_button'):
                self.voice_button.setText("🎤 Voce")
                self.voice_button.setStyleSheet("")

            self.logger.info("Registrazione vocale fermata")

        except Exception as e:
            self.logger.error(f"Errore nel fermare registrazione: {e}")

    def on_voice_stopped(self):
        """Gestisce quando la registrazione si ferma per silenzio."""
        try:
            self.is_listening = False
            if hasattr(self, 'voice_button'):
                self.voice_button.setText("🎤 Voce")
                self.voice_button.setStyleSheet("")
            self.show_status_message("Registrazione fermata (silenzio rilevato)")

            self.logger.info("Registrazione fermata per silenzio")

        except Exception as e:
            self.logger.error(f"Errore nella gestione stop registrazione: {e}")

    def show_status_message(self, message, error=False):
        """Mostra un messaggio di stato."""
        try:
            # Per ora, mostriamo il messaggio nei log
            if error:
                self.logger.error(f"Status: {message}")
            else:
                self.logger.info(f"Status: {message}")
        except Exception as e:
            self.logger.error(f"Errore nella visualizzazione messaggio: {e}")

    def handle_hands_button(self):
        """Gestisce il pulsante Mani."""
        try:
            # Attiva/disattiva il rilevamento mani
            current_enabled = self.settings.get('hand_detection', True)
            new_enabled = not current_enabled

            self.settings['hand_detection'] = new_enabled
            AppConfig.save_settings(self.settings)

            if new_enabled:
                if hasattr(self, 'hands_button'):
                    self.hands_button.setText("✋ Mani ✅")
                self.show_status_message("Rilevamento mani attivato")
            else:
                if hasattr(self, 'hands_button'):
                    self.hands_button.setText("✋ Mani ❌")
                self.show_status_message("Rilevamento mani disattivato")

            self.logger.info(f"Rilevamento mani: {'attivato' if new_enabled else 'disattivato'}")

        except Exception as e:
            self.logger.error(f"Errore nel pulsante mani: {e}")

    def handle_face_button(self):
        """Gestisce il pulsante Faccia."""
        try:
            # Attiva/disattiva il rilevamento faccia
            current_enabled = self.settings.get('face_detection', True)
            new_enabled = not current_enabled

            self.settings['face_detection'] = new_enabled
            AppConfig.save_settings(self.settings)

            if new_enabled:
                if hasattr(self, 'face_button'):
                    self.face_button.setText("😊 Faccia ✅")
                self.show_status_message("Rilevamento faccia attivato")
            else:
                if hasattr(self, 'face_button'):
                    self.face_button.setText("😊 Faccia ❌")
                self.show_status_message("Rilevamento faccia disattivato")

            self.logger.info(f"Rilevamento faccia: {'attivato' if new_enabled else 'disattivato'}")

        except Exception as e:
            self.logger.error(f"Errore nel pulsante faccia: {e}")

    def handle_clean_button(self):
        """Gestisce il pulsante Pulisci."""
        try:
            reply = QMessageBox.question(
                self, "Conferma Pulizia",
                "Sei sicuro di voler pulire tutto il contenuto?\n\n"
                "Questa azione eliminerà:\n"
                "• Tutto il testo nelle aree di lavoro\n"
                "• Tutti i pensierini creati\n"
                "• I risultati del rilevamento",
                QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No
            )

            if reply == QMessageBox.StandardButton.Yes:
                # Pulisci le aree di lavoro
                if hasattr(self, 'work_area') and self.work_area:
                    self.safe_call(self.work_area, 'clear')

                # Rimuovi tutti i pensierini
                self.clear_all_pensierini()

                # Ferma eventuali registrazioni
                if self.is_listening:
                    self.stop_voice_recording()

                self.show_status_message("Contenuto pulito completamente")
                self.logger.info("Contenuto pulito dall'utente")

        except Exception as e:
            self.logger.error(f"Errore nel pulsante pulisci: {e}")

    def clear_all_pensierini(self):
        """Rimuove tutti i pensierini."""
        try:
            # Rimuovi tutti i widget dalla layout
            if hasattr(self, 'workspace_layout') and self.workspace_layout:
                while self.workspace_layout.count():
                    item = self.workspace_layout.takeAt(0)
                    if item and item.widget() and hasattr(item.widget(), 'deleteLater'):
                        item.widget().deleteLater()

            self.logger.info("Tutti i pensierini rimossi")

        except Exception as e:
            self.logger.error(f"Errore nella rimozione pensierini: {e}")

    def add_text_widget(self):
        """Aggiunge un nuovo widget di testo trascinabile."""
        try:
            text, ok = QInputDialog.getText(self, "Nuovo Pensierino", "Inserisci il testo:")
            if ok and text:
                if DraggableTextWidget:
                    widget = DraggableTextWidget(text, self.settings)
                    if hasattr(self, 'workspace_layout') and self.workspace_layout:
                        self.workspace_layout.addWidget(widget)
                    self.text_widgets.append(widget)
                    self.logger.info(f"Nuovo widget di testo aggiunto: {text[:50]}...")
                else:
                    self.logger.error("DraggableTextWidget non disponibile")
        except Exception as e:
            self.logger.error(f"Errore nell'aggiunta del widget di testo: {e}")


# ===========================================
# FUNZIONE PRINCIPALE
# ===========================================

def main():
    """Funzione principale dell'applicazione."""
    try:
        app = QApplication(sys.argv)
        app.setStyle('Fusion')

        # Imposta l'icona dell'applicazione se disponibile
        if os.path.exists("icon.png"):
            app.setWindowIcon(QIcon("icon.png"))

        # Crea e mostra la finestra principale
        window = MainWindow()
        window.show()

        # Avvia l'applicazione
        sys.exit(app.exec())

    except Exception as e:
        logger.critical(f"Errore critico nell'avvio dell'applicazione: {e}")
        sys.exit(1)

if __name__ == "__main__":
    main()
