# 📁 ICO - Icone dell'Applicazione

Questa cartella contiene tutte le icone e le risorse grafiche dell'Assistente DSA.

## 🎨 Tipi di Icone

### Icone dell'Applicazione
- `icon.png` - Icona principale dell'applicazione (256x256px)
- `icon.ico` - Icona per Windows (formato ICO)
- `icon.icns` - Icona per macOS (formato ICNS)

### Icone dei Pulsanti
- `tts_icon.png` - Icona per la sintesi vocale
- `ai_icon.png` - Icona per l'intelligenza artificiale
- `voice_icon.png` - Icona per il riconoscimento vocale
- `settings_icon.png` - Icona per le impostazioni
- `save_icon.png` - Icona per salvare
- `open_icon.png` - Icona per aprire file

### Icone di Stato
- `success_icon.png` - Icona per operazioni riuscite
- `error_icon.png` - Icona per errori
- `warning_icon.png` - Icona per avvisi
- `info_icon.png` - Icona per informazioni

## 📐 Dimensioni Raccomandate

### Icone Principali
- **256x256px** - Icona principale dell'applicazione
- **128x128px** - Icona per la barra delle applicazioni
- **64x64px** - Icona per i menu
- **32x32px** - Icona per le toolbar

### Icone dei Pulsanti
- **48x48px** - Pulsanti grandi
- **32x32px** - Pulsanti medi
- **24x24px** - Pulsanti piccoli
- **16x16px** - Icone molto piccole

## 🎨 Formati Supportati

- **PNG** - Formato principale (consigliato)
- **SVG** - Per scalabilità (se supportato dall'applicazione)
- **ICO** - Per Windows
- **ICNS** - Per macOS

## 📝 Linee Guida per le Icone

### Design
- **Stile Coerente**: Tutte le icone dovrebbero seguire lo stesso stile
- **Colori Consistenti**: Usare la palette di colori dell'applicazione
- **Semplicità**: Icone chiare e facilmente riconoscibili
- **Scalabilità**: Progettare per diverse dimensioni

### Contenuto
- **Significato Chiaro**: Ogni icona deve rappresentare chiaramente la sua funzione
- **Nessun Testo**: Evitare testo nelle icone
- **Margini Appropriati**: Lasciare spazio sufficiente intorno al contenuto

### Accessibilità
- **Contrasto**: Buona visibilità su sfondi chiari e scuri
- **Dimensione**: Icone sufficientemente grandi per essere visibili
- **Colore**: Non basarsi solo sul colore per la comprensione

## 🔧 Utilizzo nell'Applicazione

### PyQt6
```python
from PyQt6.QtGui import QIcon

# Icona principale dell'applicazione
app.setWindowIcon(QIcon("ICO/icon.png"))

# Icona per un pulsante
button.setIcon(QIcon("ICO/tts_icon.png"))
```

### QML
```qml
import QtQuick 2.15

Image {
    source: "ICO/icon.png"
    width: 32
    height: 32
}

Button {
    icon.source: "ICO/settings_icon.png"
}
```

## 📂 Struttura Organizzativa

```
ICO/
├── app/           # Icone dell'applicazione
│   ├── icon.png
│   ├── icon.ico
│   └── icon.icns
├── buttons/       # Icone dei pulsanti
│   ├── tts_icon.png
│   ├── ai_icon.png
│   └── settings_icon.png
├── status/        # Icone di stato
│   ├── success_icon.png
│   ├── error_icon.png
│   └── warning_icon.png
└── README.md      # Questa documentazione
```

## 🎨 Palette di Colori

### Colori Principali
- **Primario**: `#4a90e2` (Blu)
- **Secondario**: `#f39c12` (Arancione)
- **Successo**: `#27ae60` (Verde)
- **Errore**: `#e74c3c` (Rosso)
- **Avviso**: `#f39c12` (Arancione)

### Colori di Sfondo
- **Chiaro**: `#f8f9fa`
- **Scuro**: `#2b2b2b`
- **Testo Chiaro**: `#2c3e50`
- **Testo Scuro**: `#ffffff`

## 📝 Note

- **Attualmente Vuota**: Questa cartella è pronta per ospitare le icone
- **Scalabile**: La struttura supporta l'aggiunta di nuove icone
- **Organizzata**: Icone raggruppate per categoria
- **Documentata**: Ogni icona dovrebbe avere una descrizione

## 🚀 Prossimi Passi

1. **Aggiungere Icone**: Inserire le icone dell'applicazione
2. **Ottimizzare**: Ridimensionare per diverse risoluzioni
3. **Testare**: Verificare la visibilità su diversi temi
4. **Documentare**: Aggiungere descrizioni per ogni icona

---

**La cartella ICO è pronta per ospitare tutte le risorse grafiche dell'applicazione!** 🎨✨