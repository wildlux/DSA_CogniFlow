#!/usr/bin/env python3
"""
Script di test per verificare il funzionamento del rilevamento di mani e faccia
"""

import cv2
import numpy as np
import logging

# Configurazione logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

class TestVideoThread:
    """Classe di test per il rilevamento video"""

    def __init__(self):
        self.face_detection_enabled = True
        self.hand_detection_enabled = True

        # Carica i classificatori Haar per il rilevamento
        try:
            cascade_path = '/home/wildlux/.local/lib/python3.13/site-packages/cv2/data/haarcascade_frontalface_default.xml'
            self.face_cascade = cv2.CascadeClassifier(cascade_path)
            if self.face_cascade.empty():
                logging.warning("File Haar cascade per il rilevamento facciale non trovato.")
                self.face_cascade = None
        except Exception as e:
            logging.error(f"Errore nel caricamento del cascade Haar: {e}")
            self.face_cascade = None

        # Per le mani, usiamo un approccio alternativo basato sulla pelle
        self.lower_skin = np.array([0, 20, 70], dtype=np.uint8)
        self.upper_skin = np.array([20, 255, 255], dtype=np.uint8)

    def detect_faces(self, frame):
        """Rileva le facce nel frame e disegna rettangoli."""
        if self.face_cascade is None:
            cv2.putText(frame, 'Rilevamento faccia non disponibile', (10, 30),
                       cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 0, 255), 2)
            return frame

        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        faces = self.face_cascade.detectMultiScale(gray, 1.1, 4)

        for (x, y, w, h) in faces:
            cv2.rectangle(frame, (x, y), (x+w, y+h), (255, 0, 0), 2)
            cv2.putText(frame, 'Faccia', (x, y-10), cv2.FONT_HERSHEY_SIMPLEX, 0.9, (255, 0, 0), 2)

        return frame

    def detect_hands(self, frame):
        """Rileva le mani nel frame usando il colore della pelle."""
        hsv = cv2.cvtColor(frame, cv2.COLOR_BGR2HSV)
        mask = cv2.inRange(hsv, self.lower_skin, self.upper_skin)

        # Trova i contorni nell'immagine binaria
        contours, _ = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

        for contour in contours:
            area = cv2.contourArea(contour)
            if area > 5000:  # Filtra contorni troppo piccoli
                x, y, w, h = cv2.boundingRect(contour)
                cv2.rectangle(frame, (x, y), (x+w, y+h), (0, 255, 0), 2)
                cv2.putText(frame, 'Mano', (x, y-10), cv2.FONT_HERSHEY_SIMPLEX, 0.9, (0, 255, 0), 2)

        return frame

    def run_test(self):
        """Esegue il test del rilevamento"""
        cap = cv2.VideoCapture(0)
        if not cap.isOpened():
            logging.error("Errore: Impossibile aprire la webcam.")
            return

        logging.info("Webcam avviata. Avvio test rilevamento...")

        frame_count = 0
        max_frames = 100  # Test per 100 frame

        while frame_count < max_frames:
            ret, frame = cap.read()
            if ret:
                frame = cv2.flip(frame, 1)  # Flip orizzontale

                # Applica il rilevamento
                if self.face_detection_enabled:
                    frame = self.detect_faces(frame)
                if self.hand_detection_enabled:
                    frame = self.detect_hands(frame)

                # Mostra il frame
                cv2.imshow('Test Rilevamento Mani e Faccia', frame)

                frame_count += 1

                # Esci se premuto 'q'
                if cv2.waitKey(1) & 0xFF == ord('q'):
                    break
            else:
                logging.error("Errore di lettura del frame dalla webcam.")
                break

        cap.release()
        cv2.destroyAllWindows()
        logging.info("Test completato.")

if __name__ == '__main__':
    test = TestVideoThread()
    test.run_test()