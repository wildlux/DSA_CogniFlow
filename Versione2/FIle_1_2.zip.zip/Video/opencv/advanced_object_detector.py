# advanced_object_detector.py

import cv2
import numpy as np
import logging
from typing import Dict, List, Tuple, Optional, Any

# Import condizionale per gestire errori di import
try:
    from person_detector import PersonDetector
    from hand_palm_detector import HandPalmDetector
    from base_detector import BaseDetector
except ImportError:
    # Fallback se gli import falliscono
    class BaseDetector:
        def __init__(self, enabled=False):
            self.enabled = enabled

    class PersonDetector(BaseDetector):
        def detect(self, frame):
            return False, []

    class HandPalmDetector(BaseDetector):
        def detect(self, frame):
            return False, []

class AdvancedObjectDetector:
    """
    Sistema avanzato di rilevamento di oggetti che combina:
    - Rilevamento di persone con parti del corpo (occhi, bocca, naso)
    - Rilevamento di mani con visualizzazione del palmo
    - Gestione di riflessi/occhiali
    - Sistema modulare e configurabile
    """

    def __init__(self, config: Optional[Dict[str, Any]] = None):
        """
        Inizializza il sistema di rilevamento avanzato.

        Args:
            config: Configurazione del sistema
        """
        self.logger = logging.getLogger("AdvancedObjectDetector")

        # Configurazione di default
        self.default_config = {
            'person_detection': True,
            'hand_detection': True,
            'show_palm': True,
            'show_facial_features': True,
            'handle_glasses': True,
            'min_confidence': 0.5,
            'max_objects': 10
        }

        self.config = {**self.default_config, **(config or {})}

        # Inizializza i rilevatori
        self.person_detector = PersonDetector(enabled=self.config.get('person_detection', True))
        self.hand_detector = HandPalmDetector(enabled=self.config.get('hand_detection', True))

        # Stato del sistema
        self.detected_objects = []
        self.frame_count = 0

        self.logger.info("Sistema di rilevamento avanzato inizializzato")

    def detect_objects(self, frame) -> Tuple[bool, List[Dict[str, Any]]]:
        """
        Rileva oggetti nel frame (persone e mani).

        Args:
            frame: Il frame da analizzare

        Returns:
            Tuple[bool, List[Dict[str, Any]]]: (rilevamento_successo, lista_oggetti)
        """
        try:
            self.frame_count += 1
            detected_objects = []

            # Rilevamento persone
            if self.config.get('person_detection', True):
                person_success, persons = self.person_detector.detect(frame)
                if person_success:
                    for person in persons:
                        if person.get('confidence', 0) >= self.config.get('min_confidence', 0.5):
                            person['type'] = 'person'
                            detected_objects.append(person)

            # Rilevamento mani
            if self.config.get('hand_detection', True):
                hand_success, hands = self.hand_detector.detect(frame)
                if hand_success:
                    for hand in hands:
                        if hand.get('confidence', 0) >= self.config.get('min_confidence', 0.5):
                            hand['type'] = 'hand'
                            detected_objects.append(hand)

            # Limita il numero di oggetti rilevati
            max_objects = self.config.get('max_objects', 10)
            detected_objects = detected_objects[:max_objects]

            self.detected_objects = detected_objects
            success = len(detected_objects) > 0

            if success:
                self.logger.debug(f"Frame {self.frame_count}: rilevati {len(detected_objects)} oggetti")

            return success, detected_objects

        except Exception as e:
            self.logger.error(f"Errore nel rilevamento oggetti: {e}")
            return False, []

    def draw_detections(self, frame, detections: Optional[List[Dict[str, Any]]] = None):
        """
        Disegna le rilevazioni sul frame.

        Args:
            frame: Il frame su cui disegnare
            detections: Lista di rilevazioni (se None usa quelle dell'ultimo rilevamento)
        """
        try:
            if detections is None:
                detections = self.detected_objects

            for detection in detections:
                obj_type = detection.get('type', 'unknown')

                if obj_type == 'person':
                    self.person_detector.draw_person_analysis(frame, detection)
                elif obj_type == 'hand':
                    self.hand_detector.draw_hand_palm_analysis(frame, detection)

            # Mostra statistiche
            self._draw_statistics(frame, detections)

        except Exception as e:
            self.logger.error(f"Errore nel disegno rilevazioni: {e}")

    def _draw_statistics(self, frame, detections):
        """Disegna le statistiche sul frame."""
        try:
            height, width = frame.shape[:2]

            # Conta i tipi di oggetti
            person_count = sum(1 for d in detections if d.get('type') == 'person')
            hand_count = sum(1 for d in detections if d.get('type') == 'hand')

            # Disegna statistiche
            stats_text = f"Persone: {person_count} | Mani: {hand_count} | Frame: {self.frame_count}"
            cv2.putText(frame, stats_text, (10, height - 10),
                       cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255, 255, 255), 2)

            # Mostra configurazione attiva
            config_text = f"Persona: {'ON' if self.config.get('person_detection') else 'OFF'} | "
            config_text += f"Mano: {'ON' if self.config.get('hand_detection') else 'OFF'}"
            cv2.putText(frame, config_text, (10, height - 35),
                       cv2.FONT_HERSHEY_SIMPLEX, 0.5, (200, 200, 200), 1)

        except Exception as e:
            self.logger.error(f"Errore nel disegno statistiche: {e}")

    def get_detected_persons(self) -> List[Dict[str, Any]]:
        """Ottiene la lista delle persone rilevate."""
        return [obj for obj in self.detected_objects if obj.get('type') == 'person']

    def get_detected_hands(self) -> List[Dict[str, Any]]:
        """Ottiene la lista delle mani rilevate."""
        return [obj for obj in self.detected_objects if obj.get('type') == 'hand']

    def get_hand_gestures(self) -> List[Dict[str, Any]]:
        """Ottiene i gesti delle mani rilevate."""
        gestures = []
        for hand in self.get_detected_hands():
            gesture = self.hand_detector.get_hand_gesture(hand)
            gestures.append({
                'hand': hand,
                'gesture': gesture,
                'confidence': hand.get('confidence', 0)
            })
        return gestures

    def update_config(self, new_config: Dict[str, Any]):
        """Aggiorna la configurazione del sistema."""
        try:
            self.config.update(new_config)

            # Aggiorna i rilevatori
            if 'person_detection' in new_config:
                self.person_detector.set_enabled(new_config['person_detection'])

            if 'hand_detection' in new_config:
                self.hand_detector.set_enabled(new_config['hand_detection'])

            self.logger.info(f"Configurazione aggiornata: {new_config}")

        except Exception as e:
            self.logger.error(f"Errore nell'aggiornamento configurazione: {e}")

    def get_config(self) -> Dict[str, Any]:
        """Ottiene la configurazione corrente."""
        return self.config.copy()

    def reset(self):
        """Resetta lo stato del sistema."""
        self.detected_objects = []
        self.frame_count = 0
        self.logger.info("Sistema di rilevamento resettato")

    def get_system_info(self) -> Dict[str, Any]:
        """Ottiene informazioni sul sistema."""
        return {
            'frame_count': self.frame_count,
            'detected_objects': len(self.detected_objects),
            'person_detector_enabled': self.person_detector.is_enabled(),
            'hand_detector_enabled': self.hand_detector.is_enabled(),
            'config': self.config
        }


class ObjectDetectionManager:
    """
    Manager per il sistema di rilevamento oggetti avanzato.
    Gestisce l'integrazione con il sistema principale.
    """

    def __init__(self):
        self.logger = logging.getLogger("ObjectDetectionManager")
        self.detector = None
        self.is_initialized = False

    def initialize(self, config: Optional[Dict[str, Any]] = None) -> bool:
        """Inizializza il sistema di rilevamento."""
        try:
            self.detector = AdvancedObjectDetector(config)
            self.is_initialized = True
            self.logger.info("Sistema di rilevamento oggetti inizializzato")
            return True

        except Exception as e:
            self.logger.error(f"Errore nell'inizializzazione: {e}")
            return False

    def process_frame(self, frame) -> Tuple[bool, List[Dict[str, Any]]]:
        """Processa un frame per il rilevamento di oggetti."""
        if not self.is_initialized or self.detector is None:
            return False, []

        try:
            return self.detector.detect_objects(frame)

        except Exception as e:
            self.logger.error(f"Errore nell'elaborazione frame: {e}")
            return False, []

    def draw_results(self, frame, detections: Optional[List[Dict[str, Any]]] = None):
        """Disegna i risultati del rilevamento sul frame."""
        if not self.is_initialized or self.detector is None:
            return

        try:
            self.detector.draw_detections(frame, detections)

        except Exception as e:
            self.logger.error(f"Errore nel disegno risultati: {e}")

    def get_detected_objects(self) -> List[Dict[str, Any]]:
        """Ottiene gli oggetti rilevati."""
        if self.detector:
            return self.detector.detected_objects
        return []

    def update_configuration(self, config: Dict[str, Any]):
        """Aggiorna la configurazione."""
        if self.detector:
            self.detector.update_config(config)

    def get_statistics(self) -> Dict[str, Any]:
        """Ottiene le statistiche del sistema."""
        if self.detector:
            return self.detector.get_system_info()
        return {}


# Istanza globale del manager
object_detection_manager = ObjectDetectionManager()

def get_object_detection_manager() -> ObjectDetectionManager:
    """Ottiene l'istanza globale del manager."""
    return object_detection_manager

def initialize_object_detection(config: Optional[Dict[str, Any]] = None) -> bool:
    """Inizializza il sistema di rilevamento oggetti."""
    return object_detection_manager.initialize(config)

def process_frame_for_objects(frame) -> Tuple[bool, List[Dict[str, Any]]]:
    """Processa un frame per rilevare oggetti."""
    return object_detection_manager.process_frame(frame)

def draw_object_detections(frame, detections: Optional[List[Dict[str, Any]]] = None):
    """Disegna le rilevazioni di oggetti sul frame."""
    object_detection_manager.draw_results(frame, detections)