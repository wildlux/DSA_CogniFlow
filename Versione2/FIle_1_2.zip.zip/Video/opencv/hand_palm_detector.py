# hand_palm_detector.py

import cv2
import numpy as np
import math
import logging
from typing import Dict, List, Tuple, Optional, Any
from base_detector import BaseDetector

class HandPalmDetector(BaseDetector):
    """
    Rilevatore avanzato di mani con visualizzazione del palmo.
    Implementa il sistema di rilevamento delle mani con visualizzazione
    del palmo come mostrato nel video di riferimento.
    """

    def __init__(self, enabled: bool = False):
        super().__init__(enabled)
        self.hands_data = []
        self.palm_contours = []
        self.finger_tips = []
        self.logger = logging.getLogger("HandPalmDetector")

        # Parametri per il rilevamento delle mani
        self.lower_skin = np.array([0, 20, 70], dtype=np.uint8)
        self.upper_skin = np.array([20, 255, 255], dtype=np.uint8)

        # Parametri per il rilevamento del palmo
        self.min_hand_area = 5000
        self.max_hand_area = 50000
        self.palm_center_threshold = 0.3  # Soglia per identificare il centro del palmo

    def detect(self, frame):
        """Rileva le mani e analizza i palmi."""
        if not self.enabled:
            return False, []

        if not self.validate_frame(frame):
            return False, []

        try:
            # Rileva le mani
            hands = self._detect_hands(frame)
            if not hands:
                return False, []

            # Analizza ogni mano per trovare il palmo
            analyzed_hands = []
            for hand_contour in hands:
                hand_data = self._analyze_hand_palm(frame, hand_contour)
                if hand_data:
                    analyzed_hands.append(hand_data)

            detected = len(analyzed_hands) > 0
            if detected:
                self.logger.debug(f"Rilevate {len(analyzed_hands)} mani con palmo")

            return detected, analyzed_hands

        except Exception as e:
            self.logger.error(f"Errore nel rilevamento mani: {e}")
            return False, []

    def _detect_hands(self, frame) -> List[np.ndarray]:
        """Rileva le mani nel frame usando il colore della pelle."""
        try:
            # Converti in HSV
            hsv = cv2.cvtColor(frame, cv2.COLOR_BGR2HSV)

            # Crea maschera per il colore della pelle
            mask = cv2.inRange(hsv, self.lower_skin, self.upper_skin)

            # Operazioni morfologiche per pulire la maschera
            kernel = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (7, 7))
            mask = cv2.morphologyEx(mask, cv2.MORPH_CLOSE, kernel)
            mask = cv2.morphologyEx(mask, cv2.MORPH_OPEN, kernel)

            # Trova i contorni
            contours, _ = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

            # Filtra i contorni per dimensione (mani)
            hand_contours = []
            for contour in contours:
                area = cv2.contourArea(contour)
                if self.min_hand_area < area < self.max_hand_area:
                    # Verifica che sia una forma simile a una mano
                    if self._is_hand_shape(contour):
                        hand_contours.append(contour)

            return hand_contours

        except Exception as e:
            self.logger.error(f"Errore nel rilevamento base delle mani: {e}")
            return []

    def _is_hand_shape(self, contour) -> bool:
        """Verifica se un contorno ha la forma di una mano."""
        try:
            # Calcola il perimetro e area
            perimeter = cv2.arcLength(contour, True)
            area = cv2.contourArea(contour)

            if perimeter == 0:
                return False

            # Calcola la compattezza (circularity)
            circularity = 4 * np.pi * area / (perimeter * perimeter)

            # Calcola il bounding box
            x, y, w, h = cv2.boundingRect(contour)
            aspect_ratio = w / h if h > 0 else 0

            # Una mano tipica ha:
            # - Bassa compattezza (non circolare)
            # - Aspect ratio ragionevole
            # - Almeno 5 punti nel contorno
            if (circularity < 0.8 and
                0.5 < aspect_ratio < 2.0 and
                len(contour) >= 5):
                return True

            return False

        except Exception as e:
            self.logger.error(f"Errore nella verifica forma mano: {e}")
            return False

    def _analyze_hand_palm(self, frame, contour) -> Optional[Dict[str, Any]]:
        """Analizza una mano per trovare il palmo e le dita."""
        try:
            # Trova il centro della mano
            moments = cv2.moments(contour)
            if moments['m00'] == 0:
                return None

            center_x = int(moments['m10'] / moments['m00'])
            center_y = int(moments['m01'] / moments['m00'])

            # Trova i punti estremi (dita)
            finger_tips = self._find_finger_tips(contour, center_x, center_y)

            # Trova il contorno del palmo (escludendo le dita)
            palm_contour = self._extract_palm_contour(contour, finger_tips, center_x, center_y)

            # Calcola le proprietà del palmo
            palm_properties = self._calculate_palm_properties(palm_contour, center_x, center_y)

            # Determina l'orientamento della mano
            orientation = self._determine_hand_orientation(finger_tips, center_x, center_y)

            hand_data = {
                'contour': contour,
                'center': (center_x, center_y),
                'finger_tips': finger_tips,
                'palm_contour': palm_contour,
                'palm_properties': palm_properties,
                'orientation': orientation,
                'confidence': self._calculate_hand_confidence(finger_tips, palm_contour)
            }

            return hand_data

        except Exception as e:
            self.logger.error(f"Errore nell'analisi palmo mano: {e}")
            return None

    def _find_finger_tips(self, contour, center_x, center_y) -> List[Tuple[int, int]]:
        """Trova le punte delle dita usando la convessità."""
        try:
            # Trova l'hull convesso
            hull = cv2.convexHull(contour, returnPoints=False)
            hull_points = cv2.convexHull(contour, returnPoints=True)

            # Trova i difetti di convessità
            defects = cv2.convexityDefects(contour, hull)

            finger_tips = []

            if defects is not None:
                for i in range(defects.shape[0]):
                    s, e, f, d = defects[i, 0]
                    start = tuple(contour[s][0])
                    end = tuple(contour[e][0])
                    far = tuple(contour[f][0])

                    # Calcola la profondità del difetto
                    a = math.sqrt((end[0] - start[0])**2 + (end[1] - start[1])**2)
                    b = math.sqrt((far[0] - start[0])**2 + (far[1] - start[1])**2)
                    c = math.sqrt((end[0] - far[0])**2 + (end[1] - far[1])**2)

                    if a > 0:
                        area = math.sqrt(max(0, (a + b + c) * (b + c - a) * (c + a - b) * (a + b - c)))
                        distance = (2 * area) / a if a > 0 else 0

                        # Se la profondità è significativa, potrebbe essere tra due dita
                        if distance > 20:
                            # Considera i punti dell'hull come potenziali punte delle dita
                            for point in hull_points:
                                px, py = point[0]
                                # Verifica che sia sufficientemente lontano dal centro del palmo
                                distance_from_center = math.sqrt(
                                    (px - center_x)**2 + (py - center_y)**2
                                )
                                if distance_from_center > 30:  # Lontano dal centro
                                    finger_tips.append((px, py))

            # Se non abbiamo trovato punte con i difetti, usa i punti estremi dell'hull
            if len(finger_tips) < 3:
                finger_tips = []
                for point in hull_points:
                    px, py = point[0]
                    distance_from_center = math.sqrt(
                        (px - center_x)**2 + (py - center_y)**2
                    )
                    if distance_from_center > 40:  # Lontano dal centro
                        finger_tips.append((px, py))

            # Rimuovi duplicati e limita a 5 dita max
            unique_tips = []
            for tip in finger_tips:
                # Verifica che non sia troppo vicino ad altri punti
                is_unique = True
                for existing_tip in unique_tips:
                    distance = math.sqrt(
                        (tip[0] - existing_tip[0])**2 + (tip[1] - existing_tip[1])**2
                    )
                    if distance < 20:  # Troppo vicino
                        is_unique = False
                        break
                if is_unique:
                    unique_tips.append(tip)

            return unique_tips[:5]  # Max 5 dita

        except Exception as e:
            self.logger.error(f"Errore nella ricerca punte dita: {e}")
            return []

    def _extract_palm_contour(self, hand_contour, finger_tips, center_x, center_y):
        """Estrae il contorno del palmo escludendo le dita."""
        try:
            if len(finger_tips) < 3:
                return hand_contour  # Se poche dita, usa il contorno originale

            # Crea una maschera per il palmo
            palm_mask = np.zeros_like(cv2.cvtColor(
                cv2.drawContours(np.zeros((480, 640, 3), dtype=np.uint8),
                               [hand_contour], -1, (255, 255, 255), -1),
                cv2.COLOR_BGR2GRAY
            ))

            # Rimuovi le aree delle dita dalla maschera
            for tip in finger_tips:
                cv2.circle(palm_mask, tip, 25, 0, -1)  # Rimuovi area intorno alla punta

            # Trova il contorno del palmo rimanente
            palm_contours, _ = cv2.findContours(palm_mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

            if palm_contours:
                # Trova il contorno più grande
                largest_contour = max(palm_contours, key=cv2.contourArea)
                return largest_contour

            return hand_contour

        except Exception as e:
            self.logger.error(f"Errore nell'estrazione contorno palmo: {e}")
            return hand_contour

    def _calculate_palm_properties(self, palm_contour, center_x, center_y) -> Dict[str, Any]:
        """Calcola le proprietà del palmo."""
        try:
            # Area del palmo
            palm_area = cv2.contourArea(palm_contour)

            # Perimetro del palmo
            palm_perimeter = cv2.arcLength(palm_contour, True)

            # Bounding box del palmo
            x, y, w, h = cv2.boundingRect(palm_contour)

            # Centroide del palmo
            moments = cv2.moments(palm_contour)
            if moments['m00'] != 0:
                palm_center_x = int(moments['m10'] / moments['m00'])
                palm_center_y = int(moments['m01'] / moments['m00'])
            else:
                palm_center_x, palm_center_y = center_x, center_y

            return {
                'area': palm_area,
                'perimeter': palm_perimeter,
                'width': w,
                'height': h,
                'center': (palm_center_x, palm_center_y),
                'aspect_ratio': w / h if h > 0 else 0
            }

        except Exception as e:
            self.logger.error(f"Errore nel calcolo proprietà palmo: {e}")
            return {
                'area': 0,
                'perimeter': 0,
                'width': 0,
                'height': 0,
                'center': (center_x, center_y),
                'aspect_ratio': 0
            }

    def _determine_hand_orientation(self, finger_tips, center_x, center_y) -> str:
        """Determina l'orientamento della mano."""
        try:
            if len(finger_tips) < 2:
                return "unknown"

            # Calcola la direzione media delle dita
            vectors = []
            for tip in finger_tips:
                dx = tip[0] - center_x
                dy = tip[1] - center_y
                vectors.append((dx, dy))

            # Calcola il vettore medio
            avg_dx = sum(v[0] for v in vectors) / len(vectors)
            avg_dy = sum(v[1] for v in vectors) / len(vectors)

            # Determina l'angolo
            angle = math.degrees(math.atan2(avg_dy, avg_dx))

            # Classifica l'orientamento
            if -45 <= angle <= 45:
                return "right"  # Dita puntano a destra
            elif 45 < angle <= 135:
                return "down"   # Dita puntano in basso
            elif -135 <= angle < -45:
                return "up"     # Dita puntano in alto
            else:
                return "left"   # Dita puntano a sinistra

        except Exception as e:
            self.logger.error(f"Errore nella determinazione orientamento: {e}")
            return "unknown"

    def _calculate_hand_confidence(self, finger_tips, palm_contour) -> float:
        """Calcola la confidenza del rilevamento della mano."""
        try:
            confidence = 0.0

            # Confidenza basata sul numero di dita rilevate
            num_fingers = len(finger_tips)
            if num_fingers >= 3:
                confidence += 0.5
            elif num_fingers >= 2:
                confidence += 0.3
            elif num_fingers >= 1:
                confidence += 0.1

            # Confidenza basata sull'area del palmo
            palm_area = cv2.contourArea(palm_contour)
            if self.min_hand_area < palm_area < self.max_hand_area:
                confidence += 0.3
            elif palm_area > 0:
                confidence += 0.1

            # Confidenza basata sulla forma
            if self._is_hand_shape(palm_contour):
                confidence += 0.2

            return min(confidence, 1.0)

        except Exception as e:
            self.logger.error(f"Errore nel calcolo confidenza: {e}")
            return 0.0

    def draw_hand_palm_analysis(self, frame, hand_data):
        """Disegna l'analisi del palmo della mano sul frame."""
        try:
            if not hand_data:
                return

            contour = hand_data['contour']
            center = hand_data['center']
            finger_tips = hand_data['finger_tips']
            palm_contour = hand_data['palm_contour']
            orientation = hand_data['orientation']
            confidence = hand_data['confidence']

            # Disegna il contorno della mano
            cv2.drawContours(frame, [contour], -1, (0, 255, 0), 2)

            # Disegna il centro della mano
            cv2.circle(frame, center, 5, (255, 0, 0), -1)

            # Disegna le punte delle dita
            for i, tip in enumerate(finger_tips):
                cv2.circle(frame, tip, 8, (0, 0, 255), -1)
                cv2.putText(frame, f"Dita {i+1}", (tip[0] + 10, tip[1] - 10),
                           cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 0, 255), 1)

            # Disegna il contorno del palmo
            if palm_contour is not None and len(palm_contour) > 0:
                cv2.drawContours(frame, [palm_contour], -1, (255, 255, 0), 2)

                # Evidenzia il centro del palmo
                palm_props = hand_data.get('palm_properties', {})
                if 'center' in palm_props:
                    palm_center = palm_props['center']
                    cv2.circle(frame, palm_center, 10, (255, 165, 0), -1)
                    cv2.putText(frame, "Centro Palmo", (palm_center[0] + 15, palm_center[1] - 15),
                               cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255, 165, 0), 2)

            # Mostra informazioni sulla mano
            info_x = center[0] + 20
            info_y = center[1] - 20

            cv2.putText(frame, f"Mano {orientation.upper()}", (info_x, info_y),
                       cv2.FONT_HERSHEY_SIMPLEX, 0.7, (255, 255, 255), 2)

            cv2.putText(frame, f"Dita: {len(finger_tips)}", (info_x, info_y + 25),
                       cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255, 255, 255), 1)

            cv2.putText(frame, f"Conf: {confidence:.2f}", (info_x, info_y + 45),
                       cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255, 255, 255), 1)

            # Mostra il bounding box della mano
            x, y, w, h = cv2.boundingRect(contour)
            cv2.rectangle(frame, (x, y), (x + w, y + h), (0, 255, 255), 2)

        except Exception as e:
            self.logger.error(f"Errore nel disegno analisi mano: {e}")

    def get_hand_gesture(self, hand_data) -> str:
        """Determina il gesto della mano basato sui dati del palmo."""
        try:
            finger_tips = hand_data.get('finger_tips', [])
            num_fingers = len(finger_tips)

            if num_fingers == 0:
                return "mano chiusa"
            elif num_fingers == 1:
                return "indice esteso"
            elif num_fingers == 2:
                return "due dita"
            elif num_fingers == 3:
                return "tre dita"
            elif num_fingers == 4:
                return "quattro dita"
            elif num_fingers >= 5:
                return "mano aperta"
            else:
                return "gesto indefinito"

        except Exception as e:
            self.logger.error(f"Errore nella determinazione gesto: {e}")
            return "gesto indefinito"