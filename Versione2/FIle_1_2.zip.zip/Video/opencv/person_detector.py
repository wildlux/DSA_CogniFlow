# person_detector.py

import cv2
import numpy as np
import logging
from typing import Dict, List, Tuple, Optional, Any
try:
    from base_detector import BaseDetector
except ImportError:
    import sys
    import os
    sys.path.append(os.path.dirname(__file__))
    from base_detector import BaseDetector

class PersonDetector(BaseDetector):
    """
    Rilevatore avanzato di persone con analisi delle parti del corpo.
    Include gestione speciale per occhiali e riflessi.
    """

    def __init__(self, enabled: bool = False):
        super().__init__(enabled)
        self.face_cascade = None
        self.eye_cascade = None
        self.nose_cascade = None
        self.mouth_cascade = None
        self._initialize_cascades()

    def _initialize_cascades(self):
        """Inizializza tutti i cascade classifier per il rilevamento."""
        try:
            import cv2.data
            cascade_path = cv2.data.haarcascades

            # Cascade per il volto
            self.face_cascade = cv2.CascadeClassifier(
                cascade_path + 'haarcascade_frontalface_default.xml'
            )

            # Cascade per gli occhi
            self.eye_cascade = cv2.CascadeClassifier(
                cascade_path + 'haarcascade_eye.xml'
            )

            # Cascade per il naso
            self.nose_cascade = cv2.CascadeClassifier(
                cascade_path + 'haarcascade_mcs_nose.xml'
            )

            # Cascade per la bocca
            self.mouth_cascade = cv2.CascadeClassifier(
                cascade_path + 'haarcascade_smile.xml'
            )

            self.logger.info("Cascade classifiers per rilevamento persona inizializzati")

        except Exception as e:
            self.logger.error(f"Errore nell'inizializzazione dei cascade: {e}")

    def detect(self, frame):
        """Rileva persone e analizza le parti del corpo."""
        if not self.enabled:
            return False, []

        if not self.validate_frame(frame):
            return False, []

        try:
            # Rileva le facce
            faces = self._detect_faces(frame)
            if not faces:
                return False, []

            # Analizza ogni faccia rilevata
            analyzed_persons = []
            for (x, y, w, h) in faces:
                person_data = self._analyze_person(frame, x, y, w, h)
                analyzed_persons.append(person_data)

            detected = len(analyzed_persons) > 0
            if detected:
                self.logger.debug(f"Rilevate {len(analyzed_persons)} persone")

            return detected, analyzed_persons

        except Exception as e:
            self.logger.error(f"Errore nel rilevamento persona: {e}")
            return False, []

    def _detect_faces(self, frame) -> List[Tuple[int, int, int, int]]:
        """Rileva le facce nel frame."""
        if self.face_cascade is None:
            return []

        try:
            gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)

            # Migliora il contrasto per migliore rilevamento
            gray = cv2.equalizeHist(gray)

            # Rileva le facce con parametri ottimizzati
            faces = self.face_cascade.detectMultiScale(
                gray,
                scaleFactor=1.1,
                minNeighbors=5,
                minSize=(30, 30),
                maxSize=(300, 300)
            )

            # Converti le facce in lista di tuple
            face_list = []
            for face in faces:
                # OpenCV Rect può essere indicizzato come tupla
                if len(face) == 4:
                    face_list.append((int(face[0]), int(face[1]), int(face[2]), int(face[3])))
                else:
                    face_list.append(tuple(face))
            return face_list

        except Exception as e:
            self.logger.error(f"Errore nel rilevamento facce: {e}")
            return []

    def _analyze_person(self, frame, face_x, face_y, face_w, face_h) -> Dict[str, Any]:
        """Analizza una persona rilevata e trova le parti del corpo."""
        try:
            # Estrai la regione del volto
            face_roi = frame[face_y:face_y+face_h, face_x:face_x+face_w]
            face_gray = cv2.cvtColor(face_roi, cv2.COLOR_BGR2GRAY)

            # Migliora l'immagine per gestire riflessi/occhiali
            face_gray = self._preprocess_face_for_glasses(face_gray)

            # Trova le parti del corpo
            eyes = self._detect_eyes(face_gray, face_w, face_h)
            nose = self._detect_nose(face_gray, face_w, face_h)
            mouth = self._detect_mouth(face_gray, face_w, face_h)

            # Analizza la sagoma del corpo
            body_contour = self._detect_body_contour(frame, face_x, face_y, face_w, face_h)

            person_data = {
                'face': {
                    'x': face_x,
                    'y': face_y,
                    'width': face_w,
                    'height': face_h,
                    'center': (face_x + face_w//2, face_y + face_h//2)
                },
                'eyes': eyes,
                'nose': nose,
                'mouth': mouth,
                'body_contour': body_contour,
                'has_glasses': self._detect_glasses(face_gray, eyes),
                'confidence': self._calculate_person_confidence(eyes, nose, mouth)
            }

            return person_data

        except Exception as e:
            self.logger.error(f"Errore nell'analisi persona: {e}")
            return {
                'face': {'x': face_x, 'y': face_y, 'width': face_w, 'height': face_h},
                'eyes': [],
                'nose': None,
                'mouth': None,
                'body_contour': None,
                'has_glasses': False,
                'confidence': 0.0
            }

    def _preprocess_face_for_glasses(self, face_gray):
        """Preprocessa l'immagine del volto per gestire occhiali e riflessi."""
        try:
            # Riduci rumore per gestire riflessi
            face_gray = cv2.medianBlur(face_gray, 3)

            # Equalizza istogramma per migliorare contrasto
            face_gray = cv2.equalizeHist(face_gray)

            # Applica filtro bilaterale per ridurre rumore mantenendo bordi
            face_gray = cv2.bilateralFilter(face_gray, 9, 75, 75)

            # Migliora i bordi per rilevare meglio gli occhiali
            face_gray = cv2.Laplacian(face_gray, cv2.CV_8U, ksize=3)
            face_gray = cv2.convertScaleAbs(face_gray, alpha=0.5, beta=0)

            return face_gray

        except Exception as e:
            self.logger.error(f"Errore nel preprocessing volto: {e}")
            return face_gray

    def _detect_eyes(self, face_gray, face_w, face_h) -> List[Dict[str, Any]]:
        """Rileva gli occhi nel volto."""
        if self.eye_cascade is None:
            return []

        try:
            # Definisci regione degli occhi (metà superiore del volto)
            eye_region = face_gray[int(face_h*0.1):int(face_h*0.5), :]

            eyes = self.eye_cascade.detectMultiScale(
                eye_region,
                scaleFactor=1.1,
                minNeighbors=3,
                minSize=(20, 20),
                maxSize=(int(face_w*0.4), int(face_h*0.3))
            )

            eye_list = []
            for (ex, ey, ew, eh) in eyes:
                # Converti coordinate relative al volto completo
                eye_data = {
                    'x': ex,
                    'y': ey + int(face_h*0.1),  # Offset per regione occhi
                    'width': ew,
                    'height': eh,
                    'center': (ex + ew//2, ey + int(face_h*0.1) + eh//2),
                    'aspect_ratio': ew / eh if eh > 0 else 0
                }
                eye_list.append(eye_data)

            return eye_list[:2]  # Massimo 2 occhi

        except Exception as e:
            self.logger.error(f"Errore nel rilevamento occhi: {e}")
            return []

    def _detect_nose(self, face_gray, face_w, face_h) -> Optional[Dict[str, Any]]:
        """Rileva il naso nel volto."""
        if self.nose_cascade is None:
            return None

        try:
            # Definisci regione del naso (parte centrale del volto)
            nose_region = face_gray[int(face_h*0.3):int(face_h*0.7), int(face_w*0.3):int(face_w*0.7)]

            noses = self.nose_cascade.detectMultiScale(
                nose_region,
                scaleFactor=1.1,
                minNeighbors=3,
                minSize=(15, 15),
                maxSize=(int(face_w*0.3), int(face_h*0.3))
            )

            if len(noses) > 0:
                nx, ny, nw, nh = noses[0]
                # Converti coordinate relative al volto completo
                return {
                    'x': nx + int(face_w*0.3),
                    'y': ny + int(face_h*0.3),
                    'width': nw,
                    'height': nh,
                    'center': (nx + int(face_w*0.3) + nw//2, ny + int(face_h*0.3) + nh//2)
                }

            return None

        except Exception as e:
            self.logger.error(f"Errore nel rilevamento naso: {e}")
            return None

    def _detect_mouth(self, face_gray, face_w, face_h) -> Optional[Dict[str, Any]]:
        """Rileva la bocca nel volto."""
        if self.mouth_cascade is None:
            return None

        try:
            # Definisci regione della bocca (terzo inferiore del volto)
            mouth_region = face_gray[int(face_h*0.6):, int(face_w*0.2):int(face_w*0.8)]

            mouths = self.mouth_cascade.detectMultiScale(
                mouth_region,
                scaleFactor=1.1,
                minNeighbors=5,
                minSize=(20, 15),
                maxSize=(int(face_w*0.6), int(face_h*0.3))
            )

            if len(mouths) > 0:
                mx, my, mw, mh = mouths[0]
                # Converti coordinate relative al volto completo
                return {
                    'x': mx + int(face_w*0.2),
                    'y': my + int(face_h*0.6),
                    'width': mw,
                    'height': mh,
                    'center': (mx + int(face_w*0.2) + mw//2, my + int(face_h*0.6) + mh//2)
                }

            return None

        except Exception as e:
            self.logger.error(f"Errore nel rilevamento bocca: {e}")
            return None

    def _detect_glasses(self, face_gray, eyes) -> bool:
        """Rileva se la persona indossa occhiali."""
        if len(eyes) < 2:
            return False

        try:
            # Analizza la regione tra gli occhi per cercare montatura occhiali
            eye1, eye2 = eyes[0], eyes[1]

            # Trova la regione tra gli occhi
            min_x = min(eye1['x'], eye2['x'])
            max_x = max(eye1['x'] + eye1['width'], eye2['x'] + eye2['width'])
            min_y = min(eye1['y'], eye2['y'])
            max_y = max(eye1['y'] + eye1['height'], eye2['y'] + eye2['height'])

            # Espandi leggermente la regione
            width = max_x - min_x
            height = max_y - min_y
            region = face_gray[min_y:max_y, min_x:max_x]

            if region.size == 0:
                return False

            # Analizza i bordi per cercare montatura occhiali
            edges = cv2.Canny(region, 50, 150)

            # Conta i pixel di bordo
            edge_pixels = np.count_nonzero(edges)
            total_pixels = region.shape[0] * region.shape[1]

            # Calcola la densità dei bordi
            edge_density = edge_pixels / total_pixels if total_pixels > 0 else 0

            # Se la densità dei bordi è alta, probabilmente ci sono occhiali
            return edge_density > 0.15

        except Exception as e:
            self.logger.error(f"Errore nel rilevamento occhiali: {e}")
            return False

    def _detect_body_contour(self, frame, face_x, face_y, face_w, face_h):
        """Rileva la sagoma del corpo partendo dal volto."""
        try:
            # Converti in scala di grigi
            gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)

            # Applica threshold per creare immagine binaria
            _, thresh = cv2.threshold(gray, 127, 255, cv2.THRESH_BINARY_INV)

            # Trova i contorni
            contours, _ = cv2.findContours(thresh, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

            # Trova il contorno più grande che contiene il volto
            best_contour = None
            max_area = 0

            face_center = (face_x + face_w//2, face_y + face_h//2)

            for contour in contours:
                area = cv2.contourArea(contour)
                if area > max_area and area > face_w * face_h:
                    # Verifica se il contorno contiene il volto
                    if cv2.pointPolygonTest(contour, face_center, False) >= 0:
                        best_contour = contour
                        max_area = area

            return best_contour

        except Exception as e:
            self.logger.error(f"Errore nel rilevamento sagoma corpo: {e}")
            return None

    def _calculate_person_confidence(self, eyes, nose, mouth) -> float:
        """Calcola la confidenza del rilevamento persona."""
        confidence = 0.0

        # Occhi (massimo 0.4)
        if len(eyes) == 2:
            confidence += 0.4
        elif len(eyes) == 1:
            confidence += 0.2

        # Naso (massimo 0.3)
        if nose is not None:
            confidence += 0.3

        # Bocca (massimo 0.3)
        if mouth is not None:
            confidence += 0.3

        return confidence

    def draw_person_analysis(self, frame, person_data):
        """Disegna l'analisi della persona sul frame."""
        try:
            face = person_data['face']

            # Disegna rettangolo volto
            cv2.rectangle(frame,
                         (face['x'], face['y']),
                         (face['x'] + face['width'], face['y'] + face['height']),
                         (255, 0, 0), 2)

            # Disegna occhi
            for eye in person_data['eyes']:
                cv2.rectangle(frame,
                             (face['x'] + eye['x'], face['y'] + eye['y']),
                             (face['x'] + eye['x'] + eye['width'], face['y'] + eye['y'] + eye['height']),
                             (0, 255, 0), 2)
                cv2.putText(frame, "Occhio", (face['x'] + eye['x'], face['y'] + eye['y'] - 5),
                           cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 255, 0), 1)

            # Disegna naso
            if person_data['nose']:
                nose = person_data['nose']
                cv2.rectangle(frame,
                             (face['x'] + nose['x'], face['y'] + nose['y']),
                             (face['x'] + nose['x'] + nose['width'], face['y'] + nose['y'] + nose['height']),
                             (255, 255, 0), 2)
                cv2.putText(frame, "Naso", (face['x'] + nose['x'], face['y'] + nose['y'] - 5),
                           cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 255, 0), 1)

            # Disegna bocca
            if person_data['mouth']:
                mouth = person_data['mouth']
                cv2.rectangle(frame,
                             (face['x'] + mouth['x'], face['y'] + mouth['y']),
                             (face['x'] + mouth['x'] + mouth['width'], face['y'] + mouth['y'] + mouth['height']),
                             (0, 0, 255), 2)
                cv2.putText(frame, "Bocca", (face['x'] + mouth['x'], face['y'] + mouth['y'] - 5),
                           cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 0, 255), 1)

            # Mostra se ha occhiali
            if person_data['has_glasses']:
                cv2.putText(frame, "OCCHIALI RILEVATI",
                           (face['x'], face['y'] - 20),
                           cv2.FONT_HERSHEY_SIMPLEX, 0.7, (255, 165, 0), 2)

            # Mostra confidenza
            confidence_text = f"Confidenza: {person_data['confidence']:.2f}"
            cv2.putText(frame, confidence_text,
                       (face['x'], face['y'] + face['height'] + 20),
                       cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255, 255, 255), 1)

            # Disegna sagoma corpo se disponibile
            if person_data['body_contour'] is not None:
                cv2.drawContours(frame, [person_data['body_contour']], -1, (0, 255, 255), 2)

        except Exception as e:
            self.logger.error(f"Errore nel disegno analisi persona: {e}")