#!/usr/bin/env python3
"""
Script di debug per testare il rilevamento di mani e faccia
"""

import cv2
import numpy as np
import logging
import math
from PyQt6.QtCore import pyqtSignal

# Configurazione logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

class DebugVideoThread:
    """Classe di debug per testare il rilevamento"""

    def __init__(self):
        self.face_detection_enabled = True
        self.hand_detection_enabled = True
        self.gesture_recognition_enabled = True
        self.facial_expression_enabled = True

        # Carica i classificatori Haar per il rilevamento
        try:
            import cv2.data
            cascade_path = cv2.data.haarcascades + 'haarcascade_frontalface_default.xml'
            self.face_cascade = cv2.CascadeClassifier(cascade_path)
            if self.face_cascade.empty():
                logging.warning("File Haar cascade per il rilevamento facciale non trovato.")
                self.face_cascade = None
        except Exception as e:
            logging.error(f"Errore nel caricamento del cascade Haar: {e}")
            self.face_cascade = None

        # Per le mani, usiamo un approccio alternativo basato sulla pelle
        self.lower_skin = np.array([0, 20, 70], dtype=np.uint8)
        self.upper_skin = np.array([20, 255, 255], dtype=np.uint8)

        # Parametri per il riconoscimento dei gesti
        self.prev_hand_positions = []
        self.gesture_history = []
        self.selected_widget = None
        self.drag_start_time: float = 0.0
        self.is_dragging = False
        self.drag_timer = 0
        self.DRAG_THRESHOLD = 6.0  # 6 secondi per iniziare il trascinamento

        # Parametri per il riconoscimento avanzato delle mani
        self.hand_tracking = {
            'left': {'position': None, 'fingers': 0, 'gesture': 'unknown', 'confidence': 0},
            'right': {'position': None, 'fingers': 0, 'gesture': 'unknown', 'confidence': 0}
        }
        self.active_inputs = set()  # Traccia dispositivi attivi (mani + mouse)

        # Parametri per il riconoscimento dei gesti
        self.prev_hand_positions = []
        self.gesture_history = []

        # Parametri per il riconoscimento delle espressioni facciali
        self.prev_face_positions = []
        self.expression_history = []

    def detect_faces(self, frame):
        """Rileva le facce nel frame e disegna rettangoli."""
        if self.face_cascade is None:
            cv2.putText(frame, 'Rilevamento faccia non disponibile', (10, 30),
                       cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 0, 255), 2)
            return frame

        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        faces = self.face_cascade.detectMultiScale(
            gray,
            scaleFactor=1.05,
            minNeighbors=3,
            minSize=(30, 30),
            maxSize=(300, 300)
        )

        if len(faces) > 0:
            cv2.putText(frame, f'Faccia rilevata: {len(faces)}', (10, 30),
                       cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 255, 0), 2)
        else:
            cv2.putText(frame, 'Nessuna faccia rilevata', (10, 30),
                       cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 255, 255), 2)

        for (x, y, w, h) in faces:
            cv2.rectangle(frame, (x, y), (x+w, y+h), (255, 0, 0), 3)
            cv2.putText(frame, 'Faccia', (x, y-10), cv2.FONT_HERSHEY_SIMPLEX, 0.9, (255, 0, 0), 2)

        return frame

    def detect_hands(self, frame):
        """Rileva le mani nel frame usando il colore della pelle."""
        hsv = cv2.cvtColor(frame, cv2.COLOR_BGR2HSV)
        mask = cv2.inRange(hsv, self.lower_skin, self.upper_skin)

        # Operazioni morfologiche per migliorare la maschera
        kernel = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (5, 5))
        mask = cv2.morphologyEx(mask, cv2.MORPH_CLOSE, kernel)
        mask = cv2.morphologyEx(mask, cv2.MORPH_OPEN, kernel)

        # Trova i contorni nell'immagine binaria
        contours, _ = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

        hand_count = 0
        for contour in contours:
            area = cv2.contourArea(contour)
            if area > 3000:
                x, y, w, h = cv2.boundingRect(contour)
                aspect_ratio = w / h if h > 0 else 0
                if 0.5 < aspect_ratio < 2.0:
                    cv2.rectangle(frame, (x, y), (x+w, y+h), (0, 255, 0), 3)
                    cv2.putText(frame, 'Mano', (x, y-10), cv2.FONT_HERSHEY_SIMPLEX, 0.9, (0, 255, 0), 2)
                    hand_count += 1

        if hand_count > 0:
            cv2.putText(frame, f'Mani rilevate: {hand_count}', (10, 60),
                       cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 255, 0), 2)
        else:
            cv2.putText(frame, 'Nessuna mano rilevata', (10, 60),
                       cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 255, 255), 2)

        return frame

    def detect_hand_gestures(self, frame):
        """Rileva i gesti delle mani (aperta/chiusa) usando analisi della forma."""
        if not self.gesture_recognition_enabled:
            return frame

        hsv = cv2.cvtColor(frame, cv2.COLOR_BGR2HSV)
        mask = cv2.inRange(hsv, self.lower_skin, self.upper_skin)

        # Operazioni morfologiche per migliorare la maschera
        kernel = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (5, 5))
        mask = cv2.morphologyEx(mask, cv2.MORPH_CLOSE, kernel)
        mask = cv2.morphologyEx(mask, cv2.MORPH_OPEN, kernel)

        # Trova i contorni
        contours, _ = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

        gesture_count = 0
        for contour in contours:
            area = cv2.contourArea(contour)
            if area > 3000:
                x, y, w, h = cv2.boundingRect(contour)
                aspect_ratio = w / h if h > 0 else 0

                if 0.5 < aspect_ratio < 2.0:
                    # Analizza la forma per determinare se la mano è aperta o chiusa
                    gesture = self.analyze_hand_shape(contour, x, y, w, h)

                    # Disegna il rettangolo e il gesto rilevato
                    cv2.rectangle(frame, (x, y), (x+w, y+h), (255, 165, 0), 3)  # Arancione per i gesti
                    cv2.putText(frame, f'Gesto: {gesture}', (x, y-10), cv2.FONT_HERSHEY_SIMPLEX, 0.7, (255, 165, 0), 2)
                    gesture_count += 1

        # Mostra lo stato del riconoscimento gesti
        if gesture_count > 0:
            cv2.putText(frame, f'GestI rilevati: {gesture_count}', (10, 90),
                       cv2.FONT_HERSHEY_SIMPLEX, 1, (255, 165, 0), 2)
        else:
            cv2.putText(frame, 'Nessun gesto rilevato', (10, 90),
                       cv2.FONT_HERSHEY_SIMPLEX, 1, (255, 165, 0), 2)

        return frame

    def analyze_hand_shape(self, contour, x, y, w, h):
        """Analizza la forma del contorno per determinare il gesto della mano."""
        # Calcola la convessità
        hull = cv2.convexHull(contour)
        hull_area = cv2.contourArea(hull)

        if hull_area > 0:
            solidity = cv2.contourArea(contour) / hull_area
        else:
            solidity = 0

        # Calcola i difetti di convessità
        hull_indices = cv2.convexHull(contour, returnPoints=False)
        defects = cv2.convexityDefects(contour, hull_indices)

        finger_count = 0
        if defects is not None:
            for i in range(defects.shape[0]):
                s, e, f, d = defects[i, 0]
                start = tuple(contour[s][0])
                end = tuple(contour[e][0])
                far = tuple(contour[f][0])

                # Calcola la distanza dal punto lontano al contorno
                a = math.sqrt((end[0] - start[0])**2 + (end[1] - start[1])**2)
                b = math.sqrt((far[0] - start[0])**2 + (far[1] - start[1])**2)
                c = math.sqrt((end[0] - far[0])**2 + (end[1] - far[1])**2)

                # Usa la formula di Erone per calcolare l'area
                s = (a + b + c) / 2
                area = math.sqrt(s * (s - a) * (s - b) * (s - c))

                # Calcola la distanza dal punto lontano
                distance = (2 * area) / a if a > 0 else 0

                # Conta le dita basandosi sulla profondità dei difetti
                if distance > 20:  # Soglia per considerare un dito
                    finger_count += 1

        # Determina il gesto basato su solidità e numero di dita
        if solidity > 0.8 and finger_count >= 4:
            return "Mano Aperta"
        elif solidity < 0.6 or finger_count <= 1:
            return "Mano Chiusa"
        else:
            return "Gesto Parziale"

    def detect_facial_expressions(self, frame):
        """Rileva le espressioni facciali usando landmark e geometria."""
        if not self.facial_expression_enabled or self.face_cascade is None:
            return frame

        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        faces = self.face_cascade.detectMultiScale(
            gray,
            scaleFactor=1.05,
            minNeighbors=3,
            minSize=(30, 30),
            maxSize=(300, 300)
        )

        expression_count = 0
        for (x, y, w, h) in faces:
            # Estrai la regione del volto
            face_roi = gray[y:y+h, x:x+w]

            # Analizza l'espressione usando caratteristiche geometriche
            expression = self.analyze_facial_expression(face_roi, x, y, w, h)

            # Disegna il rettangolo e l'espressione rilevata
            cv2.rectangle(frame, (x, y), (x+w, y+h), (255, 0, 255), 3)  # Magenta per espressioni
            cv2.putText(frame, f'Espressione: {expression}', (x, y+h+25), cv2.FONT_HERSHEY_SIMPLEX, 0.7, (255, 0, 255), 2)
            expression_count += 1

        # Mostra lo stato del riconoscimento espressioni
        if expression_count > 0:
            cv2.putText(frame, f'Espressioni rilevate: {expression_count}', (10, 120),
                       cv2.FONT_HERSHEY_SIMPLEX, 1, (255, 0, 255), 2)
        else:
            cv2.putText(frame, 'Nessuna espressione rilevata', (10, 120),
                       cv2.FONT_HERSHEY_SIMPLEX, 1, (255, 0, 255), 2)

        return frame

    def analyze_facial_expression(self, face_roi, x, y, w, h):
        """Analizza l'espressione facciale usando caratteristiche geometriche."""
        if face_roi.size == 0:
            return "Non rilevabile"

        # Calcola caratteristiche geometriche
        height, width = face_roi.shape

        # Dividi il volto in regioni
        top_third = face_roi[:height//3, :]
        middle_third = face_roi[height//3:2*height//3, :]
        bottom_third = face_roi[2*height//3:, :]

        # Calcola la luminosità media di ogni regione
        top_brightness = np.mean(top_third)
        middle_brightness = np.mean(middle_third)
        bottom_brightness = np.mean(bottom_third)

        # Calcola i gradienti per rilevare curve della bocca
        sobelx = cv2.Sobel(face_roi, cv2.CV_64F, 1, 0, ksize=3)
        sobely = cv2.Sobel(face_roi, cv2.CV_64F, 0, 1, ksize=3)
        gradient_magnitude = np.sqrt(sobelx**2 + sobely**2)

        # Analizza la regione della bocca (terzo inferiore)
        mouth_gradient = np.mean(gradient_magnitude[2*height//3:, :])

        # Classifica l'espressione basata sulle caratteristiche
        if mouth_gradient > 50 and bottom_brightness > middle_brightness:
            return "Sorriso"
        elif mouth_gradient < 20 and bottom_brightness < middle_brightness:
            return "Triste"
        elif abs(top_brightness - bottom_brightness) < 10:
            return "Neutro"
        elif mouth_gradient > 30:
            return "Sorpreso"
        else:
            return "Neutro"

    def run_debug(self):
        """Esegue il debug del rilevamento"""
        cap = cv2.VideoCapture(0)
        if not cap.isOpened():
            logging.error("Errore: Impossibile aprire la webcam.")
            return

        logging.info("Webcam avviata. Avvio debug rilevamento...")
        logging.info("Controlli:")
        logging.info("  'q' - Esci")
        logging.info("  'f' - Toggle rilevamento faccia")
        logging.info("  'h' - Toggle rilevamento mani")
        logging.info("  'g' - Toggle riconoscimento gesti")
        logging.info("  'e' - Toggle riconoscimento espressioni")

        while True:
            ret, frame = cap.read()
            if ret:
                frame = cv2.flip(frame, 1)

                # Mostra sempre lo stato dei rilevamenti
                status_text = ""
                if self.face_detection_enabled:
                    status_text += "Faccia: ON  "
                else:
                    status_text += "Faccia: OFF  "

                if self.hand_detection_enabled:
                    status_text += "Mani: ON  "
                else:
                    status_text += "Mani: OFF  "

                if self.gesture_recognition_enabled:
                    status_text += "Gesti: ON  "
                else:
                    status_text += "Gesti: OFF  "

                if self.facial_expression_enabled:
                    status_text += "Espressioni: ON"
                else:
                    status_text += "Espressioni: OFF"

                cv2.putText(frame, status_text, (10, frame.shape[0] - 20),
                           cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255, 255, 255), 2)

                if self.face_detection_enabled:
                    frame = self.detect_faces(frame)
                if self.hand_detection_enabled:
                    frame = self.detect_hands(frame)
                if self.gesture_recognition_enabled:
                    frame = self.detect_hand_gestures(frame)
                if self.facial_expression_enabled:
                    frame = self.detect_facial_expressions(frame)

                # Mostra il frame
                cv2.imshow('Debug Rilevamento Avanzato', frame)

                # Simula l'invio del segnale (per compatibilità con il codice esistente)
                # Nel debug script mostriamo direttamente l'immagine

                # Gestisci i tasti
                key = cv2.waitKey(1) & 0xFF
                if key == ord('q'):
                    break
                elif key == ord('f'):
                    self.face_detection_enabled = not self.face_detection_enabled
                    logging.info(f"Rilevamento faccia: {'ON' if self.face_detection_enabled else 'OFF'}")
                elif key == ord('h'):
                    self.hand_detection_enabled = not self.hand_detection_enabled
                    logging.info(f"Rilevamento mani: {'ON' if self.hand_detection_enabled else 'OFF'}")
                elif key == ord('g'):
                    self.gesture_recognition_enabled = not self.gesture_recognition_enabled
                    logging.info(f"Riconoscimento gesti: {'ON' if self.gesture_recognition_enabled else 'OFF'}")
                elif key == ord('e'):
                    self.facial_expression_enabled = not self.facial_expression_enabled
                    logging.info(f"Riconoscimento espressioni: {'ON' if self.facial_expression_enabled else 'OFF'}")
            else:
                logging.error("Errore di lettura del frame dalla webcam.")
                break

        cap.release()
        cv2.destroyAllWindows()
        logging.info("Debug completato.")

if __name__ == '__main__':
    debug = DebugVideoThread()
    debug.run_debug()