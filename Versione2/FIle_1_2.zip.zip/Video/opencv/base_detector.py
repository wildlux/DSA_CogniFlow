# base_detector.py

import cv2
import numpy as np
from abc import ABC, abstractmethod
from typing import Tuple

class BaseDetector(ABC):
    """
    Classe base astratta per tutti i rilevatori di computer vision.

    Questa classe fornisce un'interfaccia comune e funzionalità condivise
    per tutti i rilevatori, migliorando la manutenibilità e riducendo
    la duplicazione del codice.
    """

    def __init__(self, enabled: bool = False):
        """
        Inizializza il rilevatore base.

        Args:
            enabled (bool): Se il rilevatore è abilitato
        """
        self.enabled = enabled

    @abstractmethod
    def detect(self, frame) -> Tuple[bool, any]:
        """
        Metodo astratto per il rilevamento.

        Args:
            frame: Il frame da analizzare

        Returns:
            Tuple[bool, any]: (rilevamento_successo, dati_rilevamento)
        """
        pass

    def set_enabled(self, enabled: bool):
        """Abilita o disabilita il rilevatore."""
        self.enabled = enabled

    def is_enabled(self) -> bool:
        """Restituisce lo stato di abilitazione del rilevatore."""
        return self.enabled

    def draw_status_text(self, frame, text: str, position: Tuple[int, int] = (10, 30)):
        """
        Disegna il testo di stato sul frame.

        Args:
            frame: Il frame su cui disegnare
            text (str): Il testo da disegnare
            position (Tuple[int, int]): Posizione (x, y) del testo
        """
        cv2.putText(
            frame,
            text,
            position,
            cv2.FONT_HERSHEY_SIMPLEX,
            1,
            (255, 255, 255),
            2
        )

    def draw_bounding_box(self, frame, x: int, y: int, w: int, h: int,
                         color: Tuple[int, int, int] = (0, 255, 0),
                         thickness: int = 2):
        """
        Disegna un rettangolo di delimitazione.

        Args:
            frame: Il frame su cui disegnare
            x, y, w, h (int): Coordinate e dimensioni del rettangolo
            color (Tuple[int, int, int]): Colore del rettangolo (BGR)
            thickness (int): Spessore del rettangolo
        """
        cv2.rectangle(frame, (x, y), (x + w, y + h), color, thickness)

    def draw_text(self, frame, text: str, position: Tuple[int, int],
                  color: Tuple[int, int, int] = (0, 255, 0),
                  font_scale: float = 0.6, thickness: int = 1):
        """
        Disegna testo sul frame.

        Args:
            frame: Il frame su cui disegnare
            text (str): Il testo da disegnare
            position (Tuple[int, int]): Posizione (x, y) del testo
            color (Tuple[int, int, int]): Colore del testo (BGR)
            font_scale (float): Dimensione del font
            thickness (int): Spessore del testo
        """
        cv2.putText(
            frame,
            text,
            position,
            cv2.FONT_HERSHEY_SIMPLEX,
            font_scale,
            color,
            thickness
        )

    def validate_frame(self, frame) -> bool:
        """
        Valida che il frame sia utilizzabile.

        Args:
            frame: Il frame da validare

        Returns:
            bool: True se il frame è valido
        """
        if frame is None:
            return False

        if not hasattr(frame, 'shape'):
            return False

        if len(frame.shape) < 2:
            return False

        return True

    def preprocess_frame(self, frame):
        """
        Preprocessa il frame per il rilevamento.

        Args:
            frame: Il frame da preprocessare

        Returns:
            Il frame preprocessato
        """
        if not self.validate_frame(frame):
            return frame

        # Applica eventuali filtri comuni
        return frame


class FaceDetector(BaseDetector):
    """
    Rilevatore di facce basato su Haar cascades.
    """

    def __init__(self, enabled: bool = False):
        super().__init__(enabled)
        self.face_cascade = None
        self._load_cascade()

    def _load_cascade(self):
        """Carica il cascade classifier per il rilevamento facciale."""
        try:
            import cv2.data
            cascade_path = cv2.data.haarcascades + 'haarcascade_frontalface_default.xml'
            self.face_cascade = cv2.CascadeClassifier(cascade_path)
            if self.face_cascade.empty():
                self.face_cascade = None
        except Exception as e:
            self.face_cascade = None

    def detect(self, frame):
        """Rileva le facce nel frame."""
        if not self.enabled or self.face_cascade is None:
            return False, []

        if not self.validate_frame(frame):
            return False, []

        try:
            gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
            faces = self.face_cascade.detectMultiScale(
                gray,
                scaleFactor=1.05,
                minNeighbors=3,
                minSize=(30, 30),
                maxSize=(300, 300)
            )

            detected = len(faces) > 0
            return detected, faces

        except Exception as e:
            return False, []


class HandDetector(BaseDetector):
    """
    Rilevatore di mani basato sul colore della pelle.
    """

    def __init__(self, enabled: bool = False):
        super().__init__(enabled)
        # Range HSV per il colore della pelle (convertito in array numpy)
        self.lower_skin = np.array([0, 20, 70], dtype=np.uint8)
        self.upper_skin = np.array([20, 255, 255], dtype=np.uint8)

    def detect(self, frame):
        """Rileva le mani nel frame usando il colore della pelle."""
        if not self.enabled:
            return False, []

        if not self.validate_frame(frame):
            return False, []

        try:
            hsv = cv2.cvtColor(frame, cv2.COLOR_BGR2HSV)
            mask = cv2.inRange(hsv, self.lower_skin, self.upper_skin)

            # Operazioni morfologiche per migliorare la maschera
            kernel = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (5, 5))
            mask = cv2.morphologyEx(mask, cv2.MORPH_CLOSE, kernel)
            mask = cv2.morphologyEx(mask, cv2.MORPH_OPEN, kernel)

            # Trova i contorni
            contours, _ = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

            hands = []
            for contour in contours:
                area = cv2.contourArea(contour)
                if area > 3000:  # Soglia per le mani
                    x, y, w, h = cv2.boundingRect(contour)
                    aspect_ratio = w / h if h > 0 else 0
                    if 0.5 < aspect_ratio < 2.0:  # Proporzioni ragionevoli per le mani
                        hands.append((x, y, w, h))

            detected = len(hands) > 0
            return detected, hands

        except Exception as e:
            return False, []