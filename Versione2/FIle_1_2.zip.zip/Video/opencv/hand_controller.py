#!/usr/bin/env python3
"""
Controllo Avanzato delle Mani - Modulo Specializzato
Sistema completo per il riconoscimento e controllo delle mani
"""

import cv2
import numpy as np
import math
import logging
from PyQt6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel, QPushButton,
    QSlider, QGroupBox, QCheckBox, QComboBox, QTextEdit,
    QTabWidget, QGridLayout, QMessageBox, QSpinBox, QProgressBar
)
from PyQt6.QtCore import Qt, pyqtSignal, QTimer
from PyQt6.QtGui import QFont, QImage, QPixmap

class HandController(QWidget):
    """
    Controller avanzato per il riconoscimento e controllo delle mani
    Gestisce il rilevamento, tracking e interazione delle mani
    """

    # Segnali per comunicare con il sistema principale
    hand_gesture_detected = pyqtSignal(str, dict)  # gesto, info_mano
    hand_position_changed = pyqtSignal(str, tuple)  # mano, posizione
    interaction_detected = pyqtSignal(str, str)  # tipo_interazione, descrizione

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("🤏 Controllo Avanzato delle Mani - Modalità Sviluppatore")
        self.setGeometry(100, 100, 900, 700)

        # Variabili per il riconoscimento delle mani
        self.left_hand = {
            'position': None,
            'fingers': 0,
            'gesture': 'unknown',
            'confidence': 0.0,
            'last_gesture': 'unknown',
            'gesture_timer': 0
        }

        self.right_hand = {
            'position': None,
            'fingers': 0,
            'gesture': 'unknown',
            'confidence': 0.0,
            'last_gesture': 'unknown',
            'gesture_timer': 0
        }

        # Parametri di configurazione
        self.skin_detection_params = {
            'lower_skin': np.array([0, 20, 70], dtype=np.uint8),
            'upper_skin': np.array([20, 255, 255], dtype=np.uint8),
            'min_area': 5000,
            'max_area': 50000,
            'aspect_ratio_min': 0.4,
            'aspect_ratio_max': 2.5
        }

        self.gesture_params = {
            'solidity_threshold': 0.7,
            'finger_threshold': 20,
            'compactness_open': 0.4,
            'compactness_closed': 0.6,
            'drag_timer_threshold': 6.0
        }

        # Stato del sistema
        self.is_active = True
        self.debug_mode = True
        self.interaction_mode = True
        self.current_frame = None

        # Timer per l'analisi
        self.analysis_timer = QTimer()
        self.analysis_timer.timeout.connect(self.analyze_hands)
        self.analysis_timer.start(50)  # 20 FPS

        # Timer per il drag
        self.drag_timer = QTimer()
        self.drag_timer.timeout.connect(self.update_drag_timer)

    def update_drag_timer(self):
        """Aggiorna il timer di trascinamento"""
        pass

        self.setup_ui()
        self.setup_connections()

    def setup_ui(self):
        """Configura l'interfaccia utente del controller"""
        layout = QVBoxLayout(self)

        # Titolo principale
        title_label = QLabel("🤏 Controllo Avanzato delle Mani")
        title_label.setFont(QFont("Arial", 16, QFont.Weight.Bold))
        title_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        layout.addWidget(title_label)

        # Tab widget
        self.tab_widget = QTabWidget()
        layout.addWidget(self.tab_widget)

        # Aggiungi i tab
        self.setup_monitoring_tab()
        self.setup_configuration_tab()
        self.setup_calibration_tab()
        self.setup_interaction_tab()
        self.setup_statistics_tab()

        # Barra di stato
        self.status_label = QLabel("✅ Controller delle mani attivo - Modalità sviluppatore")
        self.status_label.setStyleSheet("color: green; font-weight: bold;")
        layout.addWidget(self.status_label)

    def setup_monitoring_tab(self):
        """Configura il tab per il monitoraggio in tempo reale"""
        monitor_widget = QWidget()
        layout = QVBoxLayout(monitor_widget)

        # Stato delle mani
        hands_group = QGroupBox("📊 Stato delle Mani")
        hands_layout = QGridLayout(hands_group)

        # Mano sinistra
        hands_layout.addWidget(QLabel("🫲 Mano Sinistra:"), 0, 0)
        self.left_hand_label = QLabel("Non rilevata")
        hands_layout.addWidget(self.left_hand_label, 0, 1)

        # Mano destra
        hands_layout.addWidget(QLabel("🫱 Mano Destra:"), 1, 0)
        self.right_hand_label = QLabel("Non rilevata")
        hands_layout.addWidget(self.right_hand_label, 1, 1)

        layout.addWidget(hands_group)

        # Gestures attive
        gestures_group = QGroupBox("🎯 Gesti Rilevati")
        gestures_layout = QVBoxLayout(gestures_group)

        self.gesture_log = QTextEdit()
        self.gesture_log.setMaximumHeight(150)
        self.gesture_log.setReadOnly(True)
        gestures_layout.addWidget(self.gesture_log)

        layout.addWidget(gestures_group)

        # Anteprima video
        preview_group = QGroupBox("📹 Anteprima Rilevamento")
        preview_layout = QVBoxLayout(preview_group)

        self.preview_label = QLabel("Inizializzazione camera...")
        self.preview_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.preview_label.setStyleSheet("border: 2px solid #ccc; min-height: 300px;")
        preview_layout.addWidget(self.preview_label)

        layout.addWidget(preview_group)

        self.tab_widget.addTab(monitor_widget, "📊 Monitoraggio")

    def setup_configuration_tab(self):
        """Configura il tab per le impostazioni"""
        config_widget = QWidget()
        layout = QVBoxLayout(config_widget)

        # Parametri di rilevamento
        detection_group = QGroupBox("🔧 Parametri di Rilevamento")
        detection_layout = QGridLayout(detection_group)

        # Area minima
        detection_layout.addWidget(QLabel("Area Minima:"), 0, 0)
        self.min_area_spin = QSpinBox()
        self.min_area_spin.setRange(1000, 20000)
        self.min_area_spin.setValue(self.skin_detection_params['min_area'])
        detection_layout.addWidget(self.min_area_spin, 0, 1)

        # Area massima
        detection_layout.addWidget(QLabel("Area Massima:"), 1, 0)
        self.max_area_spin = QSpinBox()
        self.max_area_spin.setRange(10000, 100000)
        self.max_area_spin.setValue(self.skin_detection_params['max_area'])
        detection_layout.addWidget(self.max_area_spin, 1, 1)

        # Aspect ratio minimo
        detection_layout.addWidget(QLabel("Aspect Ratio Min:"), 2, 0)
        self.aspect_min_spin = QSpinBox()
        self.aspect_min_spin.setRange(20, 100)
        self.aspect_min_spin.setValue(int(self.skin_detection_params['aspect_ratio_min'] * 100))
        detection_layout.addWidget(self.aspect_min_spin, 2, 1)

        # Aspect ratio massimo
        detection_layout.addWidget(QLabel("Aspect Ratio Max:"), 3, 0)
        self.aspect_max_spin = QSpinBox()
        self.aspect_max_spin.setRange(100, 500)
        self.aspect_max_spin.setValue(int(self.skin_detection_params['aspect_ratio_max'] * 100))
        detection_layout.addWidget(self.aspect_max_spin, 3, 1)

        layout.addWidget(detection_group)

        # Parametri dei gesti
        gesture_group = QGroupBox("🎯 Parametri dei Gesti")
        gesture_layout = QGridLayout(gesture_group)

        # Soglia solidità
        gesture_layout.addWidget(QLabel("Soglia Solidità:"), 0, 0)
        self.solidity_slider = QSlider(Qt.Orientation.Horizontal)
        self.solidity_slider.setRange(50, 90)
        self.solidity_slider.setValue(int(self.gesture_params['solidity_threshold'] * 100))
        gesture_layout.addWidget(self.solidity_slider, 0, 1)

        self.solidity_label = QLabel("0.7")
        gesture_layout.addWidget(self.solidity_label, 0, 2)

        # Soglia dita
        gesture_layout.addWidget(QLabel("Soglia Dita:"), 1, 0)
        self.finger_slider = QSlider(Qt.Orientation.Horizontal)
        self.finger_slider.setRange(10, 40)
        self.finger_slider.setValue(self.gesture_params['finger_threshold'])
        gesture_layout.addWidget(self.finger_slider, 1, 1)

        self.finger_label = QLabel("20")
        gesture_layout.addWidget(self.finger_label, 1, 2)

        layout.addWidget(gesture_group)

        # Pulsanti
        buttons_layout = QHBoxLayout()

        self.apply_config_button = QPushButton("💾 Applica Configurazione")
        self.apply_config_button.clicked.connect(self.apply_configuration)
        buttons_layout.addWidget(self.apply_config_button)

        self.reset_config_button = QPushButton("🔄 Reset Default")
        self.reset_config_button.clicked.connect(self.reset_configuration)
        buttons_layout.addWidget(self.reset_config_button)

        layout.addLayout(buttons_layout)

        self.tab_widget.addTab(config_widget, "⚙️ Configurazione")

    def setup_calibration_tab(self):
        """Configura il tab per la calibrazione del colore della pelle"""
        calib_widget = QWidget()
        layout = QVBoxLayout(calib_widget)

        # Istruzioni
        instructions = QLabel("""
        🎨 Calibrazione Colore della Pelle

        Per calibrare il rilevamento delle mani:

        1. Posizionati in una buona illuminazione
        2. Metti la mano nel riquadro di anteprima
        3. Regola i valori HSV fino a vedere solo la tua mano
        4. Salva le impostazioni

        HSV Ranges:
        • H (Hue): Tonalità del colore
        • S (Saturation): Intensità del colore
        • V (Value): Luminosità
        """)
        instructions.setStyleSheet("font-family: monospace; background-color: #f8f9fa; padding: 10px; border-radius: 5px;")
        layout.addWidget(instructions)

        # Controlli HSV
        hsv_group = QGroupBox("🎛️ Controlli HSV")
        hsv_layout = QGridLayout(hsv_group)

        # Lower bounds
        hsv_layout.addWidget(QLabel("Limite Inferiore:"), 0, 0)

        hsv_layout.addWidget(QLabel("H Min:"), 1, 0)
        self.h_min_spin = QSpinBox()
        self.h_min_spin.setRange(0, 179)
        self.h_min_spin.setValue(self.skin_detection_params['lower_skin'][0])
        hsv_layout.addWidget(self.h_min_spin, 1, 1)

        hsv_layout.addWidget(QLabel("S Min:"), 2, 0)
        self.s_min_spin = QSpinBox()
        self.s_min_spin.setRange(0, 255)
        self.s_min_spin.setValue(self.skin_detection_params['lower_skin'][1])
        hsv_layout.addWidget(self.s_min_spin, 2, 1)

        hsv_layout.addWidget(QLabel("V Min:"), 3, 0)
        self.v_min_spin = QSpinBox()
        self.v_min_spin.setRange(0, 255)
        self.v_min_spin.setValue(self.skin_detection_params['lower_skin'][2])
        hsv_layout.addWidget(self.v_min_spin, 3, 1)

        # Upper bounds
        hsv_layout.addWidget(QLabel("Limite Superiore:"), 0, 2)

        hsv_layout.addWidget(QLabel("H Max:"), 1, 2)
        self.h_max_spin = QSpinBox()
        self.h_max_spin.setRange(0, 179)
        self.h_max_spin.setValue(self.skin_detection_params['upper_skin'][0])
        hsv_layout.addWidget(self.h_max_spin, 1, 3)

        hsv_layout.addWidget(QLabel("S Max:"), 2, 2)
        self.s_max_spin = QSpinBox()
        self.s_max_spin.setRange(0, 255)
        self.s_max_spin.setValue(self.skin_detection_params['upper_skin'][1])
        hsv_layout.addWidget(self.s_max_spin, 2, 3)

        hsv_layout.addWidget(QLabel("V Max:"), 3, 2)
        self.v_max_spin = QSpinBox()
        self.v_max_spin.setRange(0, 255)
        self.v_max_spin.setValue(self.skin_detection_params['upper_skin'][2])
        hsv_layout.addWidget(self.v_max_spin, 3, 3)

        layout.addWidget(hsv_group)

        # Pulsanti di calibrazione
        calib_buttons = QHBoxLayout()

        self.auto_calibrate_button = QPushButton("🔍 Calibrazione Automatica")
        self.auto_calibrate_button.clicked.connect(self.auto_calibrate)
        calib_buttons.addWidget(self.auto_calibrate_button)

        self.save_calibration_button = QPushButton("💾 Salva Calibrazione")
        self.save_calibration_button.clicked.connect(self.save_calibration)
        calib_buttons.addWidget(self.save_calibration_button)

        layout.addLayout(calib_buttons)

        self.tab_widget.addTab(calib_widget, "🎨 Calibrazione")

    def setup_interaction_tab(self):
        """Configura il tab per le interazioni"""
        interaction_widget = QWidget()
        layout = QVBoxLayout(interaction_widget)

        # Impostazioni interazione
        interaction_group = QGroupBox("🎮 Impostazioni Interazione")
        interaction_layout = QVBoxLayout(interaction_group)

        # Modalità interazione
        self.interaction_checkbox = QCheckBox("Abilita Interazione con l'Interfaccia")
        self.interaction_checkbox.setChecked(self.interaction_mode)
        self.interaction_checkbox.stateChanged.connect(self.toggle_interaction_mode)
        interaction_layout.addWidget(self.interaction_checkbox)

        # Timer drag
        drag_layout = QHBoxLayout()
        drag_layout.addWidget(QLabel("Timer Drag (secondi):"))
        self.drag_timer_spin = QSpinBox()
        self.drag_timer_spin.setRange(1, 10)
        self.drag_timer_spin.setValue(int(self.gesture_params['drag_timer_threshold']))
        drag_layout.addWidget(self.drag_timer_spin)
        interaction_layout.addLayout(drag_layout)

        # Zona di interazione
        zone_group = QGroupBox("🎯 Zona di Interazione")
        zone_layout = QGridLayout(zone_group)

        zone_layout.addWidget(QLabel("Margine Sinistro:"), 0, 0)
        self.margin_left_spin = QSpinBox()
        self.margin_left_spin.setRange(0, 200)
        self.margin_left_spin.setValue(50)
        zone_layout.addWidget(self.margin_left_spin, 0, 1)

        zone_layout.addWidget(QLabel("Margine Superiore:"), 1, 0)
        self.margin_top_spin = QSpinBox()
        self.margin_top_spin.setRange(0, 200)
        self.margin_top_spin.setValue(100)
        zone_layout.addWidget(self.margin_top_spin, 1, 1)

        zone_layout.addWidget(QLabel("Larghezza (%):"), 2, 0)
        self.zone_width_spin = QSpinBox()
        self.zone_width_spin.setRange(10, 50)
        self.zone_width_spin.setValue(33)
        zone_layout.addWidget(self.zone_width_spin, 2, 1)

        zone_layout.addWidget(QLabel("Altezza (%):"), 3, 0)
        self.zone_height_spin = QSpinBox()
        self.zone_height_spin.setRange(10, 50)
        self.zone_height_spin.setValue(70)
        zone_layout.addWidget(self.zone_height_spin, 3, 1)

        interaction_layout.addWidget(zone_group)

        layout.addWidget(interaction_group)

        # Log delle interazioni
        log_group = QGroupBox("📝 Log Interazioni")
        log_layout = QVBoxLayout(log_group)

        self.interaction_log = QTextEdit()
        self.interaction_log.setMaximumHeight(200)
        self.interaction_log.setReadOnly(True)
        log_layout.addWidget(self.interaction_log)

        layout.addWidget(log_group)

        self.tab_widget.addTab(interaction_widget, "🎮 Interazione")

    def setup_statistics_tab(self):
        """Configura il tab per le statistiche"""
        stats_widget = QWidget()
        layout = QVBoxLayout(stats_widget)

        # Statistiche generali
        general_stats = QGroupBox("📊 Statistiche Generali")
        general_layout = QVBoxLayout(general_stats)

        self.total_frames_label = QLabel("Frame Totali: 0")
        general_layout.addWidget(self.total_frames_label)

        self.hands_detected_label = QLabel("Mani Rilevate: 0")
        general_layout.addWidget(self.hands_detected_label)

        self.gestures_detected_label = QLabel("Gesti Rilevati: 0")
        general_layout.addWidget(self.gestures_detected_label)

        self.interactions_count_label = QLabel("Interazioni: 0")
        general_layout.addWidget(self.interactions_count_label)

        layout.addWidget(general_stats)

        # Statistiche per mano
        hands_stats = QGroupBox("🤏 Statistiche per Mano")
        hands_layout = QGridLayout(hands_stats)

        hands_layout.addWidget(QLabel("Mano Sinistra:"), 0, 0)
        self.left_stats_label = QLabel("Gesti: 0, Conf: 0.0")
        hands_layout.addWidget(self.left_stats_label, 0, 1)

        hands_layout.addWidget(QLabel("Mano Destra:"), 1, 0)
        self.right_stats_label = QLabel("Gesti: 0, Conf: 0.0")
        hands_layout.addWidget(self.right_stats_label, 1, 1)

        layout.addWidget(hands_stats)

        # Pulsante reset
        reset_button = QPushButton("🔄 Reset Statistiche")
        reset_button.clicked.connect(self.reset_statistics)
        layout.addWidget(reset_button)

        self.tab_widget.addTab(stats_widget, "📈 Statistiche")

    def setup_connections(self):
        """Configura le connessioni dei segnali"""
        # Connetti i controlli dei parametri
        self.solidity_slider.valueChanged.connect(
            lambda v: self.update_gesture_param('solidity_threshold', v/100))
        self.finger_slider.valueChanged.connect(
            lambda v: self.update_gesture_param('finger_threshold', v))

        # Connetti i controlli HSV
        self.h_min_spin.valueChanged.connect(self.update_hsv_params)
        self.s_min_spin.valueChanged.connect(self.update_hsv_params)
        self.v_min_spin.valueChanged.connect(self.update_hsv_params)
        self.h_max_spin.valueChanged.connect(self.update_hsv_params)
        self.s_max_spin.valueChanged.connect(self.update_hsv_params)
        self.v_max_spin.valueChanged.connect(self.update_hsv_params)

    def analyze_hands(self):
        """Analizza le mani nel frame corrente"""
        if not self.is_active or self.current_frame is None:
            return

        # Rilevamento delle mani
        hands_info = self.detect_hands_in_frame(self.current_frame)

        # Aggiorna lo stato delle mani
        for hand_type, info in hands_info.items():
            if hand_type == 'left':
                self.left_hand.update(info)
            elif hand_type == 'right':
                self.right_hand.update(info)

        # Aggiorna l'interfaccia
        self.update_hand_display()

        # Gestisci le interazioni
        if self.interaction_mode:
            self.handle_interactions()

    def detect_hands_in_frame(self, frame):
        """Rileva le mani nel frame fornito"""
        hands_info = {'left': {'position': None, 'fingers': 0, 'gesture': 'unknown', 'confidence': 0},
                     'right': {'position': None, 'fingers': 0, 'gesture': 'unknown', 'confidence': 0}}

        try:
            # Conversione HSV
            hsv = cv2.cvtColor(frame, cv2.COLOR_BGR2HSV)

            # Maschera per il colore della pelle
            mask = cv2.inRange(hsv, self.skin_detection_params['lower_skin'],
                             self.skin_detection_params['upper_skin'])

            # Operazioni morfologiche
            kernel = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (7, 7))
            mask = cv2.morphologyEx(mask, cv2.MORPH_CLOSE, kernel)
            mask = cv2.morphologyEx(mask, cv2.MORPH_OPEN, kernel)

            # Trova contorni
            contours, _ = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_TC89_L1)

            valid_hands = []
            for contour in contours:
                area = cv2.contourArea(contour)
                if (self.skin_detection_params['min_area'] < area < self.skin_detection_params['max_area']):
                    x, y, w, h = cv2.boundingRect(contour)
                    aspect_ratio = w / h if h > 0 else 0

                    if (self.skin_detection_params['aspect_ratio_min'] < aspect_ratio < self.skin_detection_params['aspect_ratio_max']):
                        valid_hands.append((x, y, w, h, contour))

            # Analizza le mani valide
            for x, y, w, h, contour in valid_hands:
                center_x = x + w // 2

                # Determina se è destra o sinistra
                if center_x < frame.shape[1] // 2:
                    hand_type = 'left'
                else:
                    hand_type = 'right'

                # Analizza la forma
                gesture_info = self.analyze_hand_shape(contour, x, y, w, h)

                hands_info[hand_type] = {
                    'position': (center_x, y + h // 2),
                    'fingers': gesture_info['fingers'],
                    'gesture': gesture_info['gesture'],
                    'confidence': gesture_info['confidence']
                }

        except Exception as e:
            if self.debug_mode:
                logging.error(f"Errore nel rilevamento delle mani: {e}")

        return hands_info

    def analyze_hand_shape(self, contour, x, y, w, h):
        """Analizza la forma della mano per determinare il gesto"""
        try:
            # Calcola la convessità
            hull = cv2.convexHull(contour)
            hull_area = cv2.contourArea(hull)
            contour_area = cv2.contourArea(contour)

            if hull_area > 0:
                solidity = contour_area / hull_area
            else:
                solidity = 0

            # Calcola il perimetro e la compattezza
            perimeter = cv2.arcLength(contour, True)
            if perimeter > 0:
                compactness = (4 * math.pi * contour_area) / (perimeter * perimeter)
            else:
                compactness = 0

            # Analisi dei difetti di convessità per contare le dita
            finger_count = self.count_fingers(contour)

            # Determina il gesto basato sui parametri
            if finger_count >= 4 and solidity > self.gesture_params['solidity_threshold']:
                gesture = "Mano Aperta"
            elif finger_count <= 2 or solidity < 0.65:
                gesture = "Mano Chiusa"
            else:
                gesture = "Gesto Parziale"

            # Calcola la confidenza
            confidence = min(1.0, (finger_count * 0.2) + (solidity * 0.3) + 0.3)

            return {
                'fingers': finger_count,
                'gesture': gesture,
                'confidence': confidence,
                'solidity': solidity,
                'compactness': compactness
            }

        except Exception as e:
            if self.debug_mode:
                logging.error(f"Errore nell'analisi della forma: {e}")
            return {'fingers': 0, 'gesture': 'unknown', 'confidence': 0, 'solidity': 0, 'compactness': 0}

    def count_fingers(self, contour):
        """Conta le dita nella mano"""
        try:
            hull_indices = cv2.convexHull(contour, returnPoints=False)
            defects = cv2.convexityDefects(contour, hull_indices)

            finger_count = 0
            if defects is not None:
                for i in range(defects.shape[0]):
                    s, e, f, d = defects[i, 0]
                    start = tuple(contour[s][0])
                    end = tuple(contour[e][0])
                    far = tuple(contour[f][0])

                    # Calcola la profondità del difetto
                    a = math.sqrt((end[0] - start[0])**2 + (end[1] - start[1])**2)
                    b = math.sqrt((far[0] - start[0])**2 + (far[1] - start[1])**2)
                    c = math.sqrt((end[0] - far[0])**2 + (end[1] - far[1])**2)

                    if a > 0:
                        area = math.sqrt(max(0, (s * (s - a) * (s - b) * (s - c))))
                        distance = (2 * area) / a
                    else:
                        distance = 0

                    # Conta le dita
                    if distance > self.gesture_params['finger_threshold']:
                        finger_count += 1

            return finger_count

        except Exception as e:
            if self.debug_mode:
                logging.error(f"Errore nel conteggio delle dita: {e}")
            return 0

    def update_hand_display(self):
        """Aggiorna la visualizzazione delle informazioni sulle mani"""
        # Aggiorna mano sinistra
        if self.left_hand['position'] is not None:
            left_text = f"Gesto: {self.left_hand['gesture']}, Dita: {self.left_hand['fingers']}, Conf: {self.left_hand['confidence']:.2f}"
            self.left_hand_label.setText(left_text)
            self.left_hand_label.setStyleSheet("color: blue; font-weight: bold;")
        else:
            self.left_hand_label.setText("Non rilevata")
            self.left_hand_label.setStyleSheet("color: gray;")

        # Aggiorna mano destra
        if self.right_hand['position'] is not None:
            right_text = f"Gesto: {self.right_hand['gesture']}, Dita: {self.right_hand['fingers']}, Conf: {self.right_hand['confidence']:.2f}"
            self.right_hand_label.setText(right_text)
            self.right_hand_label.setStyleSheet("color: green; font-weight: bold;")
        else:
            self.right_hand_label.setText("Non rilevata")
            self.right_hand_label.setStyleSheet("color: gray;")

        # Log dei gesti se cambiati
        if self.left_hand['gesture'] != self.left_hand['last_gesture']:
            self.gesture_log.append(f"🫲 SX: {self.left_hand['gesture']}")
            self.left_hand['last_gesture'] = self.left_hand['gesture']

        if self.right_hand['gesture'] != self.right_hand['last_gesture']:
            self.gesture_log.append(f"🫱 DX: {self.right_hand['gesture']}")
            self.right_hand['last_gesture'] = self.right_hand['gesture']

        # Limita il log a 50 righe
        if self.gesture_log.toPlainText().count('\n') > 50:
            cursor = self.gesture_log.textCursor()
            cursor.movePosition(cursor.MoveOperation.Start)
            cursor.movePosition(cursor.MoveOperation.Down, cursor.MoveMode.MoveAnchor, 10)
            cursor.select(cursor.SelectionType.LineUnderCursor)
            cursor.removeSelectedText()
            cursor.deletePreviousChar()

    def handle_interactions(self):
        """Gestisce le interazioni delle mani con l'interfaccia"""
        # Qui implementeremmo la logica di interazione
        # Per ora, solo logging
        if self.debug_mode:
            if self.left_hand['gesture'] == "Mano Chiusa":
                self.interaction_log.append("🫲 Mano sinistra chiusa - Pronto per interazione")
            if self.right_hand['gesture'] == "Mano Chiusa":
                self.interaction_log.append("🫱 Mano destra chiusa - Pronto per interazione")

    def set_current_frame(self, frame):
        """Imposta il frame corrente per l'analisi"""
        self.current_frame = frame

        # Aggiorna l'anteprima se disponibile
        if hasattr(self, 'preview_label') and frame is not None:
            try:
                # Converti per la visualizzazione
                rgb_frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
                height, width, channel = rgb_frame.shape
                bytes_per_line = 3 * width
                qt_image = QImage(rgb_frame.data, width, height, bytes_per_line, QImage.Format.Format_RGB888)

                pixmap = QPixmap.fromImage(qt_image)
                scaled_pixmap = pixmap.scaled(400, 300, Qt.AspectRatioMode.KeepAspectRatio)
                self.preview_label.setPixmap(scaled_pixmap)

            except Exception as e:
                if self.debug_mode:
                    logging.error(f"Errore nell'aggiornamento dell'anteprima: {e}")

    def apply_configuration(self):
        """Applica la configurazione corrente"""
        try:
            # Aggiorna parametri di rilevamento
            self.skin_detection_params.update({
                'min_area': self.min_area_spin.value(),
                'max_area': self.max_area_spin.value(),
                'aspect_ratio_min': self.aspect_min_spin.value() / 100,
                'aspect_ratio_max': self.aspect_max_spin.value() / 100
            })

            # Aggiorna parametri dei gesti
            self.gesture_params.update({
                'solidity_threshold': self.solidity_slider.value() / 100,
                'finger_threshold': self.finger_slider.value()
            })

            QMessageBox.information(self, "Configurazione Applicata",
                                  "✅ La configurazione è stata applicata con successo!")

        except Exception as e:
            QMessageBox.critical(self, "Errore", f"❌ Errore nell'applicazione della configurazione: {str(e)}")

    def reset_configuration(self):
        """Reset alla configurazione predefinita"""
        self.skin_detection_params = {
            'lower_skin': np.array([0, 20, 70], dtype=np.uint8),
            'upper_skin': np.array([20, 255, 255], dtype=np.uint8),
            'min_area': 5000,
            'max_area': 50000,
            'aspect_ratio_min': 0.4,
            'aspect_ratio_max': 2.5
        }

        self.gesture_params = {
            'solidity_threshold': 0.7,
            'finger_threshold': 20,
            'compactness_open': 0.4,
            'compactness_closed': 0.6,
            'drag_timer_threshold': 6.0
        }

        QMessageBox.information(self, "Reset Completato",
                              "🔄 Configurazione resettata ai valori predefiniti!")

    def auto_calibrate(self):
        """Calibrazione automatica del colore della pelle"""
        QMessageBox.information(self, "Calibrazione Automatica",
                              "🔍 Funzionalità di calibrazione automatica da implementare")

    def save_calibration(self):
        """Salva la calibrazione corrente"""
        try:
            self.skin_detection_params['lower_skin'] = np.array([
                self.h_min_spin.value(),
                self.s_min_spin.value(),
                self.v_min_spin.value()
            ], dtype=np.uint8)

            self.skin_detection_params['upper_skin'] = np.array([
                self.h_max_spin.value(),
                self.s_max_spin.value(),
                self.v_max_spin.value()
            ], dtype=np.uint8)

            QMessageBox.information(self, "Calibrazione Salvata",
                                  "💾 La calibrazione del colore della pelle è stata salvata!")

        except Exception as e:
            QMessageBox.critical(self, "Errore", f"❌ Errore nel salvataggio della calibrazione: {str(e)}")

    def toggle_interaction_mode(self, state):
        """Attiva/disattiva la modalità interazione"""
        self.interaction_mode = bool(state)
        if self.interaction_mode:
            self.status_label.setText("🎮 Modalità interazione attiva")
        else:
            self.status_label.setText("✅ Controller pronto")

    def update_gesture_param(self, param, value):
        """Aggiorna un parametro dei gesti"""
        if param == 'solidity_threshold':
            self.gesture_params[param] = value
            self.solidity_label.setText(f"{value:.2f}")
        elif param == 'finger_threshold':
            self.gesture_params[param] = value
            self.finger_label.setText(str(value))

    def update_hsv_params(self):
        """Aggiorna i parametri HSV"""
        # I valori vengono letti direttamente dagli spin box quando necessario
        pass

    def reset_statistics(self):
        """Resetta le statistiche"""
        self.total_frames_label.setText("Frame Totali: 0")
        self.hands_detected_label.setText("Mani Rilevate: 0")
        self.gestures_detected_label.setText("Gesti Rilevati: 0")
        self.interactions_count_label.setText("Interazioni: 0")
        self.left_stats_label.setText("Gesti: 0, Conf: 0.0")
        self.right_stats_label.setText("Gesti: 0, Conf: 0.0")

    def closeEvent(self, event):
        """Gestisce la chiusura della finestra"""
        self.analysis_timer.stop()
        self.drag_timer.stop()
        event.accept()

# Funzione per creare e mostrare il controller
def show_hand_controller(parent=None):
    """Crea e mostra il controller delle mani"""
    controller = HandController(parent)
    controller.show()
    return controller

if __name__ == "__main__":
    # Test standalone del controller
    from PyQt6.QtWidgets import QApplication
    import sys

    app = QApplication(sys.argv)
    controller = show_hand_controller()
    sys.exit(app.exec())