# advanced_detection_system.py

import cv2
import logging
from typing import Dict, List, Tuple, Optional, Any

# Import condizionale per gestire dipendenze mancanti
try:
    from mediapipe_detector import MediaPipeHandDetector
    from mediapipe_face_detector import MediaPipeFaceDetector
    MEDIAPIPE_AVAILABLE = True
except ImportError:
    MEDIAPIPE_AVAILABLE = False
    logging.warning("MediaPipe detectors non disponibili")

try:
    from person_detector import PersonDetector
    from hand_palm_detector import HandPalmDetector
    LEGACY_DETECTORS_AVAILABLE = True
except ImportError:
    LEGACY_DETECTORS_AVAILABLE = False
    logging.warning("Legacy detectors non disponibili")

class AdvancedDetectionSystem:
    """
    Sistema avanzato di rilevamento che combina MediaPipe e rilevatori legacy.
    Fornisce rilevamento di mani, espressioni facciali e persone con alta accuratezza.
    """

    def __init__(self, config: Optional[Dict[str, Any]] = None):
        """
        Inizializza il sistema di rilevamento avanzato.

        Args:
            config: Configurazione del sistema
        """
        self.logger = logging.getLogger("AdvancedDetectionSystem")

        # Configurazione di default
        self.default_config = {
            'use_mediapipe': True,           # Preferisci MediaPipe se disponibile
            'fallback_to_legacy': True,      # Usa rilevatori legacy come fallback
            'hand_detection': True,          # Rilevamento mani
            'face_detection': True,          # Rilevamento facce/espressioni
            'person_detection': True,        # Rilevamento persone
            'show_landmarks': True,          # Mostra landmark
            'show_expressions': True,        # Mostra espressioni
            'show_gestures': True,           # Mostra gesti
            'min_confidence': 0.5,           # Confidenza minima
            'max_detections': 5              # Numero max rilevazioni
        }

        self.config = {**self.default_config, **(config or {})}

        # Inizializza i rilevatori
        self.mediapipe_hand_detector = None
        self.mediapipe_face_detector = None
        self.legacy_person_detector = None
        self.legacy_hand_detector = None

        self._initialize_detectors()

        self.logger.info("Sistema di rilevamento avanzato inizializzato")

    def _initialize_detectors(self):
        """Inizializza tutti i rilevatori disponibili."""
        # MediaPipe detectors (preferiti)
        if MEDIAPIPE_AVAILABLE and self.config.get('use_mediapipe', True):
            try:
                self.mediapipe_hand_detector = MediaPipeHandDetector(
                    enabled=self.config.get('hand_detection', True)
                )
                self.logger.info("MediaPipe Hand Detector inizializzato")
            except Exception as e:
                self.logger.error(f"Errore inizializzazione MediaPipe Hand: {e}")

            try:
                self.mediapipe_face_detector = MediaPipeFaceDetector(
                    enabled=self.config.get('face_detection', True)
                )
                self.logger.info("MediaPipe Face Detector inizializzato")
            except Exception as e:
                self.logger.error(f"Errore inizializzazione MediaPipe Face: {e}")

        # Legacy detectors (fallback)
        if LEGACY_DETECTORS_AVAILABLE and self.config.get('fallback_to_legacy', True):
            if not self.mediapipe_hand_detector and self.config.get('hand_detection', True):
                try:
                    self.legacy_hand_detector = HandPalmDetector(
                        enabled=self.config.get('hand_detection', True)
                    )
                    self.logger.info("Legacy Hand Detector inizializzato")
                except Exception as e:
                    self.logger.error(f"Errore inizializzazione Legacy Hand: {e}")

            if not self.mediapipe_face_detector and self.config.get('face_detection', True):
                try:
                    self.legacy_person_detector = PersonDetector(
                        enabled=self.config.get('person_detection', True)
                    )
                    self.logger.info("Legacy Person Detector inizializzato")
                except Exception as e:
                    self.logger.error(f"Errore inizializzazione Legacy Person: {e}")

    def detect_objects(self, frame) -> Tuple[bool, Dict[str, List[Dict[str, Any]]]]:
        """
        Rileva oggetti nel frame usando tutti i rilevatori disponibili.
        Include rilevamento di occhiali e accessori.

        Args:
            frame: Il frame da analizzare

        Returns:
            Tuple[bool, Dict[str, List[Dict[str, Any]]]]:
                (rilevamento_successo, {'hands': [...], 'faces': [...], 'persons': [...], 'gestures': [...], 'expressions': [...], 'accessories': [...]})
        """
        try:
            self.frame_count += 1
            results = {
                'hands': [],
                'faces': [],
                'persons': [],
                'gestures': [],
                'expressions': [],
                'accessories': []  # Nuovi: occhiali, cappelli, etc.
            }

            # Rilevamento mani
            if self.config.get('hand_detection', True):
                hand_results = self._detect_hands(frame)
                results['hands'] = hand_results.get('hands', [])
                results['gestures'] = hand_results.get('gestures', [])

            # Rilevamento facce/espressioni
            if self.config.get('face_detection', True):
                face_results = self._detect_faces(frame)
                results['faces'] = face_results.get('faces', [])
                results['expressions'] = face_results.get('expressions', [])

                # Analizza accessori (occhiali, etc.)
                accessories = self._detect_accessories(frame, results['faces'])
                results['accessories'] = accessories

            # Rilevamento persone (legacy)
            if self.config.get('person_detection', True) and not self.mediapipe_face_detector:
                person_results = self._detect_persons(frame)
                results['persons'] = person_results.get('persons', [])

            # Filtra per confidenza minima
            min_confidence = self.config.get('min_confidence', 0.5)
            results = self._filter_by_confidence(results, min_confidence)

            # Limita numero di rilevazioni
            max_detections = self.config.get('max_detections', 5)
            results = self._limit_detections(results, max_detections)

            success = any(len(v) > 0 for v in results.values() if isinstance(v, list))

            if success:
                self.logger.debug(f"Frame {self.frame_count}: rilevati oggetti: {dict((k, len(v)) for k, v in results.items() if isinstance(v, list))}")

            return success, results

        except Exception as e:
            self.logger.error(f"Errore nel rilevamento oggetti: {e}")
            return False, {'hands': [], 'faces': [], 'persons': [], 'gestures': [], 'expressions': [], 'accessories': []}

    def _detect_hands(self, frame) -> Dict[str, List[Dict[str, Any]]]:
        """Rileva le mani usando il miglior rilevatore disponibile."""
        try:
            if self.mediapipe_hand_detector and self.mediapipe_hand_detector.is_enabled():
                success, hands = self.mediapipe_hand_detector.detect_hands(frame)
                if success and hands:
                    gestures = []
                    for hand in hands:
                        gesture = hand.get('gesture', 'unknown')
                        gestures.append({
                            'gesture': gesture,
                            'confidence': hand.get('confidence', 0),
                            'hand_info': hand
                        })
                    return {'hands': hands, 'gestures': gestures}

            # Fallback al rilevatore legacy
            if self.legacy_hand_detector and self.legacy_hand_detector.is_enabled():
                success, hands = self.legacy_hand_detector.detect(frame)
                if success and hands:
                    gestures = []
                    for hand in hands:
                        gesture = self.legacy_hand_detector.get_hand_gesture(hand)
                        gestures.append({
                            'gesture': gesture,
                            'confidence': hand.get('confidence', 0),
                            'hand_info': hand
                        })
                    return {'hands': hands, 'gestures': gestures}

            return {'hands': [], 'gestures': []}

        except Exception as e:
            self.logger.error(f"Errore nel rilevamento mani: {e}")
            return {'hands': [], 'gestures': []}

    def _detect_faces(self, frame) -> Dict[str, List[Dict[str, Any]]]:
        """Rileva le facce e le espressioni usando il miglior rilevatore disponibile."""
        try:
            if self.mediapipe_face_detector and self.mediapipe_face_detector.is_enabled():
                success, faces = self.mediapipe_face_detector.detect_faces(frame)
                if success and faces:
                    expressions = []
                    for face in faces:
                        expression = face.get('expression', 'neutra')
                        expressions.append({
                            'expression': expression,
                            'confidence': face.get('confidence', 0),
                            'face_info': face
                        })
                    return {'faces': faces, 'expressions': expressions}

            return {'faces': [], 'expressions': []}

        except Exception as e:
            self.logger.error(f"Errore nel rilevamento facce: {e}")
            return {'faces': [], 'expressions': []}

    def _detect_persons(self, frame) -> Dict[str, List[Dict[str, Any]]]:
        """Rileva le persone usando il rilevatore legacy."""
        try:
            if self.legacy_person_detector and self.legacy_person_detector.is_enabled():
                success, persons = self.legacy_person_detector.detect(frame)
                if success and persons:
                    return {'persons': persons}

            return {'persons': []}

        except Exception as e:
            self.logger.error(f"Errore nel rilevamento persone: {e}")
            return {'persons': []}

    def _detect_accessories(self, frame, faces) -> List[Dict[str, Any]]:
        """Rileva accessori come occhiali, cappelli, etc."""
        try:
            accessories = []

            for face in faces:
                if face.get('type') == 'face' or 'landmarks' in face:
                    # Rilevamento occhiali
                    has_glasses = self._detect_glasses_from_face(frame, face)
                    if has_glasses:
                        accessories.append({
                            'type': 'glasses',
                            'confidence': has_glasses.get('confidence', 0.5),
                            'position': has_glasses.get('position', {}),
                            'face_id': face.get('face_index', 0)
                        })

                    # Rilevamento cappello (se implementato)
                    has_hat = self._detect_hat_from_face(frame, face)
                    if has_hat:
                        accessories.append({
                            'type': 'hat',
                            'confidence': has_hat.get('confidence', 0.5),
                            'position': has_hat.get('position', {}),
                            'face_id': face.get('face_index', 0)
                        })

            return accessories

        except Exception as e:
            self.logger.error(f"Errore nel rilevamento accessori: {e}")
            return []

    def _detect_glasses_from_face(self, frame, face) -> Optional[Dict[str, Any]]:
        """Rileva occhiali da una faccia rilevata."""
        try:
            if 'landmarks' not in face:
                return None

            landmarks = face['landmarks']
            if len(landmarks) < 20:
                return None

            # Trova landmark occhi
            left_eye_region = [landmarks[i] for i in range(130, 140) if i < len(landmarks)]
            right_eye_region = [landmarks[i] for i in range(350, 360) if i < len(landmarks)]

            if not left_eye_region or not right_eye_region:
                return None

            # Calcola area intorno agli occhi
            left_eye_center = self._calculate_region_center(left_eye_region)
            right_eye_center = self._calculate_region_center(right_eye_region)

            if left_eye_center and right_eye_center:
                # Estrai regione tra gli occhi
                eye_distance = abs(right_eye_center['x'] - left_eye_center['x'])
                region_size = int(eye_distance * 1.5)

                x1 = max(0, int((left_eye_center['x'] + right_eye_center['x']) / 2 - region_size / 2))
                y1 = max(0, int(min(left_eye_center['y'], right_eye_center['y']) - region_size / 3))
                x2 = min(frame.shape[1], x1 + region_size)
                y2 = min(frame.shape[0], y1 + region_size)

                if x2 > x1 and y2 > y1:
                    eye_region = frame[y1:y2, x1:x2]

                    # Analizza per rilevare occhiali
                    glasses_confidence = self._analyze_glasses_region(eye_region)

                    if glasses_confidence > 0.6:  # Soglia per considerare presenza occhiali
                        return {
                            'confidence': glasses_confidence,
                            'position': {
                                'x': x1,
                                'y': y1,
                                'width': x2 - x1,
                                'height': y2 - y1
                            }
                        }

            return None

        except Exception as e:
            self.logger.error(f"Errore nel rilevamento occhiali: {e}")
            return None

    def _detect_hat_from_face(self, frame, face) -> Optional[Dict[str, Any]]:
        """Rileva cappello da una faccia rilevata."""
        try:
            if 'landmarks' not in face:
                return None

            landmarks = face['landmarks']
            if len(landmarks) < 10:
                return None

            # Usa landmark della fronte e testa
            forehead_landmarks = [landmarks[i] for i in range(9, 11) if i < len(landmarks)]

            if forehead_landmarks:
                forehead_center = self._calculate_region_center(forehead_landmarks)

                # Estrai regione sopra la fronte
                region_size = 100
                x1 = max(0, int(forehead_center['x'] - region_size / 2))
                y1 = max(0, int(forehead_center['y'] - region_size))
                x2 = min(frame.shape[1], x1 + region_size)
                y2 = forehead_center['y']  # Solo fino alla fronte

                if x2 > x1 and y2 > y1:
                    hat_region = frame[y1:y2, x1:x2]

                    # Analizza per rilevare cappello
                    hat_confidence = self._analyze_hat_region(hat_region)

                    if hat_confidence > 0.5:
                        return {
                            'confidence': hat_confidence,
                            'position': {
                                'x': x1,
                                'y': y1,
                                'width': x2 - x1,
                                'height': y2 - y1
                            }
                        }

            return None

        except Exception as e:
            self.logger.error(f"Errore nel rilevamento cappello: {e}")
            return None

    def _calculate_region_center(self, landmarks) -> Optional[Dict[str, float]]:
        """Calcola il centro di una regione di landmark."""
        try:
            if not landmarks:
                return None

            x_coords = [lm['x'] for lm in landmarks]
            y_coords = [lm['y'] for lm in landmarks]

            return {
                'x': sum(x_coords) / len(x_coords),
                'y': sum(y_coords) / len(y_coords)
            }

        except Exception as e:
            return None

    def _analyze_glasses_region(self, region) -> float:
        """Analizza una regione per rilevare occhiali."""
        try:
            if region.size == 0:
                return 0.0

            # Converti in scala di grigi
            gray = cv2.cvtColor(region, cv2.COLOR_BGR2GRAY)

            # Migliora contrasto
            gray = cv2.equalizeHist(gray)

            # Rileva bordi
            edges = cv2.Canny(gray, 50, 150)

            # Calcola densità dei bordi
            edge_pixels = np.count_nonzero(edges)
            total_pixels = region.shape[0] * region.shape[1]
            edge_density = edge_pixels / total_pixels if total_pixels > 0 else 0

            # Analizza simmetria (occhiali sono simmetrici)
            height, width = gray.shape
            left_half = gray[:, :width//2]
            right_half = cv2.flip(gray[:, width//2:], 1)  # Flip orizzontale

            # Calcola differenza tra metà sinistra e destra
            diff = cv2.absdiff(left_half, right_half)
            symmetry_score = 1.0 - (np.mean(diff) / 255.0)

            # Combina i punteggi
            confidence = (edge_density * 0.6) + (symmetry_score * 0.4)

            return min(confidence, 1.0)

        except Exception as e:
            return 0.0

    def _analyze_hat_region(self, region) -> float:
        """Analizza una regione per rilevare cappello."""
        try:
            if region.size == 0:
                return 0.0

            # Converti in HSV per analizzare colori
            hsv = cv2.cvtColor(region, cv2.COLOR_BGR2HSV)

            # Analizza distribuzione dei colori
            hist = cv2.calcHist([hsv], [0, 1], None, [30, 32], [0, 180, 0, 256])
            hist = cv2.normalize(hist, hist).flatten()

            # Calcola entropia del colore (cappelli spesso hanno colori uniformi)
            entropy = -np.sum(hist * np.log2(hist + 1e-10))

            # Analizza forma (cappelli spesso hanno contorni curvi)
            gray = cv2.cvtColor(region, cv2.COLOR_BGR2GRAY)
            edges = cv2.Canny(gray, 30, 100)

            # Trova contorni
            contours, _ = cv2.findContours(edges, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

            if contours:
                # Analizza il contorno più grande
                largest_contour = max(contours, key=cv2.contourArea)
                area = cv2.contourArea(largest_contour)
                perimeter = cv2.arcLength(largest_contour, True)

                if perimeter > 0:
                    # Calcola circularity (cappelli spesso circolari)
                    circularity = 4 * np.pi * area / (perimeter * perimeter)

                    # Cappelli hanno circularity moderata
                    shape_score = 1.0 - abs(circularity - 0.5)
                else:
                    shape_score = 0.0
            else:
                shape_score = 0.0

            # Combina i punteggi
            confidence = (shape_score * 0.6) + ((1.0 - entropy) * 0.4)

            return min(confidence, 1.0)

        except Exception as e:
            return 0.0

    def _filter_by_confidence(self, results: Dict[str, List], min_confidence: float) -> Dict[str, List]:
        """Filtra i risultati per confidenza minima."""
        try:
            filtered = {}

            for key, items in results.items():
                if isinstance(items, list):
                    filtered_items = []
                    for item in items:
                        if isinstance(item, dict):
                            confidence = item.get('confidence', 0)
                            if confidence >= min_confidence:
                                filtered_items.append(item)
                        else:
                            filtered_items.append(item)
                    filtered[key] = filtered_items
                else:
                    filtered[key] = items

            return filtered

        except Exception as e:
            self.logger.error(f"Errore nel filtraggio per confidenza: {e}")
            return results

    def _limit_detections(self, results: Dict[str, List], max_count: int) -> Dict[str, List]:
        """Limita il numero di rilevazioni per categoria."""
        try:
            limited = {}

            for key, items in results.items():
                if isinstance(items, list):
                    limited[key] = items[:max_count]
                else:
                    limited[key] = items

            return limited

        except Exception as e:
            self.logger.error(f"Errore nel limitare rilevazioni: {e}")
            return results

    def draw_detections(self, frame, detections: Optional[Dict[str, List[Dict[str, Any]]]] = None):
        """
        Disegna tutte le rilevazioni sul frame.

        Args:
            frame: Il frame su cui disegnare
            detections: Dizionario con le rilevazioni (se None usa quelle dell'ultimo rilevamento)
        """
        try:
            if detections is None:
                return

            # Disegna mani
            if self.config.get('show_gestures', True) and 'hands' in detections:
                for hand in detections['hands']:
                    if self.mediapipe_hand_detector:
                        self.mediapipe_hand_detector.draw_hand_landmarks(frame, hand)
                    elif self.legacy_hand_detector:
                        self.legacy_hand_detector.draw_hand_palm_analysis(frame, hand)

            # Disegna facce/espressioni
            if self.config.get('show_expressions', True) and 'faces' in detections:
                for face in detections['faces']:
                    if self.mediapipe_face_detector:
                        self.mediapipe_face_detector.draw_face_landmarks(frame, face)

            # Disegna persone (legacy)
            if 'persons' in detections:
                for person in detections['persons']:
                    if self.legacy_person_detector:
                        self.legacy_person_detector.draw_person_analysis(frame, person)

            # Mostra statistiche
            self._draw_statistics(frame, detections)

        except Exception as e:
            self.logger.error(f"Errore nel disegno rilevazioni: {e}")

    def _draw_statistics(self, frame, detections):
        """Disegna le statistiche sul frame."""
        try:
            height, width = frame.shape[:2]

            # Conta rilevazioni
            stats = {}
            for key, items in detections.items():
                if isinstance(items, list):
                    stats[key] = len(items)

            # Mostra statistiche
            stats_text = f"Advanced Detection - "
            stats_parts = []
            if stats.get('hands', 0) > 0:
                stats_parts.append(f"Mani: {stats['hands']}")
            if stats.get('faces', 0) > 0:
                stats_parts.append(f"Facce: {stats['faces']}")
            if stats.get('persons', 0) > 0:
                stats_parts.append(f"Persone: {stats['persons']}")
            if stats.get('gestures', 0) > 0:
                stats_parts.append(f"Gesti: {stats['gestures']}")
            if stats.get('expressions', 0) > 0:
                stats_parts.append(f"Espressioni: {stats['expressions']}")

            stats_text += " | ".join(stats_parts) if stats_parts else "Nessuna rilevazione"

            cv2.putText(frame, stats_text, (10, height - 10),
                       cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255, 255, 255), 2)

            # Mostra sistema utilizzato
            system_text = "Sistema: "
            if self.mediapipe_hand_detector and self.mediapipe_hand_detector.is_enabled():
                system_text += "MediaPipe "
            elif self.legacy_hand_detector and self.legacy_hand_detector.is_enabled():
                system_text += "Legacy "

            if self.mediapipe_face_detector and self.mediapipe_face_detector.is_enabled():
                system_text += "FaceMesh"
            elif self.legacy_person_detector and self.legacy_person_detector.is_enabled():
                system_text += "Cascade"

            cv2.putText(frame, system_text, (10, height - 35),
                       cv2.FONT_HERSHEY_SIMPLEX, 0.5, (200, 200, 200), 1)

        except Exception as e:
            self.logger.error(f"Errore nel disegno statistiche: {e}")

    def get_detected_hands(self) -> List[Dict[str, Any]]:
        """Ottiene la lista delle mani rilevate."""
        # Questo metodo dovrebbe essere chiamato dopo detect_objects
        return []

    def get_detected_faces(self) -> List[Dict[str, Any]]:
        """Ottiene la lista delle facce rilevate."""
        return []

    def get_gestures(self) -> List[Dict[str, Any]]:
        """Ottiene la lista dei gesti rilevati."""
        return []

    def get_expressions(self) -> List[Dict[str, Any]]:
        """Ottiene la lista delle espressioni rilevate."""
        return []

    def update_config(self, new_config: Dict[str, Any]):
        """Aggiorna la configurazione del sistema."""
        try:
            self.config.update(new_config)

            # Aggiorna i rilevatori
            if 'hand_detection' in new_config:
                enabled = new_config['hand_detection']
                if self.mediapipe_hand_detector:
                    self.mediapipe_hand_detector.set_enabled(enabled)
                if self.legacy_hand_detector:
                    self.legacy_hand_detector.set_enabled(enabled)

            if 'face_detection' in new_config:
                enabled = new_config['face_detection']
                if self.mediapipe_face_detector:
                    self.mediapipe_face_detector.set_enabled(enabled)

            if 'person_detection' in new_config:
                enabled = new_config['person_detection']
                if self.legacy_person_detector:
                    self.legacy_person_detector.set_enabled(enabled)

            self.logger.info(f"Configurazione aggiornata: {new_config}")

        except Exception as e:
            self.logger.error(f"Errore nell'aggiornamento configurazione: {e}")

    def get_config(self) -> Dict[str, Any]:
        """Ottiene la configurazione corrente."""
        return self.config.copy()

    def get_system_info(self) -> Dict[str, Any]:
        """Ottiene informazioni sul sistema."""
        return {
            'mediapipe_available': MEDIAPIPE_AVAILABLE,
            'legacy_detectors_available': LEGACY_DETECTORS_AVAILABLE,
            'mediapipe_hand_enabled': self.mediapipe_hand_detector.is_enabled() if self.mediapipe_hand_detector else False,
            'mediapipe_face_enabled': self.mediapipe_face_detector.is_enabled() if self.mediapipe_face_detector else False,
            'legacy_hand_enabled': self.legacy_hand_detector.is_enabled() if self.legacy_hand_detector else False,
            'legacy_person_enabled': self.legacy_person_detector.is_enabled() if self.legacy_person_detector else False,
            'config': self.config
        }

    def reset(self):
        """Resetta lo stato del sistema."""
        self.logger.info("Sistema di rilevamento avanzato resettato")


# Istanza globale del sistema
advanced_detection_system = AdvancedDetectionSystem()

def get_advanced_detection_system() -> AdvancedDetectionSystem:
    """Ottiene l'istanza globale del sistema di rilevamento avanzato."""
    return advanced_detection_system

def initialize_advanced_detection(config: Optional[Dict[str, Any]] = None):
    """Inizializza il sistema di rilevamento avanzato."""
    global advanced_detection_system
    advanced_detection_system = AdvancedDetectionSystem(config)

def process_frame_with_advanced_detection(frame) -> Tuple[bool, Dict[str, List[Dict[str, Any]]]]:
    """Processa un frame con il sistema di rilevamento avanzato."""
    return advanced_detection_system.detect_objects(frame)

def draw_advanced_detections(frame, detections: Optional[Dict[str, List[Dict[str, Any]]]] = None):
    """Disegna le rilevazioni avanzate sul frame."""
    advanced_detection_system.draw_detections(frame, detections)