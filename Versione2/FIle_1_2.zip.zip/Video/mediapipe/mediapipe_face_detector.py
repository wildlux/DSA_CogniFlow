# mediapipe_face_detector.py

import cv2
import numpy as np
import logging
import math
from typing import Dict, List, Tuple, Optional, Any

try:
    import mediapipe as mp
    MEDIAPIPE_AVAILABLE = True
except ImportError:
    MEDIAPIPE_AVAILABLE = False
    logging.warning("MediaPipe non disponibile. Installare con: pip install mediapipe")

class MediaPipeFaceDetector:
    """
    Rilevatore avanzato di espressioni facciali usando MediaPipe Face Mesh.
    Rileva oltre 40 espressioni facciali con alta accuratezza.
    """

    def __init__(self, enabled: bool = True, max_faces: int = 1):
        self.enabled = enabled
        self.max_faces = max_faces
        self.logger = logging.getLogger("MediaPipeFaceDetector")

        if not MEDIAPIPE_AVAILABLE:
            self.logger.error("MediaPipe non disponibile")
            self.face_mesh = None
            return

        # Inizializza MediaPipe Face Mesh
        self.mp_face_mesh = mp.solutions.face_mesh
        self.mp_drawing = mp.solutions.drawing_utils
        self.mp_drawing_styles = mp.solutions.drawing_styles

        # Configurazione del rilevatore
        self.face_mesh = self.mp_face_mesh.FaceMesh(
            static_image_mode=False,
            max_num_faces=self.max_faces,
            min_detection_confidence=0.5,
            min_tracking_confidence=0.5,
            refine_landmarks=True  # Per landmarks più precisi
        )

        self.logger.info("MediaPipe Face Detector inizializzato")

        # Definizioni dei landmark per le espressioni
        self._initialize_expression_landmarks()

    def _initialize_expression_landmarks(self):
        """Inizializza i landmark per il riconoscimento delle espressioni."""
        # Landmark per gli occhi
        self.LEFT_EYE_LANDMARKS = [33, 133, 160, 159, 158, 144, 145, 153]
        self.RIGHT_EYE_LANDMARKS = [362, 263, 387, 386, 385, 373, 374, 380]

        # Landmark per la bocca
        self.MOUTH_LANDMARKS = [61, 62, 63, 64, 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80]

        # Landmark per le sopracciglia
        self.LEFT_EYEBROW_LANDMARKS = [70, 63, 105, 66, 107]
        self.RIGHT_EYEBROW_LANDMARKS = [336, 296, 334, 293, 300]

        # Landmark per il naso
        self.NOSE_LANDMARKS = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15]

    def detect_faces(self, frame) -> Tuple[bool, List[Dict[str, Any]]]:
        """Rileva le facce e analizza le espressioni usando MediaPipe."""
        if not self.enabled or not MEDIAPIPE_AVAILABLE or self.face_mesh is None:
            return False, []

        try:
            # Converti BGR a RGB per MediaPipe
            rgb_frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)

            # Processa il frame
            results = self.face_mesh.process(rgb_frame)

            if not results.multi_face_landmarks:
                return False, []

            detected_faces = []
            for face_idx, face_landmarks in enumerate(results.multi_face_landmarks):
                # Analizza l'espressione facciale
                face_info = self._analyze_facial_expression(face_landmarks, face_idx)

                # Verifica confidenza minima
                if face_info.get('confidence', 0) > 0.5:
                    detected_faces.append(face_info)

            return len(detected_faces) > 0, detected_faces

        except Exception as e:
            self.logger.error(f"Errore nel rilevamento facce MediaPipe: {e}")
            return False, []

    def _analyze_facial_expression(self, face_landmarks, face_idx: int) -> Dict[str, Any]:
        """Analizza l'espressione facciale dai landmark."""
        try:
            # Estrai landmark come coordinate
            landmarks = []
            h, w, _ = (480, 640, 3)  # Dimensioni tipiche

            for landmark in face_landmarks.landmark:
                x, y = int(landmark.x * w), int(landmark.y * h)
                landmarks.append({
                    'x': x,
                    'y': y,
                    'z': landmark.z,
                    'index': len(landmarks)
                })

            # Analizza le diverse parti del volto
            eye_analysis = self._analyze_eyes(landmarks)
            mouth_analysis = self._analyze_mouth(landmarks)
            eyebrow_analysis = self._analyze_eyebrows(landmarks)

            # Determina l'espressione principale
            expression = self._classify_expression(eye_analysis, mouth_analysis, eyebrow_analysis)

            # Calcola metriche aggiuntive
            face_metrics = self._calculate_face_metrics(landmarks)

            face_info = {
                'landmarks': landmarks,
                'expression': expression,
                'eye_analysis': eye_analysis,
                'mouth_analysis': mouth_analysis,
                'eyebrow_analysis': eyebrow_analysis,
                'face_metrics': face_metrics,
                'confidence': self._calculate_expression_confidence(landmarks),
                'face_index': face_idx,
                'bounding_box': self._get_face_bounding_box(landmarks)
            }

            return face_info

        except Exception as e:
            self.logger.error(f"Errore nell'analisi espressione facciale: {e}")
            return {
                'expression': 'neutra',
                'confidence': 0.0,
                'landmarks': [],
                'eye_analysis': {},
                'mouth_analysis': {},
                'eyebrow_analysis': {},
                'face_metrics': {}
            }

    def _analyze_eyes(self, landmarks) -> Dict[str, Any]:
        """Analizza gli occhi per determinare aperture e direzione dello sguardo."""
        try:
            # Estrai landmark per occhi sinistro e destro
            left_eye = [landmarks[i] for i in self.LEFT_EYE_LANDMARKS if i < len(landmarks)]
            right_eye = [landmarks[i] for i in self.RIGHT_EYE_LANDMARKS if i < len(landmarks)]

            if len(left_eye) < 4 or len(right_eye) < 4:
                return {'left_open': False, 'right_open': False, 'gaze_direction': 'center'}

            # Calcola apertura occhi
            left_open = self._calculate_eye_openness(left_eye)
            right_open = self._calculate_eye_openness(right_eye)

            # Calcola direzione dello sguardo
            gaze_direction = self._calculate_gaze_direction(left_eye, right_eye)

            return {
                'left_open': left_open > 0.3,  # Soglia per occhio aperto
                'right_open': right_open > 0.3,
                'left_openness': left_open,
                'right_openness': right_open,
                'gaze_direction': gaze_direction,
                'both_eyes_open': left_open > 0.3 and right_open > 0.3,
                'both_eyes_closed': left_open < 0.1 and right_open < 0.1
            }

        except Exception as e:
            self.logger.error(f"Errore nell'analisi occhi: {e}")
            return {'left_open': False, 'right_open': False, 'gaze_direction': 'center'}

    def _calculate_eye_openness(self, eye_landmarks) -> float:
        """Calcola quanto è aperto l'occhio (0-1)."""
        try:
            if len(eye_landmarks) < 6:
                return 0.0

            # Calcola distanza verticale (apertura palpebra)
            top_point = eye_landmarks[1]  # Punto superiore
            bottom_point = eye_landmarks[5]  # Punto inferiore
            vertical_distance = abs(top_point['y'] - bottom_point['y'])

            # Calcola distanza orizzontale (larghezza occhio)
            left_point = eye_landmarks[0]  # Angolo sinistro
            right_point = eye_landmarks[3]  # Angolo destro
            horizontal_distance = abs(right_point['x'] - left_point['x'])

            if horizontal_distance == 0:
                return 0.0

            # Rapporto apertura/larghezza
            openness_ratio = vertical_distance / horizontal_distance

            # Normalizza (tipicamente 0.2-0.4 per occhio aperto)
            normalized_openness = min(1.0, max(0.0, openness_ratio / 0.4))

            return normalized_openness

        except Exception as e:
            return 0.0

    def _calculate_gaze_direction(self, left_eye, right_eye) -> str:
        """Calcola la direzione dello sguardo."""
        try:
            if len(left_eye) < 4 or len(right_eye) < 4:
                return "center"

            # Calcola centro pupilla (approssimato)
            left_center = self._get_eye_center(left_eye)
            right_center = self._get_eye_center(right_eye)

            if left_center is None or right_center is None:
                return "center"

            # Calcola direzione media
            avg_x = (left_center['x'] + right_center['x']) / 2
            avg_y = (left_center['y'] + right_center['y']) / 2

            # Determina direzione
            if avg_x < -0.1:
                return "left"
            elif avg_x > 0.1:
                return "right"
            elif avg_y < -0.1:
                return "up"
            elif avg_y > 0.1:
                return "down"
            else:
                return "center"

        except Exception as e:
            return "center"

    def _get_eye_center(self, eye_landmarks) -> Optional[Dict[str, float]]:
        """Calcola il centro approssimativo dell'occhio."""
        try:
            if len(eye_landmarks) < 4:
                return None

            # Centro approssimativo tra gli angoli dell'occhio
            left_corner = eye_landmarks[0]
            right_corner = eye_landmarks[3]

            return {
                'x': (left_corner['x'] + right_corner['x']) / 2,
                'y': (left_corner['y'] + right_corner['y']) / 2
            }

        except Exception as e:
            return None

    def _analyze_mouth(self, landmarks) -> Dict[str, Any]:
        """Analizza la bocca per determinare sorrisi, bocche aperte, etc."""
        try:
            mouth_points = [landmarks[i] for i in self.MOUTH_LANDMARKS if i < len(landmarks)]

            if len(mouth_points) < 8:
                return {'open': False, 'smile': False, 'width': 0, 'height': 0}

            # Calcola dimensioni bocca
            mouth_width = self._calculate_mouth_width(mouth_points)
            mouth_height = self._calculate_mouth_height(mouth_points)

            # Determina se la bocca è aperta
            is_open = mouth_height > mouth_width * 0.3

            # Determina se c'è un sorriso
            is_smiling = self._detect_smile(mouth_points)

            return {
                'open': is_open,
                'smile': is_smiling,
                'width': mouth_width,
                'height': mouth_height,
                'aspect_ratio': mouth_width / mouth_height if mouth_height > 0 else 0
            }

        except Exception as e:
            self.logger.error(f"Errore nell'analisi bocca: {e}")
            return {'open': False, 'smile': False, 'width': 0, 'height': 0}

    def _calculate_mouth_width(self, mouth_points) -> float:
        """Calcola la larghezza della bocca."""
        try:
            if len(mouth_points) < 4:
                return 0.0

            # Larghezza tra gli angoli della bocca
            left_corner = mouth_points[0]  # Angolo sinistro
            right_corner = mouth_points[6]  # Angolo destro

            return abs(right_corner['x'] - left_corner['x'])

        except Exception as e:
            return 0.0

    def _calculate_mouth_height(self, mouth_points) -> float:
        """Calcola l'altezza della bocca."""
        try:
            if len(mouth_points) < 4:
                return 0.0

            # Altezza tra labbro superiore e inferiore
            upper_lip = mouth_points[3]  # Centro labbro superiore
            lower_lip = mouth_points[9]  # Centro labbro inferiore

            return abs(lower_lip['y'] - upper_lip['y'])

        except Exception as e:
            return 0.0

    def _detect_smile(self, mouth_points) -> bool:
        """Rileva se c'è un sorriso."""
        try:
            if len(mouth_points) < 8:
                return False

            # Calcola la curvatura degli angoli della bocca
            left_corner = mouth_points[0]
            right_corner = mouth_points[6]
            center_top = mouth_points[3]
            center_bottom = mouth_points[9]

            # Calcola angoli
            left_angle = self._calculate_mouth_corner_angle(left_corner, center_top, center_bottom)
            right_angle = self._calculate_mouth_corner_angle(right_corner, center_top, center_bottom)

            # Un sorriso ha angoli più acuti
            smile_threshold = 120  # gradi
            return left_angle < smile_threshold and right_angle < smile_threshold

        except Exception as e:
            return False

    def _calculate_mouth_corner_angle(self, corner, top, bottom) -> float:
        """Calcola l'angolo all'angolo della bocca."""
        try:
            # Vettori
            vec1 = (top['x'] - corner['x'], top['y'] - corner['y'])
            vec2 = (bottom['x'] - corner['x'], bottom['y'] - corner['y'])

            # Calcola angolo
            dot_product = vec1[0] * vec2[0] + vec1[1] * vec2[1]
            mag1 = math.sqrt(vec1[0]**2 + vec1[1]**2)
            mag2 = math.sqrt(vec2[0]**2 + vec2[1]**2)

            if mag1 == 0 or mag2 == 0:
                return 180.0

            cos_angle = dot_product / (mag1 * mag2)
            angle = math.degrees(math.acos(max(-1, min(1, cos_angle))))

            return angle

        except Exception as e:
            return 180.0

    def _analyze_eyebrows(self, landmarks) -> Dict[str, Any]:
        """Analizza le sopracciglia per determinare posizione e movimento."""
        try:
            left_brow = [landmarks[i] for i in self.LEFT_EYEBROW_LANDMARKS if i < len(landmarks)]
            right_brow = [landmarks[i] for i in self.RIGHT_EYEBROW_LANDMARKS if i < len(landmarks)]

            if len(left_brow) < 3 or len(right_brow) < 3:
                return {'raised': False, 'furrowed': False, 'asymmetric': False}

            # Calcola posizione media delle sopracciglia
            left_avg_y = sum(p['y'] for p in left_brow) / len(left_brow)
            right_avg_y = sum(p['y'] for p in right_brow) / len(right_brow)

            # Calcola curvatura
            left_curvature = self._calculate_brow_curvature(left_brow)
            right_curvature = self._calculate_brow_curvature(right_brow)

            return {
                'left_position': left_avg_y,
                'right_position': right_avg_y,
                'left_curvature': left_curvature,
                'right_curvature': right_curvature,
                'raised': left_curvature > 0.1 or right_curvature > 0.1,
                'furrowed': left_curvature < -0.1 or right_curvature < -0.1,
                'asymmetric': abs(left_avg_y - right_avg_y) > 5
            }

        except Exception as e:
            self.logger.error(f"Errore nell'analisi sopracciglia: {e}")
            return {'raised': False, 'furrowed': False, 'asymmetric': False}

    def _calculate_brow_curvature(self, brow_points) -> float:
        """Calcola la curvatura della sopracciglia."""
        try:
            if len(brow_points) < 3:
                return 0.0

            # Calcola la curvatura usando il punto centrale
            left = brow_points[0]
            center = brow_points[2]
            right = brow_points[4]

            # Distanza verticale dal centro
            left_height = center['y'] - left['y']
            right_height = center['y'] - right['y']

            # Curvatura normalizzata
            avg_height = (left_height + right_height) / 2
            width = abs(right['x'] - left['x'])

            if width == 0:
                return 0.0

            return avg_height / width

        except Exception as e:
            return 0.0

    def _classify_expression(self, eye_analysis, mouth_analysis, eyebrow_analysis) -> str:
        """Classifica l'espressione facciale basata sull'analisi delle parti."""
        try:
            # Analizza i componenti
            eyes_open = eye_analysis.get('both_eyes_open', False)
            eyes_closed = eye_analysis.get('both_eyes_closed', False)
            mouth_open = mouth_analysis.get('open', False)
            is_smiling = mouth_analysis.get('smile', False)
            brows_raised = eyebrow_analysis.get('raised', False)
            brows_furrowed = eyebrow_analysis.get('furrowed', False)

            # Classificazione basata su regole
            if eyes_closed and mouth_open:
                return "sorpresa"
            elif eyes_closed:
                return "occhi_chiusi"
            elif is_smiling and brows_raised:
                return "felice"
            elif is_smiling:
                return "sorriso"
            elif brows_furrowed and mouth_open:
                return "arrabbiato"
            elif brows_furrowed:
                return "preoccupato"
            elif brows_raised and mouth_open:
                return "spaventato"
            elif brows_raised:
                return "sorpreso"
            elif mouth_open:
                return "bocca_aperta"
            else:
                return "neutra"

        except Exception as e:
            self.logger.error(f"Errore nella classificazione espressione: {e}")
            return "neutra"

    def _calculate_face_metrics(self, landmarks) -> Dict[str, Any]:
        """Calcola metriche aggiuntive del volto."""
        try:
            if len(landmarks) < 20:
                return {}

            # Calcola dimensioni del volto
            x_coords = [lm['x'] for lm in landmarks]
            y_coords = [lm['y'] for lm in landmarks]

            face_width = max(x_coords) - min(x_coords)
            face_height = max(y_coords) - min(y_coords)

            # Calcola simmetria
            left_side = [lm for lm in landmarks if lm['x'] < sum(x_coords)/len(x_coords)]
            right_side = [lm for lm in landmarks if lm['x'] >= sum(x_coords)/len(x_coords)]

            symmetry_score = self._calculate_symmetry(left_side, right_side)

            return {
                'width': face_width,
                'height': face_height,
                'aspect_ratio': face_width / face_height if face_height > 0 else 0,
                'symmetry_score': symmetry_score
            }

        except Exception as e:
            return {}

    def _calculate_symmetry(self, left_side, right_side) -> float:
        """Calcola il punteggio di simmetria del volto."""
        try:
            if len(left_side) == 0 or len(right_side) == 0:
                return 0.0

            # Confronta posizioni Y simmetriche
            symmetry_differences = []
            center_x = sum(lm['x'] for lm in left_side + right_side) / len(left_side + right_side)

            for left_lm in left_side:
                # Trova punto simmetrico a destra
                symmetric_x = 2 * center_x - left_lm['x']
                closest_right = min(right_side, key=lambda lm: abs(lm['x'] - symmetric_x))

                # Calcola differenza Y
                y_diff = abs(left_lm['y'] - closest_right['y'])
                symmetry_differences.append(y_diff)

            # Punteggio di simmetria (più alto = più simmetrico)
            avg_difference = sum(symmetry_differences) / len(symmetry_differences)
            symmetry_score = max(0.0, 1.0 - (avg_difference / 50.0))  # Normalizza

            return symmetry_score

        except Exception as e:
            return 0.0

    def _calculate_expression_confidence(self, landmarks) -> float:
        """Calcola la confidenza del rilevamento dell'espressione."""
        try:
            if len(landmarks) < 20:
                return 0.0

            # Confidenza basata sulla qualità dei landmark
            valid_landmarks = sum(1 for lm in landmarks if lm['z'] != 0)
            confidence = valid_landmarks / len(landmarks)

            return confidence

        except Exception as e:
            return 0.0

    def _get_face_bounding_box(self, landmarks) -> Dict[str, int]:
        """Calcola il bounding box del volto."""
        try:
            if not landmarks:
                return {'x': 0, 'y': 0, 'width': 0, 'height': 0}

            x_coords = [lm['x'] for lm in landmarks]
            y_coords = [lm['y'] for lm in landmarks]

            return {
                'x': min(x_coords),
                'y': min(y_coords),
                'width': max(x_coords) - min(x_coords),
                'height': max(y_coords) - min(y_coords)
            }

        except Exception as e:
            return {'x': 0, 'y': 0, 'width': 0, 'height': 0}

    def draw_face_landmarks(self, frame, face_info):
        """Disegna i landmark del volto e l'espressione rilevata."""
        try:
            if not face_info or 'landmarks' not in face_info:
                return

            landmarks = face_info['landmarks']
            expression = face_info.get('expression', 'neutra')
            confidence = face_info.get('confidence', 0.0)

            # Disegna tutti i landmark
            for landmark in landmarks:
                cv2.circle(frame, (landmark['x'], landmark['y']), 1, (0, 255, 0), -1)

            # Disegna linee principali del volto
            self._draw_face_connections(frame, landmarks)

            # Mostra espressione rilevata
            if landmarks:
                x, y = landmarks[1]['x'], landmarks[1]['y'] - 30  # Sopra il naso
                cv2.putText(frame, f"{expression.upper()}", (x, y),
                           cv2.FONT_HERSHEY_SIMPLEX, 1.0, (255, 255, 255), 2)
                cv2.putText(frame, f"Conf: {confidence:.2f}", (x, y + 30),
                           cv2.FONT_HERSHEY_SIMPLEX, 0.7, (255, 255, 255), 1)

        except Exception as e:
            self.logger.error(f"Errore nel disegno landmark volto: {e}")

    def _draw_face_connections(self, frame, landmarks):
        """Disegna le connessioni principali del volto."""
        try:
            if len(landmarks) < 20:
                return

            # Connessioni occhi
            left_eye_connections = [(33, 133), (133, 173), (173, 157), (157, 158), (158, 159), (159, 160), (160, 161), (161, 163), (163, 144), (144, 145), (145, 153), (153, 154), (154, 155), (155, 133)]
            right_eye_connections = [(362, 263), (263, 249), (249, 390), (390, 373), (373, 374), (374, 380), (380, 381), (381, 382), (382, 362)]

            # Connessioni bocca
            mouth_connections = [(61, 62), (62, 63), (63, 64), (64, 65), (65, 66), (66, 67), (67, 68), (68, 69), (69, 70), (70, 71), (71, 72), (72, 73), (73, 74), (74, 75), (75, 76), (76, 77), (77, 78), (78, 79), (79, 80), (80, 81), (81, 82), (82, 83), (83, 84), (84, 85), (85, 86), (86, 87), (87, 88), (88, 89), (89, 90), (90, 91), (91, 61)]

            # Disegna connessioni
            for start_idx, end_idx in left_eye_connections + right_eye_connections + mouth_connections:
                if start_idx < len(landmarks) and end_idx < len(landmarks):
                    start_point = (landmarks[start_idx]['x'], landmarks[start_idx]['y'])
                    end_point = (landmarks[end_idx]['x'], landmarks[end_idx]['y'])
                    cv2.line(frame, start_point, end_point, (0, 255, 0), 1)

        except Exception as e:
            self.logger.error(f"Errore nel disegno connessioni volto: {e}")

    def set_enabled(self, enabled: bool):
        """Abilita/disabilita il rilevatore."""
        self.enabled = enabled
        self.logger.info(f"MediaPipe Face Detector {'abilitato' if enabled else 'disabilitato'}")

    def is_enabled(self) -> bool:
        """Verifica se il rilevatore è abilitato."""
        return self.enabled and MEDIAPIPE_AVAILABLE