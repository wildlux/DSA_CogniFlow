# mediapipe_detector.py

import cv2
import numpy as np
import logging
import math
from typing import Dict, List, Tuple, Optional, Any

try:
    import mediapipe as mp
    MEDIAPIPE_AVAILABLE = True
except ImportError:
    MEDIAPIPE_AVAILABLE = False
    logging.warning("MediaPipe non disponibile. Installare con: pip install mediapipe")

class MediaPipeHandDetector:
    """
    Rilevatore avanzato di mani usando MediaPipe.
    Rileva posizione, orientamento e gesti delle mani con alta accuratezza.
    """

    def __init__(self, enabled: bool = True, max_hands: int = 2):
        self.enabled = enabled
        self.max_hands = max_hands
        self.logger = logging.getLogger("MediaPipeHandDetector")

        if not MEDIAPIPE_AVAILABLE:
            self.logger.error("MediaPipe non disponibile")
            self.hands = None
            return

        # Inizializza MediaPipe Hands
        if MEDIAPIPE_AVAILABLE and mp is not None:
            self.mp_hands = mp.solutions.hands
            self.mp_drawing = mp.solutions.drawing_utils
            self.mp_drawing_styles = mp.solutions.drawing_styles
        else:
            self.mp_hands = None
            self.mp_drawing = None
            self.mp_drawing_styles = None

        # Configurazione del rilevatore
        self.hands = self.mp_hands.Hands(
            static_image_mode=False,
            max_num_hands=self.max_hands,
            min_detection_confidence=0.5,
            min_tracking_confidence=0.5
        )

        self.logger.info("MediaPipe Hand Detector inizializzato")

    def detect_hands(self, frame) -> Tuple[bool, List[Dict[str, Any]]]:
        """Rileva le mani nel frame usando MediaPipe."""
        if not self.enabled or not MEDIAPIPE_AVAILABLE or self.hands is None:
            return False, []

        try:
            # Converti BGR a RGB per MediaPipe
            rgb_frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)

            # Processa il frame
            results = self.hands.process(rgb_frame)

            if not results.multi_hand_landmarks:
                return False, []

            detected_hands = []
            for hand_idx, hand_landmarks in enumerate(results.multi_hand_landmarks):
                # Ottieni informazioni sulla mano
                hand_info = self._analyze_hand(hand_landmarks, hand_idx, results)

                # Verifica confidenza minima
                if hand_info.get('confidence', 0) > 0.5:
                    detected_hands.append(hand_info)

            return len(detected_hands) > 0, detected_hands

        except Exception as e:
            self.logger.error(f"Errore nel rilevamento mani MediaPipe: {e}")
            return False, []

    def _analyze_hand(self, hand_landmarks, hand_idx: int, results) -> Dict[str, Any]:
        """Analizza una mano rilevata e determina il gesto."""
        try:
            # Estrai landmark come coordinate
            landmarks = []
            h, w, _ = (480, 640, 3)  # Dimensioni tipiche, adattare se necessario

            for landmark in hand_landmarks.landmark:
                x, y = int(landmark.x * w), int(landmark.y * h)
                landmarks.append({
                    'x': x,
                    'y': y,
                    'z': landmark.z,
                    'visibility': landmark.visibility
                })

            # Calcola proprietà della mano
            hand_properties = self._calculate_hand_properties(landmarks)

            # Determina il gesto
            gesture = self._classify_gesture(landmarks)

            # Determina l'orientamento
            orientation = self._determine_orientation(landmarks)

            # Calcola confidenza
            confidence = self._calculate_confidence(hand_landmarks)

            hand_info = {
                'landmarks': landmarks,
                'gesture': gesture,
                'orientation': orientation,
                'confidence': confidence,
                'properties': hand_properties,
                'hand_index': hand_idx,
                'bounding_box': self._get_bounding_box(landmarks),
                'finger_states': self._get_finger_states(landmarks)
            }

            return hand_info

        except Exception as e:
            self.logger.error(f"Errore nell'analisi mano: {e}")
            return {
                'gesture': 'unknown',
                'orientation': 'unknown',
                'confidence': 0.0,
                'landmarks': [],
                'properties': {},
                'finger_states': {}
            }

    def _calculate_hand_properties(self, landmarks) -> Dict[str, Any]:
        """Calcola le proprietà geometriche della mano."""
        try:
            if len(landmarks) < 21:  # MediaPipe ha 21 landmark per mano
                return {}

            # Punti chiave
            wrist = landmarks[0]
            index_finger = landmarks[8]
            middle_finger = landmarks[12]
            ring_finger = landmarks[16]
            pinky_finger = landmarks[20]

            # Calcola dimensioni della mano
            hand_width = self._calculate_distance(landmarks[5], landmarks[17])  # Da pollice a mignolo
            hand_height = self._calculate_distance(wrist, index_finger)

            # Calcola area approssimativa
            hand_area = hand_width * hand_height

            # Calcola angolo di rotazione
            rotation_angle = self._calculate_rotation_angle(landmarks)

            return {
                'width': hand_width,
                'height': hand_height,
                'area': hand_area,
                'rotation_angle': rotation_angle,
                'center': self._calculate_center(landmarks)
            }

        except Exception as e:
            self.logger.error(f"Errore nel calcolo proprietà mano: {e}")
            return {}

    def _classify_gesture(self, landmarks) -> str:
        """Classifica il gesto della mano basato sui landmark."""
        try:
            if len(landmarks) < 21:
                return "unknown"

            # Estrai posizioni delle punte delle dita
            finger_tips = [
                landmarks[4],   # Pollice
                landmarks[8],   # Indice
                landmarks[12],  # Medio
                landmarks[16],  # Anulare
                landmarks[20]   # Mignolo
            ]

            # Estrai giunture delle dita
            finger_joints = [
                [landmarks[2], landmarks[3]],    # Pollice
                [landmarks[6], landmarks[7]],    # Indice
                [landmarks[10], landmarks[11]],  # Medio
                [landmarks[14], landmarks[15]],  # Anulare
                [landmarks[18], landmarks[19]]   # Mignolo
            ]

            # Calcola se le dita sono estese o piegate
            extended_fingers = []
            for i, (tip, joints) in enumerate(zip(finger_tips, finger_joints)):
                is_extended = self._is_finger_extended(tip, joints, landmarks[0])
                extended_fingers.append(is_extended)

            # Classifica il gesto
            return self._classify_gesture_from_fingers(extended_fingers, landmarks)

        except Exception as e:
            self.logger.error(f"Errore nella classificazione gesto: {e}")
            return "unknown"

    def _is_finger_extended(self, tip, joints, wrist) -> bool:
        """Determina se una dita è estesa."""
        try:
            # Calcola vettori
            wrist_to_joint = (joints[0]['x'] - wrist['x'], joints[0]['y'] - wrist['y'])
            joint_to_tip = (tip['x'] - joints[0]['x'], tip['y'] - joints[0]['y'])

            # Calcola angolo tra i vettori
            dot_product = wrist_to_joint[0] * joint_to_tip[0] + wrist_to_joint[1] * joint_to_tip[1]
            mag1 = math.sqrt(wrist_to_joint[0]**2 + wrist_to_joint[1]**2)
            mag2 = math.sqrt(joint_to_tip[0]**2 + joint_to_tip[1]**2)

            if mag1 == 0 or mag2 == 0:
                return False

            cos_angle = dot_product / (mag1 * mag2)
            angle = math.degrees(math.acos(max(-1, min(1, cos_angle))))

            # Se l'angolo è maggiore di 90 gradi, la dita è estesa
            return angle > 90

        except Exception as e:
            return False

    def _classify_gesture_from_fingers(self, extended_fingers, landmarks) -> str:
        """Classifica il gesto basato sulle dita estese."""
        try:
            extended_count = sum(extended_fingers)

            # Mano chiusa: nessuna o poche dita estese
            if extended_count <= 1:
                return "mano_chiusa"

            # Mano aperta: tutte le dita estese
            elif extended_count >= 4:
                return "mano_aperta"

            # Gestione casi specifici
            else:
                # Solo indice esteso
                if extended_fingers[1] and not any(extended_fingers[2:]):
                    return "indice_esteso"

                # Due dita (indice e medio)
                elif extended_fingers[1] and extended_fingers[2] and not any(extended_fingers[3:]):
                    return "due_dita"

                # Pollice su
                elif extended_fingers[0] and not any(extended_fingers[1:]):
                    return "pollice_su"

                # Altre combinazioni
                else:
                    return "gesto_parziale"

        except Exception as e:
            return "unknown"

    def _determine_orientation(self, landmarks) -> str:
        """Determina l'orientamento della mano."""
        try:
            if len(landmarks) < 21:
                return "unknown"

            # Calcola vettore dal polso all'indice
            wrist = landmarks[0]
            index_finger = landmarks[8]

            dx = index_finger['x'] - wrist['x']
            dy = index_finger['y'] - wrist['y']

            # Calcola angolo
            angle = math.degrees(math.atan2(dy, dx))

            # Classifica orientamento
            if -45 <= angle <= 45:
                return "destra"
            elif 45 < angle <= 135:
                return "basso"
            elif -135 <= angle < -45:
                return "alto"
            else:
                return "sinistra"

        except Exception as e:
            return "unknown"

    def _calculate_confidence(self, hand_landmarks) -> float:
        """Calcola la confidenza del rilevamento."""
        try:
            # Media della visibilità dei landmark
            visibilities = [landmark.visibility for landmark in hand_landmarks.landmark]
            return sum(visibilities) / len(visibilities) if visibilities else 0.0

        except Exception as e:
            return 0.0

    def _get_bounding_box(self, landmarks) -> Dict[str, int]:
        """Calcola il bounding box della mano."""
        try:
            if not landmarks:
                return {'x': 0, 'y': 0, 'width': 0, 'height': 0}

            x_coords = [lm['x'] for lm in landmarks]
            y_coords = [lm['y'] for lm in landmarks]

            return {
                'x': min(x_coords),
                'y': min(y_coords),
                'width': max(x_coords) - min(x_coords),
                'height': max(y_coords) - min(y_coords)
            }

        except Exception as e:
            return {'x': 0, 'y': 0, 'width': 0, 'height': 0}

    def _get_finger_states(self, landmarks) -> Dict[str, bool]:
        """Ottiene lo stato di ogni dita."""
        try:
            if len(landmarks) < 21:
                return {}

            finger_tips = [
                landmarks[4],   # Pollice
                landmarks[8],   # Indice
                landmarks[12],  # Medio
                landmarks[16],  # Anulare
                landmarks[20]   # Mignolo
            ]

            finger_joints = [
                [landmarks[2], landmarks[3]],    # Pollice
                [landmarks[6], landmarks[7]],    # Indice
                [landmarks[10], landmarks[11]],  # Medio
                [landmarks[14], landmarks[15]],  # Anulare
                [landmarks[18], landmarks[19]]   # Mignolo
            ]

            finger_names = ['pollice', 'indice', 'medio', 'anulare', 'mignolo']
            finger_states = {}

            for name, tip, joints in zip(finger_names, finger_tips, finger_joints):
                finger_states[name] = self._is_finger_extended(tip, joints, landmarks[0])

            return finger_states

        except Exception as e:
            return {}

    def _calculate_distance(self, point1, point2) -> float:
        """Calcola la distanza tra due punti."""
        return math.sqrt((point1['x'] - point2['x'])**2 + (point1['y'] - point2['y'])**2)

    def _calculate_rotation_angle(self, landmarks) -> float:
        """Calcola l'angolo di rotazione della mano."""
        try:
            if len(landmarks) < 21:
                return 0.0

            # Usa vettore dal polso al centro della mano
            wrist = landmarks[0]
            palm_center = self._calculate_center(landmarks)

            dx = palm_center['x'] - wrist['x']
            dy = palm_center['y'] - wrist['y']

            return math.degrees(math.atan2(dy, dx))

        except Exception as e:
            return 0.0

    def _calculate_center(self, landmarks) -> Dict[str, float]:
        """Calcola il centro della mano."""
        try:
            if not landmarks:
                return {'x': 0, 'y': 0}

            x_coords = [lm['x'] for lm in landmarks]
            y_coords = [lm['y'] for lm in landmarks]

            return {
                'x': sum(x_coords) / len(x_coords),
                'y': sum(y_coords) / len(y_coords)
            }

        except Exception as e:
            return {'x': 0, 'y': 0}

    def draw_hand_landmarks(self, frame, hand_info):
        """Disegna i landmark della mano sul frame."""
        try:
            if not hand_info or 'landmarks' not in hand_info:
                return

            landmarks = hand_info['landmarks']
            gesture = hand_info.get('gesture', 'unknown')
            orientation = hand_info.get('orientation', 'unknown')
            confidence = hand_info.get('confidence', 0.0)

            # Disegna connessioni tra landmark
            self._draw_hand_connections(frame, landmarks)

            # Disegna punti landmark
            for i, landmark in enumerate(landmarks):
                cv2.circle(frame, (landmark['x'], landmark['y']), 3, (0, 255, 0), -1)

            # Mostra informazioni
            if landmarks:
                x, y = landmarks[0]['x'], landmarks[0]['y'] - 20
                cv2.putText(frame, f"{gesture.upper()}", (x, y),
                           cv2.FONT_HERSHEY_SIMPLEX, 0.7, (255, 255, 255), 2)
                cv2.putText(frame, f"{orientation} | Conf: {confidence:.2f}",
                           (x, y + 25), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 255, 255), 1)

        except Exception as e:
            self.logger.error(f"Errore nel disegno landmark: {e}")

    def _draw_hand_connections(self, frame, landmarks):
        """Disegna le connessioni tra i landmark della mano."""
        try:
            if len(landmarks) < 21:
                return

            # Definizioni delle connessioni (come in MediaPipe)
            connections = [
                # Pollice
                (0, 1), (1, 2), (2, 3), (3, 4),
                # Indice
                (0, 5), (5, 6), (6, 7), (7, 8),
                # Medio
                (0, 9), (9, 10), (10, 11), (11, 12),
                # Anulare
                (0, 13), (13, 14), (14, 15), (15, 16),
                # Mignolo
                (0, 17), (17, 18), (18, 19), (19, 20),
                # Palmo
                (5, 9), (9, 13), (13, 17)
            ]

            for start_idx, end_idx in connections:
                if start_idx < len(landmarks) and end_idx < len(landmarks):
                    start_point = (landmarks[start_idx]['x'], landmarks[start_idx]['y'])
                    end_point = (landmarks[end_idx]['x'], landmarks[end_idx]['y'])
                    cv2.line(frame, start_point, end_point, (0, 255, 0), 2)

        except Exception as e:
            self.logger.error(f"Errore nel disegno connessioni: {e}")

    def set_enabled(self, enabled: bool):
        """Abilita/disabilita il rilevatore."""
        self.enabled = enabled
        self.logger.info(f"MediaPipe Hand Detector {'abilitato' if enabled else 'disabilitato'}")

    def is_enabled(self) -> bool:
        """Verifica se il rilevatore è abilitato."""
        return self.enabled and MEDIAPIPE_AVAILABLE