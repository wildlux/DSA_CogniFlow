#!/usr/bin/env python3
"""
Editor delle Emozioni Facciali - Modulo Specializzato
Gestisce la configurazione e il test delle espressioni facciali rilevate
"""

import cv2
import numpy as np
import logging
from PyQt6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel, QPushButton,
    QSlider, QGroupBox, QCheckBox, QComboBox, QTextEdit,
    QTabWidget, QGridLayout, QMessageBox, QSpinBox
)
from PyQt6.QtCore import Qt, pyqtSignal, QTimer
from PyQt6.QtGui import QFont, QImage, QPixmap

class EmotionEditor(QWidget):
    """
    Editor specializzato per la gestione delle emozioni facciali
    Permette di configurare, testare e ottimizzare il riconoscimento delle espressioni
    """

    # Segnali per comunicare con il sistema principale
    emotion_detected = pyqtSignal(str, float)  # emozione, confidenza
    settings_changed = pyqtSignal(dict)  # nuove impostazioni

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("🎭 Editor Emozioni Facciali - Modalità Sviluppatore")
        self.setGeometry(100, 100, 800, 600)

        # Variabili per il riconoscimento
        self.current_emotion = "neutro"
        self.confidence_threshold = 0.5
        self.test_mode = False
        self.real_time_analysis = True

        # Parametri di configurazione per le emozioni
        self.emotion_params = {
            'sorriso': {
                'gradient_threshold': 30,
                'std_threshold': 25,
                'entropy_threshold': 6.5,
                'brightness_factor': 1.0
            },
            'triste': {
                'gradient_threshold': 15,
                'std_threshold': 20,
                'entropy_threshold': 6.0,
                'brightness_factor': 0.9
            },
            'neutro': {
                'gradient_threshold': 20,
                'std_threshold': 25,
                'entropy_threshold': 6.5,
                'brightness_factor': 1.0
            },
            'sorpreso': {
                'gradient_threshold': 25,
                'std_threshold': 30,
                'entropy_threshold': 7.0,
                'brightness_factor': 1.1
            }
        }

        # Timer per l'analisi in tempo reale
        self.analysis_timer = QTimer()
        self.analysis_timer.timeout.connect(self.analyze_current_frame)
        self.current_frame = None

        self.setup_ui()
        self.setup_connections()

        # Avvia l'analisi in tempo reale se abilitata
        if self.real_time_analysis:
            self.analysis_timer.start(100)  # 10 FPS

    def setup_ui(self):
        """Configura l'interfaccia utente dell'editor"""
        layout = QVBoxLayout(self)

        # Titolo principale
        title_label = QLabel("🎭 Editor delle Emozioni Facciali")
        title_label.setFont(QFont("Arial", 16, QFont.Weight.Bold))
        title_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        layout.addWidget(title_label)

        # Tab widget per organizzare le funzionalità
        self.tab_widget = QTabWidget()
        layout.addWidget(self.tab_widget)

        # Aggiungi i vari tab
        self.setup_configuration_tab()
        self.setup_testing_tab()
        self.setup_statistics_tab()
        self.setup_advanced_tab()

        # Barra di stato
        self.status_label = QLabel("✅ Editor pronto - Modalità sviluppatore attiva")
        self.status_label.setStyleSheet("color: green; font-weight: bold;")
        layout.addWidget(self.status_label)

    def setup_configuration_tab(self):
        """Configura il tab per le impostazioni delle emozioni"""
        config_widget = QWidget()
        layout = QVBoxLayout(config_widget)

        # Selettore emozione corrente
        emotion_group = QGroupBox("🎯 Emozione da Configurare")
        emotion_layout = QHBoxLayout(emotion_group)

        emotion_layout.addWidget(QLabel("Emozione:"))
        self.emotion_combo = QComboBox()
        self.emotion_combo.addItems(['sorriso', 'triste', 'neutro', 'sorpreso'])
        self.emotion_combo.currentTextChanged.connect(self.on_emotion_changed)
        emotion_layout.addWidget(self.emotion_combo)

        layout.addWidget(emotion_group)

        # Parametri per l'emozione selezionata
        self.setup_emotion_parameters(layout)

        # Pulsanti di controllo
        buttons_layout = QHBoxLayout()

        self.save_button = QPushButton("💾 Salva Impostazioni")
        self.save_button.clicked.connect(self.save_settings)
        buttons_layout.addWidget(self.save_button)

        self.reset_button = QPushButton("🔄 Reset Default")
        self.reset_button.clicked.connect(self.reset_to_defaults)
        buttons_layout.addWidget(self.reset_button)

        layout.addLayout(buttons_layout)

        self.tab_widget.addTab(config_widget, "⚙️ Configurazione")

    def setup_emotion_parameters(self, parent_layout):
        """Configura i parametri per l'emozione selezionata"""
        params_group = QGroupBox("🔧 Parametri di Rilevamento")
        params_layout = QGridLayout(params_group)

        # Soglia gradiente
        params_layout.addWidget(QLabel("Soglia Gradiente:"), 0, 0)
        self.gradient_slider = QSlider(Qt.Orientation.Horizontal)
        self.gradient_slider.setRange(10, 50)
        self.gradient_slider.setValue(30)
        params_layout.addWidget(self.gradient_slider, 0, 1)

        self.gradient_value = QLabel("30")
        params_layout.addWidget(self.gradient_value, 0, 2)

        # Soglia deviazione standard
        params_layout.addWidget(QLabel("Soglia Dev. Std:"), 1, 0)
        self.std_slider = QSlider(Qt.Orientation.Horizontal)
        self.std_slider.setRange(15, 40)
        self.std_slider.setValue(25)
        params_layout.addWidget(self.std_slider, 1, 1)

        self.std_value = QLabel("25")
        params_layout.addWidget(self.std_value, 1, 2)

        # Soglia entropia
        params_layout.addWidget(QLabel("Soglia Entropia:"), 2, 0)
        self.entropy_slider = QSlider(Qt.Orientation.Horizontal)
        self.entropy_slider.setRange(50, 80)
        self.entropy_slider.setValue(65)
        params_layout.addWidget(self.entropy_slider, 2, 1)

        self.entropy_value = QLabel("6.5")
        params_layout.addWidget(self.entropy_value, 2, 2)

        # Fattore luminosità
        params_layout.addWidget(QLabel("Fattore Luminosità:"), 3, 0)
        self.brightness_slider = QSlider(Qt.Orientation.Horizontal)
        self.brightness_slider.setRange(80, 120)
        self.brightness_slider.setValue(100)
        params_layout.addWidget(self.brightness_slider, 3, 1)

        self.brightness_value = QLabel("1.0")
        params_layout.addWidget(self.brightness_value, 3, 2)

        # Connetti i segnali
        self.gradient_slider.valueChanged.connect(
            lambda v: self.update_parameter_label(self.gradient_value, v))
        self.std_slider.valueChanged.connect(
            lambda v: self.update_parameter_label(self.std_value, v/10))
        self.entropy_slider.valueChanged.connect(
            lambda v: self.update_parameter_label(self.entropy_value, v/10))
        self.brightness_slider.valueChanged.connect(
            lambda v: self.update_parameter_label(self.brightness_value, v/100))

        parent_layout.addWidget(params_group)

        # Carica i valori iniziali
        self.load_emotion_parameters()

    def setup_testing_tab(self):
        """Configura il tab per il test delle emozioni"""
        test_widget = QWidget()
        layout = QVBoxLayout(test_widget)

        # Controlli di test
        test_group = QGroupBox("🧪 Test del Rilevamento")
        test_layout = QVBoxLayout(test_group)

        # Checkbox per abilitare il test
        self.test_mode_checkbox = QCheckBox("Abilita Modalità Test")
        self.test_mode_checkbox.setChecked(self.test_mode)
        self.test_mode_checkbox.stateChanged.connect(self.toggle_test_mode)
        test_layout.addWidget(self.test_mode_checkbox)

        # Pulsanti di test
        test_buttons_layout = QHBoxLayout()

        self.test_sorriso_button = QPushButton("😊 Test Sorriso")
        self.test_sorriso_button.clicked.connect(lambda: self.test_emotion('sorriso'))
        test_buttons_layout.addWidget(self.test_sorriso_button)

        self.test_triste_button = QPushButton("😢 Test Triste")
        self.test_triste_button.clicked.connect(lambda: self.test_emotion('triste'))
        test_buttons_layout.addWidget(self.test_triste_button)

        self.test_neutro_button = QPushButton("😐 Test Neutro")
        self.test_neutro_button.clicked.connect(lambda: self.test_emotion('neutro'))
        test_buttons_layout.addWidget(self.test_neutro_button)

        self.test_sorpreso_button = QPushButton("😮 Test Sorpreso")
        self.test_sorpreso_button.clicked.connect(lambda: self.test_emotion('sorpreso'))
        test_buttons_layout.addWidget(self.test_sorpreso_button)

        test_layout.addLayout(test_buttons_layout)

        # Area di log per i risultati
        test_layout.addWidget(QLabel("📝 Risultati del Test:"))
        self.test_log = QTextEdit()
        self.test_log.setMaximumHeight(200)
        self.test_log.setReadOnly(True)
        test_layout.addWidget(self.test_log)

        layout.addWidget(test_group)

        # Anteprima dell'immagine
        preview_group = QGroupBox("📹 Anteprima Rilevamento")
        preview_layout = QVBoxLayout(preview_group)

        self.preview_label = QLabel("Caricamento anteprima...")
        self.preview_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.preview_label.setStyleSheet("border: 2px solid #ccc; min-height: 200px;")
        preview_layout.addWidget(self.preview_label)

        layout.addWidget(preview_group)

        self.tab_widget.addTab(test_widget, "🧪 Test")

    def setup_statistics_tab(self):
        """Configura il tab per le statistiche"""
        stats_widget = QWidget()
        layout = QVBoxLayout(stats_widget)

        stats_group = QGroupBox("📊 Statistiche Rilevamento Emozioni")
        stats_layout = QVBoxLayout(stats_group)

        # Statistiche in tempo reale
        self.stats_labels = {}

        emotions = ['sorriso', 'triste', 'neutro', 'sorpreso']
        for emotion in emotions:
            label = QLabel(f"{emotion.title()}: 0 rilevamenti")
            self.stats_labels[emotion] = label
            stats_layout.addWidget(label)

        # Statistiche di accuratezza
        accuracy_group = QGroupBox("🎯 Accuratezza del Sistema")
        accuracy_layout = QVBoxLayout(accuracy_group)

        self.accuracy_label = QLabel("Accuratezza Media: Calcolo in corso...")
        accuracy_layout.addWidget(self.accuracy_label)

        self.confidence_label = QLabel("Confidenza Media: N/A")
        accuracy_layout.addWidget(self.confidence_label)

        stats_layout.addWidget(accuracy_group)

        layout.addWidget(stats_group)

        # Pulsante per resettare le statistiche
        reset_stats_button = QPushButton("🔄 Reset Statistiche")
        reset_stats_button.clicked.connect(self.reset_statistics)
        layout.addWidget(reset_stats_button)

        self.tab_widget.addTab(stats_widget, "📊 Statistiche")

    def setup_advanced_tab(self):
        """Configura il tab per le impostazioni avanzate"""
        advanced_widget = QWidget()
        layout = QVBoxLayout(advanced_widget)

        # Impostazioni avanzate
        advanced_group = QGroupBox("⚡ Impostazioni Avanzate")
        advanced_layout = QVBoxLayout(advanced_group)

        # Soglia di confidenza globale
        confidence_layout = QHBoxLayout()
        confidence_layout.addWidget(QLabel("Soglia Confidenza Globale:"))
        self.confidence_spin = QSpinBox()
        self.confidence_spin.setRange(1, 100)
        self.confidence_spin.setValue(int(self.confidence_threshold * 100))
        self.confidence_spin.valueChanged.connect(self.update_confidence_threshold)
        confidence_layout.addWidget(self.confidence_spin)
        confidence_layout.addWidget(QLabel("%"))
        advanced_layout.addLayout(confidence_layout)

        # Analisi in tempo reale
        self.realtime_checkbox = QCheckBox("Analisi in Tempo Reale")
        self.realtime_checkbox.setChecked(self.real_time_analysis)
        self.realtime_checkbox.stateChanged.connect(self.toggle_realtime_analysis)
        advanced_layout.addWidget(self.realtime_checkbox)

        # Debug mode
        self.debug_checkbox = QCheckBox("Modalità Debug (Log Dettagliato)")
        self.debug_checkbox.stateChanged.connect(self.toggle_debug_mode)
        advanced_layout.addWidget(self.debug_checkbox)

        layout.addWidget(advanced_group)

        # Informazioni sul sistema
        info_group = QGroupBox("ℹ️ Informazioni Sistema")
        info_layout = QVBoxLayout(info_group)

        info_text = """
        🎭 Editor delle Emozioni Facciali v2.0
        Modalità Sviluppatore: ATTIVA

        Funzionalità:
        • Configurazione parametri per ogni emozione
        • Test in tempo reale delle espressioni
        • Statistiche di rilevamento
        • Ottimizzazione automatica

        Emozioni Supportate:
        • Sorriso 😊
        • Triste 😢
        • Neutro 😐
        • Sorpreso 😮
        """
        info_label = QLabel(info_text)
        info_label.setStyleSheet("font-family: monospace;")
        info_layout.addWidget(info_label)

        layout.addWidget(info_group)

        self.tab_widget.addTab(advanced_widget, "⚡ Avanzate")

    def setup_connections(self):
        """Configura le connessioni dei segnali"""
        # Connetti i segnali dei parametri
        self.gradient_slider.valueChanged.connect(self.update_emotion_params)
        self.std_slider.valueChanged.connect(self.update_emotion_params)
        self.entropy_slider.valueChanged.connect(self.update_emotion_params)
        self.brightness_slider.valueChanged.connect(self.update_emotion_params)

    def on_emotion_changed(self, emotion):
        """Gestisce il cambio dell'emozione selezionata"""
        self.current_emotion = emotion
        self.load_emotion_parameters()

    def load_emotion_parameters(self):
        """Carica i parametri per l'emozione corrente"""
        if self.current_emotion in self.emotion_params:
            params = self.emotion_params[self.current_emotion]

            self.gradient_slider.setValue(params['gradient_threshold'])
            self.std_slider.setValue(params['std_threshold'])
            self.entropy_slider.setValue(int(params['entropy_threshold'] * 10))
            self.brightness_slider.setValue(int(params['brightness_factor'] * 100))

    def update_parameter_label(self, label, value):
        """Aggiorna l'etichetta di un parametro"""
        if label == self.entropy_value:
            label.setText(f"{value:.1f}")
        elif label == self.brightness_value:
            label.setText(f"{value:.1f}")
        else:
            label.setText(str(value))

    def update_emotion_params(self):
        """Aggiorna i parametri dell'emozione corrente"""
        if self.current_emotion in self.emotion_params:
            self.emotion_params[self.current_emotion].update({
                'gradient_threshold': self.gradient_slider.value(),
                'std_threshold': self.std_slider.value(),
                'entropy_threshold': self.entropy_slider.value() / 10.0,
                'brightness_factor': self.brightness_slider.value() / 100.0
            })

    def save_settings(self):
        """Salva le impostazioni correnti"""
        try:
            # Invia le nuove impostazioni al sistema principale
            self.settings_changed.emit(self.emotion_params.copy())

            QMessageBox.information(self, "Impostazioni Salvate",
                                  "✅ Le impostazioni delle emozioni sono state salvate con successo!")

        except Exception as e:
            QMessageBox.critical(self, "Errore", f"❌ Errore nel salvataggio: {str(e)}")

    def reset_to_defaults(self):
        """Reset alle impostazioni predefinite"""
        self.emotion_params = {
            'sorriso': {
                'gradient_threshold': 30,
                'std_threshold': 25,
                'entropy_threshold': 6.5,
                'brightness_factor': 1.0
            },
            'triste': {
                'gradient_threshold': 15,
                'std_threshold': 20,
                'entropy_threshold': 6.0,
                'brightness_factor': 0.9
            },
            'neutro': {
                'gradient_threshold': 20,
                'std_threshold': 25,
                'entropy_threshold': 6.5,
                'brightness_factor': 1.0
            },
            'sorpreso': {
                'gradient_threshold': 25,
                'std_threshold': 30,
                'entropy_threshold': 7.0,
                'brightness_factor': 1.1
            }
        }

        self.load_emotion_parameters()
        QMessageBox.information(self, "Reset Completato",
                              "🔄 Impostazioni resettate ai valori predefiniti!")

    def test_emotion(self, emotion):
        """Testa il rilevamento di una specifica emozione"""
        if not self.test_mode:
            QMessageBox.warning(self, "Modalità Test",
                              "❌ Abilita prima la modalità test!")
            return

        # Simula il rilevamento dell'emozione
        confidence = np.random.uniform(0.7, 0.95)  # Confidenza casuale per demo

        self.test_log.append(f"🧪 Test {emotion}: Confidenza {confidence:.2f}")

        # Aggiorna le statistiche
        if emotion in self.stats_labels:
            current_text = self.stats_labels[emotion].text()
            count = int(current_text.split(':')[1].split()[0]) + 1
            self.stats_labels[emotion].setText(f"{emotion.title()}: {count} rilevamenti")

        # Invia segnale di emozione rilevata
        self.emotion_detected.emit(emotion, confidence)

    def toggle_test_mode(self, state):
        """Attiva/disattiva la modalità test"""
        self.test_mode = bool(state)
        if self.test_mode:
            self.status_label.setText("🧪 Modalità test attiva")
            self.status_label.setStyleSheet("color: orange; font-weight: bold;")
        else:
            self.status_label.setText("✅ Editor pronto")
            self.status_label.setStyleSheet("color: green; font-weight: bold;")

    def update_confidence_threshold(self, value):
        """Aggiorna la soglia di confidenza"""
        self.confidence_threshold = value / 100.0

    def toggle_realtime_analysis(self, state):
        """Attiva/disattiva l'analisi in tempo reale"""
        self.real_time_analysis = bool(state)
        if self.real_time_analysis:
            self.analysis_timer.start(100)
        else:
            self.analysis_timer.stop()

    def toggle_debug_mode(self, state):
        """Attiva/disattiva la modalità debug"""
        if bool(state):
            logging.getLogger().setLevel(logging.DEBUG)
            self.status_label.setText("🐛 Modalità debug attiva")
        else:
            logging.getLogger().setLevel(logging.INFO)
            self.status_label.setText("✅ Editor pronto")

    def analyze_current_frame(self):
        """Analizza il frame corrente per le emozioni"""
        if not self.real_time_analysis or self.current_frame is None:
            return

        # Qui implementeremmo l'analisi reale del frame
        # Per ora, simuliamo un'analisi periodica
        if np.random.random() < 0.1:  # 10% di probabilità ogni secondo
            emotions = ['sorriso', 'triste', 'neutro', 'sorpreso']
            random_emotion = np.random.choice(emotions)
            confidence = np.random.uniform(0.6, 0.9)

            self.emotion_detected.emit(random_emotion, confidence)

    def set_current_frame(self, frame):
        """Imposta il frame corrente per l'analisi"""
        self.current_frame = frame

        # Converti il frame per la visualizzazione nell'anteprima
        if frame is not None:
            # Converti da BGR a RGB
            rgb_frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)

            # Crea QImage
            height, width, channel = rgb_frame.shape
            bytes_per_line = 3 * width
            qt_image = QImage(rgb_frame.data, width, height, bytes_per_line, QImage.Format.Format_RGB888)

            # Scala per l'anteprima
            pixmap = QPixmap.fromImage(qt_image)
            scaled_pixmap = pixmap.scaled(400, 300, Qt.AspectRatioMode.KeepAspectRatio)

            self.preview_label.setPixmap(scaled_pixmap)

    def reset_statistics(self):
        """Resetta le statistiche di rilevamento"""
        for emotion in self.stats_labels:
            self.stats_labels[emotion].setText(f"{emotion.title()}: 0 rilevamenti")

        self.accuracy_label.setText("Accuratezza Media: Calcolo in corso...")
        self.confidence_label.setText("Confidenza Media: N/A")

    def closeEvent(self, a0):
        """Gestisce la chiusura della finestra"""
        # Ferma il timer
        self.analysis_timer.stop()

        # Salva le impostazioni prima di chiudere
        self.save_settings()

        a0.accept()

# Funzione per creare e mostrare l'editor
def show_emotion_editor(parent=None):
    """Crea e mostra l'editor delle emozioni facciali"""
    editor = EmotionEditor(parent)
    editor.show()
    return editor

if __name__ == "__main__":
    # Test standalone dell'editor
    from PyQt6.QtWidgets import QApplication
    import sys

    app = QApplication(sys.argv)
    editor = show_emotion_editor()
    sys.exit(app.exec())