# Video - Rilevamento Video e Computer Vision

Questa cartella contiene tutti i moduli per il rilevamento video, computer vision e gesture recognition.

## Struttura:

```
Video/
├── mediapipe/     # Implementazioni MediaPipe (avanzate)
└── opencv/        # Implementazioni OpenCV (default)
```

## Sottocartelle:

### mediapipe/
- `mediapipe_detector.py` - Rilevamento mani con MediaPipe
- `mediapipe_face_detector.py` - Rilevamento faccia con MediaPipe
- `media_pipe_recognizer.py` - Riconoscimento gesti con MediaPipe

### opencv/
- `opencv_recognizer.py` - Rilevamento con OpenCV (principale)
- `advanced_detection_system.py` - Sistema avanzato di rilevamento
- `base_detector.py` - Classe base per i detector
- `hand_controller.py` - Controllo delle mani
- `person_detector.py` - Rilevamento persone
- `test_detection.py` - Test del sistema di rilevamento

## Funzionalità:

- **Rilevamento Mani**: Tracking delle mani e gesture
- **Rilevamento Faccia**: Identificazione facce ed espressioni
- **Rilevamento Corpo**: Tracking del corpo completo
- **Gesture Recognition**: Riconoscimento gesti specifici
- **Real-time Processing**: Elaborazione video in tempo reale

## Utilizzo:

```python
# Utilizzo OpenCV (default)
from Video.opencv.opencv_recognizer import OpenCVHandDetector
detector = OpenCVHandDetector()

# Utilizzo MediaPipe (avanzato)
from Video.mediapipe.mediapipe_detector import MediaPipeHandDetector
detector = MediaPipeHandDetector()
```

## Configurazione:

Il sistema può essere configurato nelle impostazioni per scegliere tra:
- **OpenCV**: Più leggero, adatto a dispositivi con risorse limitate
- **MediaPipe**: Più preciso, richiede più risorse ma offre prestazioni superiori