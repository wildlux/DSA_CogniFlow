# AI/Ollama/dsa_integration.py
# Integrazione di Ollama con l'Assistente DSA

import os
import json
import logging
from typing import Dict, List, Optional, Any
from .ollama_manager import ollama_manager

class DSAOllamaIntegration:
    """Integrazione specializzata di Ollama per l'Assistente DSA."""

    def __init__(self):
        self.logger = logging.getLogger("DSAOllamaIntegration")
        self.config_file = os.path.join(os.path.dirname(__file__), "dsa_config.json")

        # Modelli raccomandati per DSA
        self.dsa_models = {
            "vision": "llava:7b",
            "coding": "qwen2.5-coder:latest",
            "general": "llama3.2:latest",
            "italian": "yodamaleducato:latest",
            "assistant": "fotiecodes/jarvis:3b",
            "lightweight": "gemma3:1b"
        }

        # Carica configurazione
        self.config = self._load_config()

    def _load_config(self) -> Dict[str, Any]:
        """Carica la configurazione DSA."""
        default_config = {
            "enabled": True,
            "auto_start": True,
            "default_model": "general",
            "max_context_length": 4096,
            "temperature": 0.7,
            "timeout": 30,
            "cache_responses": True,
            "log_interactions": True
        }

        try:
            if os.path.exists(self.config_file):
                with open(self.config_file, 'r', encoding='utf-8') as f:
                    loaded = json.load(f)
                    default_config.update(loaded)
        except Exception as e:
            self.logger.error(f"Errore caricamento config DSA: {e}")

        return default_config

    def save_config(self):
        """Salva la configurazione DSA."""
        try:
            with open(self.config_file, 'w', encoding='utf-8') as f:
                json.dump(self.config, f, indent=2, ensure_ascii=False)
            self.logger.info("Configurazione DSA salvata")
        except Exception as e:
            self.logger.error(f"Errore salvataggio config DSA: {e}")

    def initialize_for_dsa(self) -> bool:
        """Inizializza Ollama per l'uso con DSA."""
        try:
            self.logger.info("🔧 Inizializzazione DSA-Ollama...")

            # Verifica se Ollama è in esecuzione
            if not ollama_manager.check_ollama_running():
                self.logger.info("Avvio Ollama...")
                if not ollama_manager.start_ollama_service():
                    return False

            # Verifica modelli DSA essenziali
            available_models = ollama_manager.get_available_models()
            available_names = [model["name"] for model in available_models]

            missing_models = []
            for model_type, model_name in self.dsa_models.items():
                if model_name not in available_names:
                    missing_models.append(model_name)

            if missing_models:
                self.logger.warning(f"Modelli mancanti: {missing_models}")
                self.logger.info("Installazione modelli mancanti...")
                for model in missing_models:
                    if not ollama_manager.pull_model(model):
                        self.logger.error(f"Impossibile installare {model}")

            self.logger.info("✅ Inizializzazione DSA-Ollama completata")
            return True

        except Exception as e:
            self.logger.error(f"Errore inizializzazione DSA: {e}")
            return False

    def ask_assistant(self, question: str, context: Optional[str] = None,
                     model_type: str = "general") -> Optional[str]:
        """Chiede all'assistente DSA usando il modello appropriato."""
        try:
            model_name = self.dsa_models.get(model_type, self.dsa_models["general"])

            # Prepara il prompt
            system_prompt = """Sei un assistente DSA (Disturbo Specifico dell'Apprendimento).
Aiuti le persone con difficoltà di apprendimento, lettura e scrittura.
Sei paziente, chiaro e fornisci spiegazioni dettagliate.
Usa un linguaggio semplice ma preciso."""

            if context:
                full_prompt = f"{system_prompt}\n\nContesto: {context}\n\nDomanda: {question}"
            else:
                full_prompt = f"{system_prompt}\n\nDomanda: {question}"

            # Genera risposta
            response = ollama_manager.generate_text(
                prompt=full_prompt,
                model=model_name,
                options={
                    "temperature": self.config["temperature"],
                    "num_ctx": self.config["max_context_length"]
                }
            )

            if response:
                self.logger.info(f"✅ Risposta generata con {model_name}")
                return response
            else:
                self.logger.error("❌ Nessuna risposta generata")
                return None

        except Exception as e:
            self.logger.error(f"Errore nella richiesta all'assistente: {e}")
            return None

    def analyze_image(self, image_path: str, question: Optional[str] = None) -> Optional[str]:
        """Analizza un'immagine usando il modello vision."""
        try:
            if not os.path.exists(image_path):
                return "Immagine non trovata"

            model_name = self.dsa_models["vision"]

            if question:
                prompt = f"Analizza questa immagine e rispondi alla domanda: {question}"
            else:
                prompt = "Descrivi dettagliatamente questa immagine"

            # Nota: llava richiede una sintassi speciale per le immagini
            # In una implementazione reale, dovremmo passare l'immagine
            response = ollama_manager.generate_text(
                prompt=f"[Descrizione immagine: {image_path}]\n\n{prompt}",
                model=model_name
            )

            return response

        except Exception as e:
            self.logger.error(f"Errore nell'analisi immagine: {e}")
            return None

    def generate_code(self, request: str, language: str = "python") -> Optional[str]:
        """Genera codice usando il modello di coding."""
        try:
            model_name = self.dsa_models["coding"]

            prompt = f"""Genera codice {language} per la seguente richiesta.
Assicurati che il codice sia:
- Leggibile e ben commentato
- Efficiente
- Gestisce gli errori appropriatamente

Richiesta: {request}

Codice {language}:"""

            response = ollama_manager.generate_text(
                prompt=prompt,
                model=model_name,
                options={
                    "temperature": 0.3,  # Bassa temperatura per codice più deterministico
                    "num_ctx": 2048
                }
            )

            return response

        except Exception as e:
            self.logger.error(f"Errore nella generazione codice: {e}")
            return None

    def explain_concept(self, concept: str, level: str = "intermediate") -> Optional[str]:
        """Spiega un concetto in modo adatto per DSA."""
        try:
            model_name = self.dsa_models["general"]

            prompt = f"""Spiega il concetto di "{concept}" in modo chiaro e semplice.
Adatta la spiegazione per qualcuno con DSA (Disturbo Specifico dell'Apprendimento).
Usa:
- Linguaggio semplice
- Esempi concreti
- Spiegazioni passo-passo
- Evita gergo tecnico non necessario

Livello di difficoltà: {level}

Spiegazione:"""

            response = ollama_manager.generate_text(
                prompt=prompt,
                model=model_name,
                options={
                    "temperature": 0.7,
                    "num_ctx": self.config["max_context_length"]
                }
            )

            return response

        except Exception as e:
            self.logger.error(f"Errore nella spiegazione concetto: {e}")
            return None

    def get_available_models_info(self) -> Dict[str, Any]:
        """Ottiene informazioni sui modelli disponibili per DSA."""
        try:
            available = ollama_manager.get_available_models()
            available_names = [model["name"] for model in available]

            models_info = {}
            for model_type, model_name in self.dsa_models.items():
                models_info[model_type] = {
                    "name": model_name,
                    "available": model_name in available_names,
                    "description": self._get_model_description(model_name)
                }

            return {
                "models": models_info,
                "total_available": len([m for m in models_info.values() if m["available"]]),
                "total_configured": len(models_info)
            }

        except Exception as e:
            self.logger.error(f"Errore nel recupero info modelli: {e}")
            return {}

    def _get_model_description(self, model_name: str) -> str:
        """Ottiene la descrizione di un modello."""
        descriptions = {
            "llava:7b": "Modello vision-language per riconoscimento immagini",
            "qwen2.5-coder:latest": "Modello specializzato in generazione codice",
            "llama3.2:latest": "Modello generale per conversazioni",
            "yodamaleducato:latest": "Modello specializzato in italiano",
            "fotiecodes/jarvis:3b": "Assistente virtuale intelligente",
            "gemma3:1b": "Modello leggero e veloce"
        }
        return descriptions.get(model_name, "Modello AI")

# Istanza globale
dsa_ollama = DSAOllamaIntegration()

# Funzioni di utilità per retrocompatibilità
def initialize_dsa_ollama():
    """Inizializza l'integrazione DSA-Ollama."""
    return dsa_ollama.initialize_for_dsa()

def ask_dsa_assistant(question, context=None, model_type="general"):
    """Chiede all'assistente DSA."""
    return dsa_ollama.ask_assistant(question, context, model_type)

def analyze_image_with_dsa(image_path, question=None):
    """Analizza un'immagine con DSA."""
    return dsa_ollama.analyze_image(image_path, question)

if __name__ == "__main__":
    print("🧠 Test Integrazione DSA-Ollama...")

    if dsa_ollama.initialize_for_dsa():
        print("✅ Inizializzazione completata")

        # Test richiesta semplice
        response = dsa_ollama.ask_assistant("Cos'è l'intelligenza artificiale?")
        if response:
            print("✅ Risposta ricevuta:")
            print(response[:200] + "..." if len(response) > 200 else response)
        else:
            print("❌ Nessuna risposta ricevuta")

    else:
        print("❌ Inizializzazione fallita")