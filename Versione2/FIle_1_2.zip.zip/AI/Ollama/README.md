# 🤖 AI/Ollama - Gestione Modelli AI

Questa cartella contiene la gestione centralizzata di Ollama e dei suoi modelli per l'Assistente DSA.

## 📁 Struttura della Cartella

```
AI/Ollama/
├── models/           # Modelli scaricati (gestito automaticamente)
├── configs/          # Configurazioni personalizzate per i modelli
├── logs/            # Log delle operazioni
├── ollama_manager.py # Gestore principale di Ollama
├── recommended_models.json # Lista dei modelli raccomandati
└── README.md        # Questa documentazione
```

## 🚀 Modelli Raccomandati

### 📦 Modelli Essenziali (Installare per primi)
- **llava:7b** - Vision-Language per riconoscimento immagini
- **llama2:7b** - Modello generale per conversazioni
- **codellama:7b** - Specializzato in generazione codice
- **mistral:7b** - Efficiente e performante
- **phi:3b** - Leggero e veloce

### 🔧 Modelli Avanzati (Opzionali)
- **llama2:13b** - Versione più potente per compiti complessi
- **codellama:13b** - Per generazione di codice avanzato
- **llava:13b** - Per analisi immagini dettagliate

## 🛠️ Utilizzo

### Installazione Automatica
```python
from AI.Ollama.ollama_manager import ollama_manager

# Installa tutti i modelli raccomandati
results = ollama_manager.install_recommended_models()
print("Modelli installati:", results)
```

### Utilizzo Base
```python
from AI.Ollama.ollama_manager import ollama_manager

# Verifica se Ollama è in esecuzione
if ollama_manager.check_ollama_running():
    print("✅ Ollama è attivo")

    # Ottieni lista modelli
    models = ollama_manager.get_available_models()
    print(f"📦 Modelli disponibili: {len(models)}")

    # Genera testo
    response = ollama_manager.generate_text(
        "Spiega cos'è l'intelligenza artificiale",
        model="llama2:7b"
    )
    print(response)
```

### Gestione Manuale
```python
# Avvia Ollama se non è in esecuzione
if not ollama_manager.check_ollama_running():
    ollama_manager.start_ollama_service()

# Scarica un modello specifico
success = ollama_manager.pull_model("llava:7b")
if success:
    print("✅ Modello scaricato con successo")
```

## 📊 Informazioni sui Modelli

### llava:7b
- **Dimensione**: ~4.7 GB
- **Uso**: Riconoscimento immagini, descrizione scene
- **Vantaggi**: Comprende sia testo che immagini

### llama2:7b
- **Dimensione**: ~3.8 GB
- **Uso**: Conversazioni, ragionamento generale
- **Vantaggi**: Eccellente per compiti di linguaggio

### codellama:7b
- **Dimensione**: ~3.8 GB
- **Uso**: Generazione codice, debug, spiegazioni
- **Vantaggi**: Specializzato in programmazione

### mistral:7b
- **Dimensione**: ~4.1 GB
- **Uso**: Compiti generali, analisi
- **Vantaggi**: Efficienza e prestazioni elevate

### phi:3b
- **Dimensione**: ~2.8 GB
- **Uso**: Compiti leggeri, test
- **Vantaggi**: Veloce e richiede poche risorse

## 🔧 Configurazione

### File di Configurazione
Ogni modello può avere la sua configurazione personalizzata in `configs/`:
```json
{
  "temperature": 0.7,
  "top_p": 0.9,
  "max_tokens": 2048,
  "context_window": 4096
}
```

### Logging
I log delle operazioni sono salvati in `logs/ollama_manager.log`.

## 🚨 Risoluzione Problemi

### Ollama non si avvia
```bash
# Controlla se il servizio è installato
ollama --version

# Avvia manualmente
ollama serve
```

### Modello non scaricato
```python
# Scarica manualmente
ollama pull nome_modello
```

### Memoria insufficiente
- Usa modelli più piccoli come `phi:3b`
- Chiudi altre applicazioni
- Aumenta la RAM del sistema

## 📈 Performance

### Requisiti Minimi
- **RAM**: 8 GB
- **Spazio disco**: 20 GB
- **Sistema**: Linux/Windows/macOS

### Requisiti Raccomandati
- **RAM**: 16 GB
- **Spazio disco**: 50 GB
- **GPU**: Opzionale ma raccomandata

## 🔄 Integrazione con l'Applicazione

Il sistema è progettato per integrarsi automaticamente con l'applicazione principale:

1. **Auto-avvio**: Ollama viene avviato automaticamente se necessario
2. **Fallback**: Se un modello non è disponibile, viene usato un fallback
3. **Cache**: I modelli scaricati vengono riutilizzati

## 📝 Note

- I modelli vengono scaricati solo la prima volta
- È possibile usare modelli locali esistenti
- Il sistema è progettato per essere robusto e gestire errori
- Tutti i file vengono organizzati automaticamente

## 🆘 Supporto

Per problemi con Ollama:
- Documentazione: https://ollama.ai/docs
- GitHub: https://github.com/jmorganca/ollama
- Discord: https://discord.gg/ollama