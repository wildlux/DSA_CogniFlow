# TTS/engines/edge_tts_engine.py
# Microsoft Edge TTS Engine - Alta qualità e molte voci

import asyncio
import os
import logging
import subprocess
from typing import List, Dict, Optional, Any
import json

try:
    import edge_tts
    EDGE_TTS_AVAILABLE = True
except ImportError:
    EDGE_TTS_AVAILABLE = False
    logging.warning("edge-tts non disponibile. Installare con: pip install edge-tts")

class EdgeTTSEngine:
    """Motore TTS basato su Microsoft Edge TTS - Qualità eccellente."""

    def __init__(self):
        self.logger = logging.getLogger("EdgeTTSEngine")
        self.cache_dir = os.path.join(os.path.dirname(__file__), "..", "cache")
        self.config_file = os.path.join(os.path.dirname(__file__), "..", "configs", "edge_tts_config.json")

        os.makedirs(self.cache_dir, exist_ok=True)
        os.makedirs(os.path.dirname(self.config_file), exist_ok=True)

        self.voices = []
        if EDGE_TTS_AVAILABLE:
            self._load_voices()

    def _load_voices(self):
        """Carica la lista delle voci disponibili."""
        try:
            # Voci Microsoft Edge TTS più realistiche
            self.voices = [
                {
                    "name": "Microsoft Server Speech Text to Speech Voice (it-IT, ElsaNeural)",
                    "short_name": "it-IT-ElsaNeural",
                    "language": "it-IT",
                    "gender": "Female",
                    "quality": "High",
                    "style": "Professional"
                },
                {
                    "name": "Microsoft Server Speech Text to Speech Voice (it-IT, DiegoNeural)",
                    "short_name": "it-IT-DiegoNeural",
                    "language": "it-IT",
                    "gender": "Male",
                    "quality": "High",
                    "style": "Professional"
                },
                {
                    "name": "Microsoft Server Speech Text to Speech Voice (en-US, JennyNeural)",
                    "short_name": "en-US-JennyNeural",
                    "language": "en-US",
                    "gender": "Female",
                    "quality": "High",
                    "style": "Conversational"
                },
                {
                    "name": "Microsoft Server Speech Text to Speech Voice (en-US, GuyNeural)",
                    "short_name": "en-US-GuyNeural",
                    "language": "en-US",
                    "gender": "Male",
                    "quality": "High",
                    "style": "Conversational"
                },
                {
                    "name": "Microsoft Server Speech Text to Speech Voice (es-ES, ElviraNeural)",
                    "short_name": "es-ES-ElviraNeural",
                    "language": "es-ES",
                    "gender": "Female",
                    "quality": "High",
                    "style": "Professional"
                },
                {
                    "name": "Microsoft Server Speech Text to Speech Voice (fr-FR, DeniseNeural)",
                    "short_name": "fr-FR-DeniseNeural",
                    "language": "fr-FR",
                    "gender": "Female",
                    "quality": "High",
                    "style": "Professional"
                },
                {
                    "name": "Microsoft Server Speech Text to Speech Voice (de-DE, KatjaNeural)",
                    "short_name": "de-DE-KatjaNeural",
                    "language": "de-DE",
                    "gender": "Female",
                    "quality": "High",
                    "style": "Professional"
                }
            ]

            self.logger.info(f"Caricate {len(self.voices)} voci Edge TTS")

        except Exception as e:
            self.logger.error(f"Errore nel caricamento delle voci Edge TTS: {e}")
            self.voices = []

    def get_available_voices(self) -> List[Dict[str, Any]]:
        """Restituisce la lista delle voci disponibili."""
        return self.voices

    def synthesize(self, text: str, voice: str = "it-IT-ElsaNeural",
                  rate: float = 1.0, pitch: float = 1.0,
                  volume: float = 1.0) -> Optional[str]:
        """
        Sintetizza il testo in audio.

        Args:
            text: Testo da sintetizzare
            voice: Voce da utilizzare
            rate: Velocità (0.5-2.0)
            pitch: Intonazione (0.5-2.0)
            volume: Volume (0.0-1.0)

        Returns:
            Path del file audio generato o None se errore
        """
        if not EDGE_TTS_AVAILABLE:
            self.logger.error("Edge TTS non disponibile")
            return None

        try:
            # Crea nome file unico
            import hashlib
            import time
            hash_input = f"{text}_{voice}_{rate}_{pitch}_{volume}_{time.time()}"
            file_hash = hashlib.md5(hash_input.encode()).hexdigest()[:8]
            output_file = os.path.join(self.cache_dir, f"edge_tts_{file_hash}.mp3")

            # Verifica se il file è già in cache
            if os.path.exists(output_file):
                self.logger.info(f"File trovato in cache: {output_file}")
                return output_file

            # Calcola i parametri
            rate_value = int((rate - 1.0) * 100)  # -100 a +100
            pitch_value = int((pitch - 1.0) * 50)  # -50 a +50

            async def generate_audio():
                communicate = edge_tts.Communicate(
                    text=text,
                    voice=voice,
                    rate=f"{rate_value:+d}%",
                    pitch=f"{pitch_value:+d}Hz",
                    volume=f"{volume:.0%}"
                )

                await communicate.save(output_file)
                return output_file

            # Esegui la generazione
            loop = asyncio.new_event_loop()
            asyncio.set_event_loop(loop)
            result = loop.run_until_complete(generate_audio())
            loop.close()

            self.logger.info(f"Audio generato con successo: {output_file}")
            return result

        except Exception as e:
            self.logger.error(f"Errore nella sintesi Edge TTS: {e}")
            return None

    def play_audio(self, audio_file: str) -> bool:
        """Riproduce il file audio."""
        try:
            if os.path.exists(audio_file):
                # Usa subprocess per riprodurre
                result = subprocess.run(
                    ["mpg123", audio_file],
                    capture_output=True,
                    timeout=60
                )
                return result.returncode == 0
            return False
        except Exception as e:
            self.logger.error(f"Errore nella riproduzione audio: {e}")
            return False

    def cleanup_cache(self, max_age_days: int = 7):
        """Pulisce i file cache più vecchi di max_age_days."""
        try:
            import time
            from datetime import datetime, timedelta

            cutoff_time = time.time() - (max_age_days * 24 * 60 * 60)
            cleaned_count = 0

            for filename in os.listdir(self.cache_dir):
                if filename.startswith("edge_tts_") and filename.endswith(".mp3"):
                    filepath = os.path.join(self.cache_dir, filename)
                    if os.path.getmtime(filepath) < cutoff_time:
                        os.remove(filepath)
                        cleaned_count += 1

            if cleaned_count > 0:
                self.logger.info(f"Cache pulita: {cleaned_count} file rimossi")

        except Exception as e:
            self.logger.error(f"Errore nella pulizia cache: {e}")

# Test del motore
if __name__ == "__main__":
    engine = EdgeTTSEngine()

    if EDGE_TTS_AVAILABLE:
        print("🔊 Test Edge TTS Engine...")

        # Test sintesi
        audio_file = engine.synthesize(
            "Ciao! Sono un sintetizzatore vocale di alta qualità basato su Microsoft Edge.",
            voice="it-IT-ElsaNeural",
            rate=1.0,
            pitch=1.0
        )

        if audio_file:
            print(f"✅ Audio generato: {audio_file}")

            # Test riproduzione
            if engine.play_audio(audio_file):
                print("✅ Audio riprodotto con successo")
            else:
                print("❌ Errore nella riproduzione")
        else:
            print("❌ Errore nella generazione audio")
    else:
        print("❌ Edge TTS non disponibile")