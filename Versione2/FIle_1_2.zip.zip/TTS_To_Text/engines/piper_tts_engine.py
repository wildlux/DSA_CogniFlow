# TTS/engines/piper_tts_engine.py
# Piper TTS Engine - Sintetizzatore open-source di alta qualità

import os
import logging
import subprocess
import json
import tempfile
from typing import List, Dict, Optional, Any
import wave

try:
    import piper
    PIPER_AVAILABLE = True
except ImportError:
    PIPER_AVAILABLE = False
    logging.warning("Piper non disponibile. Installare con: pip install piper-tts")

class PiperTTSEngine:
    """Motore TTS basato su Piper - Open-source e alta qualità."""

    def __init__(self):
        self.logger = logging.getLogger("PiperTTSEngine")
        self.cache_dir = os.path.join(os.path.dirname(__file__), "..", "cache")
        self.voices_dir = os.path.join(os.path.dirname(__file__), "..", "voices")
        self.config_file = os.path.join(os.path.dirname(__file__), "..", "configs", "piper_config.json")

        # Crea le directory
        for directory in [self.cache_dir, self.voices_dir]:
            os.makedirs(directory, exist_ok=True)

        self.piper_instance = None
        self.current_voice = None

        if PIPER_AVAILABLE:
            self._initialize_piper()

    def _initialize_piper(self):
        """Inizializza Piper."""
        try:
            # Configurazione base di Piper
            self.piper_config = {
                "sample_rate": 22050,
                "noise_scale": 0.667,
                "length_scale": 1.0,
                "noise_w": 0.8,
                "max_wav_value": 32767.0,
                "speaker_id": None
            }

            self.logger.info("Piper inizializzato con successo")

        except Exception as e:
            self.logger.error(f"Errore nell'inizializzazione di Piper: {e}")

    def get_available_voices(self) -> List[Dict[str, Any]]:
        """Restituisce la lista delle voci disponibili per Piper."""
        # Voci Piper disponibili (modelli onnx)
        voices = [
            {
                "name": "Italian - Female (riccardo-fasol)",
                "model_file": "it-riccardo-fasol.onnx",
                "config_file": "it-riccardo-fasol.onnx.json",
                "language": "it-IT",
                "gender": "Female",
                "quality": "High",
                "size_mb": 45
            },
            {
                "name": "English - Female (jenny)",
                "model_file": "en-us-jenny.onnx",
                "config_file": "en-us-jenny.onnx.json",
                "language": "en-US",
                "gender": "Female",
                "quality": "High",
                "size_mb": 42
            },
            {
                "name": "English - Male (libritts)",
                "model_file": "en-us-libritts.onnx",
                "config_file": "en-us-libritts.onnx.json",
                "language": "en-US",
                "gender": "Male",
                "quality": "High",
                "size_mb": 38
            },
            {
                "name": "Spanish - Female (carlfm)",
                "model_file": "es-carlfm.onnx",
                "config_file": "es-carlfm.onnx.json",
                "language": "es-ES",
                "gender": "Female",
                "quality": "High",
                "size_mb": 40
            },
            {
                "name": "French - Female (gilles)",
                "model_file": "fr-gilles.onnx",
                "config_file": "fr-gilles.onnx.json",
                "language": "fr-FR",
                "gender": "Female",
                "quality": "High",
                "size_mb": 44
            },
            {
                "name": "German - Female (kerstin)",
                "model_file": "de-kerstin.onnx",
                "config_file": "de-kerstin.onnx.json",
                "language": "de-DE",
                "gender": "Female",
                "quality": "High",
                "size_mb": 46
            }
        ]

        return voices

    def download_voice(self, voice_name: str) -> bool:
        """Scarica una voce specifica se non è presente."""
        try:
            voices = self.get_available_voices()
            voice_info = next((v for v in voices if v["name"] == voice_name), None)

            if not voice_info:
                self.logger.error(f"Voce non trovata: {voice_name}")
                return False

            model_path = os.path.join(self.voices_dir, voice_info["model_file"])
            config_path = os.path.join(self.voices_dir, voice_info["config_file"])

            # Verifica se i file esistono già
            if os.path.exists(model_path) and os.path.exists(config_path):
                self.logger.info(f"Voce già presente: {voice_name}")
                return True

            # Scarica i file (in un'implementazione reale, qui ci sarebbero gli URL di download)
            self.logger.info(f"Download della voce {voice_name} non implementato")
            self.logger.info("Scaricare manualmente da: https://github.com/rhasspy/piper/releases")

            return False

        except Exception as e:
            self.logger.error(f"Errore nel download della voce: {e}")
            return False

    def synthesize(self, text: str, voice: str = "it-riccardo-fasol",
                  rate: float = 1.0, pitch: float = 1.0,
                  volume: float = 1.0) -> Optional[str]:
        """
        Sintetizza il testo in audio usando Piper.

        Args:
            text: Testo da sintetizzare
            voice: Nome della voce
            rate: Velocità (0.5-2.0)
            pitch: Intonazione (0.5-2.0)
            volume: Volume (0.0-1.0)

        Returns:
            Path del file audio generato o None se errore
        """
        if not PIPER_AVAILABLE:
            self.logger.error("Piper non disponibile")
            return None

        try:
            # Trova la voce
            voices = self.get_available_voices()
            voice_info = next((v for v in voices if v["name"] == voice), None)

            if not voice_info:
                self.logger.error(f"Voce non trovata: {voice}")
                return None

            # Verifica se la voce è scaricata
            model_path = os.path.join(self.voices_dir, voice_info["model_file"])
            if not os.path.exists(model_path):
                self.logger.error(f"Modello non trovato: {model_path}")
                return None

            # Crea nome file unico
            import hashlib
            import time
            hash_input = f"{text}_{voice}_{rate}_{pitch}_{volume}_{time.time()}"
            file_hash = hashlib.md5(hash_input.encode()).hexdigest()[:8]
            output_file = os.path.join(self.cache_dir, f"piper_{file_hash}.wav")

            # Verifica cache
            if os.path.exists(output_file):
                self.logger.info(f"File trovato in cache: {output_file}")
                return output_file

            # Configura i parametri
            config = self.piper_config.copy()
            config["length_scale"] = 1.0 / rate  # Inverti la velocità
            config["noise_scale"] = 0.667 * pitch  # Regola il pitch

            # Sintetizza usando subprocess (Piper CLI)
            with tempfile.NamedTemporaryFile(mode='w', suffix='.txt', delete=False) as temp_file:
                temp_file.write(text)
                temp_file_path = temp_file.name

            try:
                # Comando Piper
                cmd = [
                    "piper",
                    "--model", model_path,
                    "--output_file", output_file,
                    "--length_scale", str(config["length_scale"]),
                    "--noise_scale", str(config["noise_scale"]),
                    "--noise_w", str(config["noise_w"])
                ]

                if config["speaker_id"] is not None:
                    cmd.extend(["--speaker", str(config["speaker_id"])])

                # Aggiungi il file di testo
                cmd.append(temp_file_path)

                # Esegui Piper
                result = subprocess.run(cmd, capture_output=True, text=True, timeout=60)

                if result.returncode == 0:
                    self.logger.info(f"Audio generato con successo: {output_file}")
                    return output_file
                else:
                    self.logger.error(f"Errore Piper: {result.stderr}")
                    return None

            finally:
                # Pulisci file temporaneo
                if os.path.exists(temp_file_path):
                    os.remove(temp_file_path)

        except Exception as e:
            self.logger.error(f"Errore nella sintesi Piper: {e}")
            return None

    def play_audio(self, audio_file: str) -> bool:
        """Riproduce il file audio."""
        try:
            if os.path.exists(audio_file):
                # Usa subprocess per riprodurre
                result = subprocess.run(
                    ["aplay", audio_file] if os.name == "posix" else ["start", audio_file],
                    capture_output=True,
                    timeout=60
                )
                return result.returncode == 0
            return False
        except Exception as e:
            self.logger.error(f"Errore nella riproduzione audio: {e}")
            return False

    def cleanup_cache(self, max_age_days: int = 7):
        """Pulisce i file cache più vecchi di max_age_days."""
        try:
            import time
            from datetime import datetime, timedelta

            cutoff_time = time.time() - (max_age_days * 24 * 60 * 60)
            cleaned_count = 0

            for filename in os.listdir(self.cache_dir):
                if filename.startswith("piper_") and filename.endswith(".wav"):
                    filepath = os.path.join(self.cache_dir, filename)
                    if os.path.getmtime(filepath) < cutoff_time:
                        os.remove(filepath)
                        cleaned_count += 1

            if cleaned_count > 0:
                self.logger.info(f"Cache pulita: {cleaned_count} file rimossi")

        except Exception as e:
            self.logger.error(f"Errore nella pulizia cache: {e}")

# Test del motore
if __name__ == "__main__":
    engine = PiperTTSEngine()

    if PIPER_AVAILABLE:
        print("🔊 Test Piper TTS Engine...")

        # Test sintesi
        audio_file = engine.synthesize(
            "Ciao! Sono un sintetizzatore vocale open-source basato su Piper.",
            voice="Italian - Female (riccardo-fasol)",
            rate=1.0,
            pitch=1.0
        )

        if audio_file:
            print(f"✅ Audio generato: {audio_file}")
        else:
            print("❌ Errore nella generazione audio")
    else:
        print("❌ Piper non disponibile")