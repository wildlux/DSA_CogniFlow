# TTS/engines/coqui_tts_engine.py
# Coqui TTS Engine - Sintetizzatore avanzato con AI

import os
import logging
import subprocess
import json
from typing import List, Dict, Optional, Any

try:
    from TTS.api import TTS
    COQUI_AVAILABLE = True
except ImportError:
    COQUI_AVAILABLE = False
    logging.warning("Coqui TTS non disponibile. Installare con: pip install TTS")

class CoquiTTSEngine:
    """Motore TTS basato su Coqui TTS - AI-powered speech synthesis."""

    def __init__(self):
        self.logger = logging.getLogger("CoquiTTSEngine")
        self.cache_dir = os.path.join(os.path.dirname(__file__), "..", "cache")
        self.models_dir = os.path.join(os.path.dirname(__file__), "..", "voices", "coqui")
        self.config_file = os.path.join(os.path.dirname(__file__), "..", "configs", "coqui_config.json")

        # Crea le directory
        for directory in [self.cache_dir, self.models_dir]:
            os.makedirs(directory, exist_ok=True)

        self.tts_instance = None
        self.current_model = None

        if COQUI_AVAILABLE:
            self._initialize_coqui()

    def _initialize_coqui(self):
        """Inizializza Coqui TTS."""
        try:
            self.logger.info("Coqui TTS inizializzato")
        except Exception as e:
            self.logger.error(f"Errore nell'inizializzazione di Coqui TTS: {e}")

    def get_available_voices(self) -> List[Dict[str, Any]]:
        """Restituisce la lista dei modelli/voci disponibili."""
        models = [
            {
                "name": "Italian - Female (tts_models/it/mai/tacotron2-DDC)",
                "model_name": "tts_models/it/mai/tacotron2-DDC",
                "language": "it-IT",
                "gender": "Female",
                "quality": "High",
                "type": "Tacotron2",
                "size_gb": 0.5
            },
            {
                "name": "English - Female (tts_models/en/ljspeech/neural_vocoder)",
                "model_name": "tts_models/en/ljspeech/neural_vocoder",
                "language": "en-US",
                "gender": "Female",
                "quality": "High",
                "type": "Neural",
                "size_gb": 1.2
            },
            {
                "name": "English - Male (tts_models/en/vctk/sc-glow-tts)",
                "model_name": "tts_models/en/vctk/sc-glow-tts",
                "language": "en-US",
                "gender": "Male",
                "quality": "High",
                "type": "Glow-TTS",
                "size_gb": 0.8
            },
            {
                "name": "Spanish - Female (tts_models/es/mai/tacotron2-DDC)",
                "model_name": "tts_models/es/mai/tacotron2-DDC",
                "language": "es-ES",
                "gender": "Female",
                "quality": "High",
                "type": "Tacotron2",
                "size_gb": 0.5
            },
            {
                "name": "French - Female (tts_models/fr/mai/tacotron2-DDC)",
                "model_name": "tts_models/fr/mai/tacotron2-DDC",
                "language": "fr-FR",
                "gender": "Female",
                "quality": "High",
                "type": "Tacotron2",
                "size_gb": 0.5
            },
            {
                "name": "German - Female (tts_models/de/mai/tacotron2-DDC)",
                "model_name": "tts_models/de/mai/tacotron2-DDC",
                "language": "de-DE",
                "gender": "Female",
                "quality": "High",
                "type": "Tacotron2",
                "size_gb": 0.5
            },
            {
                "name": "Multilingual - Female (tts_models/multilingual/multi-dataset/bark)",
                "model_name": "tts_models/multilingual/multi-dataset/bark",
                "language": "multi",
                "gender": "Female",
                "quality": "Very High",
                "type": "Bark",
                "size_gb": 5.0
            }
        ]

        return models

    def load_model(self, model_name: str) -> bool:
        """Carica un modello specifico."""
        try:
            if not COQUI_AVAILABLE:
                self.logger.error("Coqui TTS non disponibile")
                return False

            self.logger.info(f"Caricamento modello: {model_name}")

            # Scarica e carica il modello
            self.tts_instance = TTS(model_name)
            self.current_model = model_name

            self.logger.info(f"Modello {model_name} caricato con successo")
            return True

        except Exception as e:
            self.logger.error(f"Errore nel caricamento del modello {model_name}: {e}")
            return False

    def synthesize(self, text: str, voice: str = "tts_models/it/mai/tacotron2-DDC",
                  rate: float = 1.0, pitch: float = 1.0,
                  volume: float = 1.0) -> Optional[str]:
        """
        Sintetizza il testo in audio usando Coqui TTS.

        Args:
            text: Testo da sintetizzare
            voice: Modello da utilizzare
            rate: Velocità (0.5-2.0)
            pitch: Intonazione (0.5-2.0)
            volume: Volume (0.0-1.0)

        Returns:
            Path del file audio generato o None se errore
        """
        if not COQUI_AVAILABLE:
            self.logger.error("Coqui TTS non disponibile")
            return None

        try:
            # Carica il modello se necessario
            if self.current_model != voice:
                if not self.load_model(voice):
                    return None

            # Crea nome file unico
            import hashlib
            import time
            hash_input = f"{text}_{voice}_{rate}_{pitch}_{volume}_{time.time()}"
            file_hash = hashlib.md5(hash_input.encode()).hexdigest()[:8]
            output_file = os.path.join(self.cache_dir, f"coqui_{file_hash}.wav")

            # Verifica cache
            if os.path.exists(output_file):
                self.logger.info(f"File trovato in cache: {output_file}")
                return output_file

            # Sintetizza
            self.tts_instance.tts_to_file(
                text=text,
                file_path=output_file,
                speed=rate,
                pitch=pitch
            )

            self.logger.info(f"Audio generato con successo: {output_file}")
            return output_file

        except Exception as e:
            self.logger.error(f"Errore nella sintesi Coqui TTS: {e}")
            return None

    def play_audio(self, audio_file: str) -> bool:
        """Riproduce il file audio."""
        try:
            if os.path.exists(audio_file):
                # Usa subprocess per riprodurre
                result = subprocess.run(
                    ["aplay", audio_file] if os.name == "posix" else ["start", audio_file],
                    capture_output=True,
                    timeout=60
                )
                return result.returncode == 0
            return False
        except Exception as e:
            self.logger.error(f"Errore nella riproduzione audio: {e}")
            return False

    def cleanup_cache(self, max_age_days: int = 7):
        """Pulisce i file cache più vecchi di max_age_days."""
        try:
            import time
            from datetime import datetime, timedelta

            cutoff_time = time.time() - (max_age_days * 24 * 60 * 60)
            cleaned_count = 0

            for filename in os.listdir(self.cache_dir):
                if filename.startswith("coqui_") and filename.endswith(".wav"):
                    filepath = os.path.join(self.cache_dir, filename)
                    if os.path.getmtime(filepath) < cutoff_time:
                        os.remove(filepath)
                        cleaned_count += 1

            if cleaned_count > 0:
                self.logger.info(f"Cache pulita: {cleaned_count} file rimossi")

        except Exception as e:
            self.logger.error(f"Errore nella pulizia cache: {e}")

    def get_model_info(self, model_name: str) -> Optional[Dict[str, Any]]:
        """Ottiene informazioni su un modello specifico."""
        try:
            models = self.get_available_voices()
            return next((m for m in models if m["model_name"] == model_name), None)
        except Exception as e:
            self.logger.error(f"Errore nel recupero info modello: {e}")
            return None

# Test del motore
if __name__ == "__main__":
    engine = CoquiTTSEngine()

    if COQUI_AVAILABLE:
        print("🔊 Test Coqui TTS Engine...")

        # Test sintesi
        audio_file = engine.synthesize(
            "Ciao! Sono un sintetizzatore vocale basato su AI con Coqui TTS.",
            voice="tts_models/it/mai/tacotron2-DDC",
            rate=1.0,
            pitch=1.0
        )

        if audio_file:
            print(f"✅ Audio generato: {audio_file}")
        else:
            print("❌ Errore nella generazione audio")
    else:
        print("❌ Coqui TTS non disponibile")