# 🎵 TTS - Sistema di Sintesi Vocale Avanzato

Questa cartella contiene un sistema completo di sintesi vocale con **5 diversi motori TTS** per garantire la massima qualità e compatibilità.

## 📁 Struttura della Cartella

```
TTS/
├── tts_manager.py          # Sistema TTS originale (compatibilità)
├── tts_engine_manager.py   # Gestore unificato di tutti i motori
├── engines/                # Motori TTS individuali
│   ├── edge_tts_engine.py  # Microsoft Edge TTS
│   ├── piper_tts_engine.py # Piper TTS (open-source)
│   └── coqui_tts_engine.py # Coqui TTS (AI-powered)
├── cache/                  # Cache dei file audio generati
├── configs/                # Configurazioni per ogni motore
└── voices/                 # Modelli e voci scaricate
    ├── pyttsx3/           # Voci di sistema
    ├── edge_tts/          # Voci Edge TTS
    ├── piper/             # Modelli Piper
    └── coqui/             # Modelli Coqui
```

## 🔊 Motori TTS Disponibili

### 1. **pyttsx3** - Motore Base
- **Tipo**: Sistema operativo
- **Qualità**: Media
- **Velocità**: Veloce
- **Lingue**: it, en, es, fr, de
- **Vantaggi**: Sempre disponibile, veloce
- **Installazione**: Inclusa in Python

### 2. **gTTS** - Google Text-to-Speech
- **Tipo**: Online (Google)
- **Qualità**: Media
- **Velocità**: Media
- **Lingue**: 8+ lingue
- **Vantaggi**: Molte lingue, gratuita
- **Installazione**: `pip install gtts`

### 3. **Edge TTS** - Microsoft Edge
- **Tipo**: Microsoft Edge
- **Qualità**: Alta
- **Velocità**: Media
- **Lingue**: 5+ lingue
- **Vantaggi**: Qualità eccellente, voci realistiche
- **Installazione**: `pip install edge-tts`

### 4. **Piper TTS** - Open-Source
- **Tipo**: Open-source
- **Qualità**: Alta
- **Velocità**: Media
- **Lingue**: 5+ lingue
- **Vantaggi**: Open-source, modelli locali
- **Installazione**: `pip install piper-tts`

### 5. **Coqui TTS** - AI-Powered
- **Tipo**: AI/Deep Learning
- **Qualità**: Molto Alta
- **Velocità**: Lenta
- **Lingue**: 6+ lingue
- **Vantaggi**: Qualità superiore, vocoder avanzato
- **Installazione**: `pip install TTS`

## 🚀 Utilizzo

### Utilizzo Base
```python
from TTS.tts_engine_manager import tts_manager

# Sintetizza testo
audio_file = tts_manager.synthesize(
    "Ciao! Sono un sintetizzatore vocale avanzato.",
    engine="edge_tts",  # o "pyttsx3", "gtts", "piper", "coqui"
    voice="it-IT-ElsaNeural",
    speed=1.0,
    pitch=1.0
)

if audio_file:
    tts_manager.play_audio(audio_file)
```

### Utilizzo Avanzato
```python
# Cambia motore
tts_manager.set_engine("coqui")

# Ottieni voci disponibili
voices = tts_manager.get_available_voices("edge_tts")
print(f"Voci disponibili: {len(voices)}")

# Ottieni info motori
engines = tts_manager.get_available_engines()
for engine in engines:
    print(f"{engine['name']}: {engine['quality']} quality")
```

### Configurazione
```python
# Modifica configurazione
tts_manager.config["default_engine"] = "edge_tts"
tts_manager.config["auto_fallback"] = True
tts_manager.save_config()
```

## ⚙️ Caratteristiche Avanzate

### **Auto-Fallback**
Se un motore fallisce, il sistema prova automaticamente gli altri:
```python
# Ordine di fallback: pyttsx3 → gTTS → Edge TTS → Piper → Coqui
tts_manager.synthesize("Testo", engine="coqui")  # Se fallisce, usa Edge TTS
```

### **Cache Intelligente**
- File audio cachati per evitare rigenerazioni
- Pulizia automatica dei file vecchi
- Hash dei parametri per identificare file unici

### **Gestione Voci**
- Voci diverse per ogni motore
- Supporto multilingua
- Configurazioni personalizzate per voce

## 📊 Confronto Motori

| Motore | Qualità | Velocità | Lingue | Installazione | Requisiti |
|--------|---------|----------|--------|---------------|-----------|
| pyttsx3 | ⭐⭐⭐ | ⭐⭐⭐⭐⭐ | ⭐⭐⭐ | ✅ Facile | Sistema |
| gTTS | ⭐⭐⭐ | ⭐⭐⭐ | ⭐⭐⭐⭐⭐ | ✅ Facile | Internet |
| Edge TTS | ⭐⭐⭐⭐⭐ | ⭐⭐⭐ | ⭐⭐⭐⭐ | ✅ Facile | Internet |
| Piper | ⭐⭐⭐⭐⭐ | ⭐⭐⭐ | ⭐⭐⭐⭐ | ⭐⭐⭐ | Modelli |
| Coqui | ⭐⭐⭐⭐⭐ | ⭐⭐ | ⭐⭐⭐⭐ | ⭐⭐⭐ | GPU/CPU |

## 🛠️ Installazione e Setup

### Installazione Completa
```bash
# Installa tutti i motori TTS
pip install gtts edge-tts piper-tts TTS

# Per Piper, scarica anche i modelli
# Vedi: https://github.com/rhasspy/piper/releases
```

### Configurazione Iniziale
```python
# Test di tutti i motori
engines = tts_manager.get_available_engines()
for engine in engines:
    if engine["available"]:
        print(f"✅ {engine['name']} è disponibile")
    else:
        print(f"❌ {engine['name']} non disponibile")
```

## 🔧 Risoluzione Problemi

### pyttsx3 non funziona
```python
# Su Linux, installa espeak
sudo apt-get install espeak-ng

# Su Windows, pyttsx3 dovrebbe funzionare out-of-the-box
```

### Edge TTS lento
```python
# Edge TTS richiede connessione internet
# Usa cache per evitare download ripetuti
tts_manager.config["cache_enabled"] = True
```

### Piper senza modelli
```python
# Scarica modelli da:
# https://github.com/rhasspy/piper/releases
# Inserisci i file .onnx nella cartella voices/piper/
```

### Coqui lento
```python
# Coqui è lento ma di alta qualità
# Usa solo per testi importanti
# Considera GPU per accelerazione
```

## 📈 Performance

### Ottimizzazioni
- **Cache**: Evita rigenerazione audio identico
- **Fallback**: Passa automaticamente al motore migliore disponibile
- **Async**: Alcuni motori supportano elaborazione asincrona
- **Streaming**: Possibilità di streaming audio

### Consigli per Performance
1. **Usa cache** per testi ripetuti
2. **Scegli motore** basato su esigenze:
   - **Velocità**: pyttsx3, gTTS
   - **Qualità**: Edge TTS, Piper, Coqui
   - **Offline**: pyttsx3, Piper, Coqui
   - **Multilingua**: gTTS, Edge TTS

## 🔄 Integrazione con l'Applicazione

Il sistema è progettato per integrarsi automaticamente:

1. **Auto-detection**: Rileva motori disponibili
2. **Fallback**: Passa automaticamente ad altri motori
3. **Configurazione**: Salva preferenze utente
4. **Cache**: Gestisce automaticamente i file temporanei

## 📝 Note Tecniche

- **File audio**: Salvati in `Audio/` (non in `TTS/cache/`)
- **Configurazioni**: In `TTS/configs/`
- **Voci**: In `TTS/voices/` per modelli locali
- **Log**: Integrazione con sistema di logging principale

## 🎯 Prossimi Sviluppi

- [ ] Supporto per più lingue
- [ ] Streaming audio in tempo reale
- [ ] Integrazione con modelli AI per prosodia
- [ ] Supporto per file audio custom
- [ ] Interfaccia web per configurazione

## 🆘 Supporto

Per problemi specifici:

- **pyttsx3**: Documentazione Python
- **gTTS**: https://gtts.readthedocs.io/
- **Edge TTS**: https://github.com/rany2/edge-tts
- **Piper**: https://github.com/rhasspy/piper
- **Coqui**: https://tts.readthedocs.io/

---

**Il sistema TTS è ora completo e pronto per offrire la migliore esperienza vocale possibile!** 🎵✨