# GPU - Accelerazione Grafica

Questa cartella contiene tutti i moduli relativi all'accelerazione GPU per l'applicazione DSA.

## File contenuti:

- `gpu_accelerator.py` - Modulo principale per l'accelerazione GPU
- `gpu_detector.py` - Rilevamento e configurazione delle GPU disponibili
- `GPU_ACCELERATION_README.md` - Documentazione dettagliata sull'accelerazione GPU

## Funzionalità:

- Rilevamento automatico delle GPU disponibili (NVIDIA, AMD, Intel)
- Configurazione ottimale per l'accelerazione
- Fallback automatico su CPU se GPU non disponibile
- Monitoraggio delle prestazioni GPU

## Utilizzo:

```python
from GPU.gpu_accelerator import initialize_gpu_acceleration

# Inizializza l'accelerazione GPU
gpu_config = initialize_gpu_acceleration()
```