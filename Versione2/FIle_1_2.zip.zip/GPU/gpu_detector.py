# gpu_detector.py

import cv2
import numpy as np
import logging
from typing import Tuple, Optional, Dict, Any
# Import semplificato per evitare errori
import cv2
import numpy as np
import logging
from typing import Tuple, Optional, Dict, Any

class GPUAcceleratedFaceDetector(BaseDetector):
    """
    Rilevatore di facce con accelerazione GPU.
    Utilizza CUDA o ROCm quando disponibile, con fallback su CPU.
    """

    def __init__(self, enabled: bool = False):
        super().__init__(enabled)
        self.gpu_manager = get_gpu_manager()
        self.use_gpu = False
        self.gpu_face_cascade = None
        self.cpu_face_cascade = None
        self._initialize_detectors()

    def _initialize_detectors(self):
        """Inizializza i rilevatori CPU e GPU."""
        # Inizializza rilevatore CPU (fallback)
        try:
            import cv2.data
            cascade_path = cv2.data.haarcascades + 'haarcascade_frontalface_default.xml'
            self.cpu_face_cascade = cv2.CascadeClassifier(cascade_path)
            if self.cpu_face_cascade.empty():
                self.logger.warning("File Haar cascade per CPU non trovato")
                self.cpu_face_cascade = None
        except Exception as e:
            self.logger.error(f"Errore nell'inizializzazione CPU cascade: {e}")
            self.cpu_face_cascade = None

        # Verifica se possiamo usare la GPU
        if self.gpu_manager.initialize() and is_gpu_available():
            self.use_gpu = True
            self.logger.info("Utilizzo accelerazione GPU per il rilevamento facce")
        else:
            self.use_gpu = False
            self.logger.info("Utilizzo CPU per il rilevamento facce")

    def detect(self, frame):
        """Rileva le facce usando GPU se disponibile."""
        if not self.enabled:
            return False, []

        if not self.validate_frame(frame):
            return False, []

        try:
            if self.use_gpu and self.gpu_manager.accelerator:
                return self._detect_gpu(frame)
            else:
                return self._detect_cpu(frame)

        except Exception as e:
            self.logger.error(f"Errore nel rilevamento facce: {e}")
            return False, []

    def _detect_gpu(self, frame) -> Tuple[bool, list]:
        """Rilevamento facce con GPU."""
        try:
            # Converti in scala di grigi sulla GPU se possibile
            if hasattr(self.gpu_manager.accelerator, 'upload_to_gpu'):
                # Carica il frame sulla GPU
                gpu_frame = self.gpu_manager.accelerator.upload_to_gpu(frame)
                if gpu_frame is not None:
                    # Converti in scala di grigi
                    gpu_gray = cv2.cuda.cvtColor(gpu_frame, cv2.COLOR_BGR2GRAY)
                    # Scarica dalla GPU per il rilevamento
                    gray_frame = self.gpu_manager.accelerator.download_from_gpu(gpu_gray)
                    if gray_frame is not None:
                        return self._detect_faces_in_frame(gray_frame)

            # Fallback su CPU se GPU fallisce
            return self._detect_cpu(frame)

        except Exception as e:
            self.logger.error(f"Errore nel rilevamento GPU: {e}")
            return self._detect_cpu(frame)

    def _detect_cpu(self, frame) -> Tuple[bool, list]:
        """Rilevamento facce con CPU."""
        if self.cpu_face_cascade is None:
            return False, []

        try:
            gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
            return self._detect_faces_in_frame(gray)

        except Exception as e:
            self.logger.error(f"Errore nel rilevamento CPU: {e}")
            return False, []

    def _detect_faces_in_frame(self, gray_frame) -> Tuple[bool, list]:
        """Rileva le facce nel frame in scala di grigi."""
        try:
            if self.cpu_face_cascade is None:
                return False, []

            faces = self.cpu_face_cascade.detectMultiScale(
                gray_frame,
                scaleFactor=1.05,
                minNeighbors=3,
                minSize=(30, 30),
                maxSize=(300, 300)
            )

            detected = len(faces) > 0
            if detected:
                self.logger.debug(f"Rilevate {len(faces)} facce")

            return detected, faces.tolist() if hasattr(faces, 'tolist') else list(faces)

        except Exception as e:
            self.logger.error(f"Errore nella detectMultiScale: {e}")
            return False, []


class GPUAcceleratedHandDetector(BaseDetector):
    """
    Rilevatore di mani con accelerazione GPU.
    Utilizza CUDA o ROCm quando disponibile, con fallback su CPU.
    """

    def __init__(self, enabled: bool = False):
        super().__init__(enabled)
        self.gpu_manager = get_gpu_manager()
        self.use_gpu = False
        # Range HSV per il colore della pelle
        self.lower_skin = np.array([0, 20, 70], dtype=np.uint8)
        self.upper_skin = np.array([20, 255, 255], dtype=np.uint8)
        self._initialize_gpu()

    def _initialize_gpu(self):
        """Inizializza l'accelerazione GPU."""
        if self.gpu_manager.initialize() and is_gpu_available():
            self.use_gpu = True
            self.logger.info("Utilizzo accelerazione GPU per il rilevamento mani")
        else:
            self.use_gpu = False
            self.logger.info("Utilizzo CPU per il rilevamento mani")

    def detect(self, frame):
        """Rileva le mani usando GPU se disponibile."""
        if not self.enabled:
            return False, []

        if not self.validate_frame(frame):
            return False, []

        try:
            if self.use_gpu and self.gpu_manager.accelerator:
                return self._detect_gpu(frame)
            else:
                return self._detect_cpu(frame)

        except Exception as e:
            self.logger.error(f"Errore nel rilevamento mani: {e}")
            return False, []

    def _detect_gpu(self, frame) -> Tuple[bool, list]:
        """Rilevamento mani con GPU."""
        try:
            # Carica il frame sulla GPU
            gpu_frame = self.gpu_manager.accelerator.upload_to_gpu(frame)
            if gpu_frame is None:
                return self._detect_cpu(frame)

            # Converti in HSV sulla GPU
            gpu_hsv = cv2.cuda.cvtColor(gpu_frame, cv2.COLOR_BGR2HSV)

            # Applica la maschera sulla GPU
            gpu_mask = cv2.cuda.inRange(gpu_hsv, self.lower_skin, self.upper_skin)

            # Scarica la maschera dalla GPU
            mask = self.gpu_manager.accelerator.download_from_gpu(gpu_mask)
            if mask is None:
                return self._detect_cpu(frame)

            # Processa la maschera sulla CPU
            return self._process_mask(mask)

        except Exception as e:
            self.logger.error(f"Errore nel rilevamento GPU mani: {e}")
            return self._detect_cpu(frame)

    def _detect_cpu(self, frame) -> Tuple[bool, list]:
        """Rilevamento mani con CPU."""
        try:
            hsv = cv2.cvtColor(frame, cv2.COLOR_BGR2HSV)
            mask = cv2.inRange(hsv, self.lower_skin, self.upper_skin)
            return self._process_mask(mask)

        except Exception as e:
            self.logger.error(f"Errore nel rilevamento CPU mani: {e}")
            return False, []

    def _process_mask(self, mask) -> Tuple[bool, list]:
        """Processa la maschera per trovare le mani."""
        try:
            # Operazioni morfologiche
            kernel = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (5, 5))
            mask = cv2.morphologyEx(mask, cv2.MORPH_CLOSE, kernel)
            mask = cv2.morphologyEx(mask, cv2.MORPH_OPEN, kernel)

            # Trova i contorni
            contours, _ = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

            hands = []
            for contour in contours:
                area = cv2.contourArea(contour)
                if area > 3000:  # Soglia per le mani
                    x, y, w, h = cv2.boundingRect(contour)
                    aspect_ratio = w / h if h > 0 else 0
                    if 0.5 < aspect_ratio < 2.0:  # Proporzioni ragionevoli
                        hands.append((x, y, w, h))

            detected = len(hands) > 0
            if detected:
                self.logger.debug(f"Rilevate {len(hands)} mani")

            return detected, hands

        except Exception as e:
            self.logger.error(f"Errore nell'elaborazione maschera: {e}")
            return False, []


class GPUVideoProcessor:
    """
    Processore video con accelerazione GPU per filtri e preprocessing.
    """

    def __init__(self):
        self.gpu_manager = get_gpu_manager()
        self.use_gpu = False
        self.logger = logging.getLogger("GPU_Video_Processor")

    def initialize(self) -> bool:
        """Inizializza il processore GPU."""
        if self.gpu_manager.initialize() and is_gpu_available():
            self.use_gpu = True
            self.logger.info("Processore video GPU inizializzato")
            return True
        else:
            self.use_gpu = False
            self.logger.info("Utilizzo processore video CPU")
            return False

    def apply_filter(self, frame: np.ndarray, filter_type: str = 'blur') -> np.ndarray:
        """Applica un filtro al frame usando GPU se disponibile."""
        if not self.use_gpu or not self.gpu_manager.accelerator:
            return self._apply_cpu_filter(frame, filter_type)

        try:
            # Carica il frame sulla GPU
            gpu_frame = self.gpu_manager.accelerator.upload_to_gpu(frame)
            if gpu_frame is None:
                return self._apply_cpu_filter(frame, filter_type)

            # Applica il filtro sulla GPU
            filtered_gpu = self.gpu_manager.accelerator.apply_gpu_filter(gpu_frame, filter_type)
            if filtered_gpu is None:
                return self._apply_cpu_filter(frame, filter_type)

            # Scarica il risultato dalla GPU
            result = self.gpu_manager.accelerator.download_from_gpu(filtered_gpu)
            if result is None:
                return self._apply_cpu_filter(frame, filter_type)

            return result

        except Exception as e:
            self.logger.error(f"Errore nell'applicazione filtro GPU: {e}")
            return self._apply_cpu_filter(frame, filter_type)

    def _apply_cpu_filter(self, frame: np.ndarray, filter_type: str) -> np.ndarray:
        """Applica un filtro usando CPU."""
        try:
            if filter_type == 'blur':
                return cv2.blur(frame, (5, 5))
            elif filter_type == 'gaussian':
                return cv2.GaussianBlur(frame, (5, 5), 0)
            elif filter_type == 'median':
                return cv2.medianBlur(frame, 5)
            elif filter_type == 'bilateral':
                return cv2.bilateralFilter(frame, 9, 75, 75)
            else:
                return frame

        except Exception as e:
            self.logger.error(f"Errore nell'applicazione filtro CPU: {e}")
            return frame

    def preprocess_frame(self, frame: np.ndarray) -> np.ndarray:
        """Preprocessa il frame per l'elaborazione."""
        if not self.validate_frame(frame):
            return frame

        # Applica ottimizzazioni GPU se disponibili
        if self.use_gpu and self.gpu_manager.accelerator:
            return self.gpu_manager.accelerator.optimize_for_gpu(frame)

        return frame

    def validate_frame(self, frame) -> bool:
        """Valida che il frame sia utilizzabile."""
        if frame is None:
            return False

        if not hasattr(frame, 'shape'):
            return False

        if len(frame.shape) < 2:
            return False

        return True


# Istanza globale del processore video GPU
gpu_video_processor = GPUVideoProcessor()

def get_gpu_video_processor() -> GPUVideoProcessor:
    """Ottiene l'istanza globale del processore video GPU."""
    return gpu_video_processor

def initialize_gpu_video_processor() -> bool:
    """Inizializza il processore video GPU."""
    return gpu_video_processor.initialize()