# gpu_accelerator.py

import logging
import numpy as np
from typing import Optional, Tuple, Dict, Any
from abc import ABC, abstractmethod

class GPUAccelerator(ABC):
    """
    Classe base astratta per l'accelerazione GPU.
    Supporta sia NVIDIA CUDA che AMD ROCm.
    """

    def __init__(self):
        self.logger = logging.getLogger("GPU_Accelerator")
        self.is_available = False
        self.device_name = "CPU"
        self.backend = "CPU"

    @abstractmethod
    def initialize(self) -> bool:
        """Inizializza l'acceleratore GPU."""
        pass

    @abstractmethod
    def is_gpu_available(self) -> bool:
        """Verifica se la GPU è disponibile."""
        pass

    @abstractmethod
    def get_device_info(self) -> Dict[str, Any]:
        """Ottiene informazioni sul dispositivo GPU."""
        pass

    def get_memory_info(self) -> Dict[str, float]:
        """Ottiene informazioni sulla memoria GPU."""
        return {
            'total_memory': 0.0,
            'free_memory': 0.0,
            'used_memory': 0.0
        }

    def optimize_for_gpu(self, data: np.ndarray) -> np.ndarray:
        """Ottimizza i dati per l'elaborazione GPU."""
        return data


class CUDAAccelerator(GPUAccelerator):
    """
    Acceleratore per GPU NVIDIA con CUDA.
    """

    def __init__(self):
        super().__init__()
        self.backend = "CUDA"
        self.cuda_available = False
        self.gpumat_available = False

    def initialize(self) -> bool:
        """Inizializza CUDA e le librerie GPU."""
        try:
            # Verifica CUDA
            import cv2
            if hasattr(cv2, 'cuda') and cv2.cuda.getCudaEnabledDeviceCount() > 0:
                self.cuda_available = True
                cv2.cuda.setDevice(0)
                self.device_name = cv2.cuda.getDevice()
                self.logger.info(f"CUDA inizializzato su dispositivo: {self.device_name}")
            else:
                self.logger.warning("CUDA non disponibile o non abilitato in OpenCV")
                return False

            # Verifica cv2.cuda.GpuMat
            try:
                test_mat = cv2.cuda.GpuMat()
                self.gpumat_available = True
                self.logger.info("GpuMat disponibile per CUDA")
            except:
                self.logger.warning("GpuMat non disponibile")
                self.gpumat_available = False

            self.is_available = self.cuda_available
            return self.is_available

        except ImportError as e:
            self.logger.error(f"CUDA non disponibile: {e}")
            return False
        except Exception as e:
            self.logger.error(f"Errore nell'inizializzazione CUDA: {e}")
            return False

    def is_gpu_available(self) -> bool:
        """Verifica se CUDA è disponibile."""
        try:
            import cv2
            return hasattr(cv2, 'cuda') and cv2.cuda.getCudaEnabledDeviceCount() > 0
        except:
            return False

    def get_device_info(self) -> Dict[str, Any]:
        """Ottiene informazioni sul dispositivo CUDA."""
        info = {
            'backend': 'CUDA',
            'available': self.is_available,
            'device_name': self.device_name,
            'cuda_available': self.cuda_available,
            'gpumat_available': self.gpumat_available
        }

        if self.cuda_available:
            try:
                import cv2
                info.update({
                    'device_count': cv2.cuda.getCudaEnabledDeviceCount(),
                    'current_device': cv2.cuda.getDevice()
                })
            except:
                pass

        return info

    def get_memory_info(self) -> Dict[str, float]:
        """Ottiene informazioni sulla memoria CUDA."""
        # Nota: OpenCV CUDA non fornisce API dirette per la memoria
        # Queste sono stime basate sul sistema
        return {
            'total_memory': 0.0,  # Non disponibile in OpenCV
            'free_memory': 0.0,
            'used_memory': 0.0
        }

    def upload_to_gpu(self, frame: np.ndarray) -> Optional[object]:
        """Carica un frame sulla GPU."""
        if not self.gpumat_available:
            return None

        try:
            import cv2
            gpu_mat = cv2.cuda.GpuMat()
            gpu_mat.upload(frame)
            return gpu_mat
        except Exception as e:
            self.logger.error(f"Errore nel caricamento su GPU: {e}")
            return None

    def download_from_gpu(self, gpu_mat) -> Optional[np.ndarray]:
        """Scarica un frame dalla GPU."""
        if not self.gpumat_available:
            return None

        try:
            import cv2
            # Verifica che sia un GpuMat valido
            if hasattr(gpu_mat, 'download') and callable(getattr(gpu_mat, 'download')):
                result = gpu_mat.download()
                return result
            else:
                self.logger.warning("Metodo download non disponibile per GpuMat")
                return None
        except Exception as e:
            self.logger.error(f"Errore nel download dalla GPU: {e}")
            return None

    def apply_gpu_filter(self, gpu_mat, filter_type: str):
        """Applica un filtro GPU al frame."""
        if not self.gpumat_available:
            return None

        try:
            import cv2.cuda

            # Verifica se i metodi CUDA sono disponibili
            if not hasattr(cv2.cuda, 'blur'):
                self.logger.warning("Filtri CUDA non disponibili")
                return gpu_mat

            if filter_type == 'blur' and hasattr(cv2.cuda, 'blur'):
                return cv2.cuda.blur(gpu_mat, (5, 5))
            elif filter_type == 'gaussian' and hasattr(cv2.cuda, 'GaussianBlur'):
                return cv2.cuda.GaussianBlur(gpu_mat, (5, 5), 0)
            elif filter_type == 'median' and hasattr(cv2.cuda, 'medianBlur'):
                return cv2.cuda.medianBlur(gpu_mat, 5)
            elif filter_type == 'bilateral' and hasattr(cv2.cuda, 'bilateralFilter'):
                return cv2.cuda.bilateralFilter(gpu_mat, 9, 75, 75)
            else:
                return gpu_mat

        except Exception as e:
            self.logger.error(f"Errore nell'applicazione del filtro GPU {filter_type}: {e}")
            return None


class ROCmAccelerator(GPUAccelerator):
    """
    Acceleratore per GPU AMD con ROCm.
    """

    def __init__(self):
        super().__init__()
        self.backend = "ROCm"
        self.rocm_available = False

    def initialize(self) -> bool:
        """Inizializza ROCm."""
        try:
            # Verifica se ROCm è disponibile
            import torch
            if torch.cuda.is_available():
                self.rocm_available = True
                self.device_name = torch.cuda.get_device_name(0)
                self.logger.info(f"ROCm inizializzato su dispositivo: {self.device_name}")
                self.is_available = True
                return True
            else:
                self.logger.warning("ROCm/ROCm non disponibile")
                return False

        except ImportError:
            self.logger.warning("PyTorch non disponibile per ROCm")
            return False
        except Exception as e:
            self.logger.error(f"Errore nell'inizializzazione ROCm: {e}")
            return False

    def is_gpu_available(self) -> bool:
        """Verifica se ROCm è disponibile."""
        try:
            import torch
            return torch.cuda.is_available()
        except:
            return False

    def get_device_info(self) -> Dict[str, Any]:
        """Ottiene informazioni sul dispositivo ROCm."""
        info = {
            'backend': 'ROCm',
            'available': self.is_available,
            'device_name': self.device_name,
            'rocm_available': self.rocm_available
        }

        if self.rocm_available:
            try:
                import torch
                info.update({
                    'device_count': torch.cuda.device_count(),
                    'current_device': torch.cuda.current_device(),
                    'device_capability': torch.cuda.get_device_capability(0)
                })
            except:
                pass

        return info

    def get_memory_info(self) -> Dict[str, float]:
        """Ottiene informazioni sulla memoria ROCm."""
        if not self.rocm_available:
            return super().get_memory_info()

        try:
            import torch
            memory_info = torch.cuda.get_device_properties(0)
            total_memory = memory_info.total_memory / (1024**3)  # GB
            allocated = torch.cuda.memory_allocated(0) / (1024**3)
            reserved = torch.cuda.memory_reserved(0) / (1024**3)

            return {
                'total_memory': total_memory,
                'free_memory': total_memory - reserved,
                'used_memory': allocated
            }
        except:
            return super().get_memory_info()


class GPUManager:
    """
    Gestore centralizzato per l'accelerazione GPU.
    Rileva automaticamente la GPU disponibile e configura l'acceleratore appropriato.
    """

    def __init__(self):
        self.logger = logging.getLogger("GPU_Manager")
        self.accelerator: Optional[GPUAccelerator] = None
        self.gpu_type = "CPU"
        self.is_initialized = False

    def initialize(self) -> bool:
        """Inizializza la GPU più performante disponibile."""
        if self.is_initialized:
            return True

        # Prova prima CUDA (NVIDIA)
        cuda_accelerator = CUDAAccelerator()
        if cuda_accelerator.is_gpu_available():
            self.logger.info("GPU NVIDIA CUDA rilevata, inizializzazione...")
            if cuda_accelerator.initialize():
                self.accelerator = cuda_accelerator
                self.gpu_type = "NVIDIA_CUDA"
                self.is_initialized = True
                self.logger.info("Accelerazione CUDA inizializzata con successo")
                return True

        # Prova poi ROCm (AMD)
        rocm_accelerator = ROCmAccelerator()
        if rocm_accelerator.is_gpu_available():
            self.logger.info("GPU AMD ROCm rilevata, inizializzazione...")
            if rocm_accelerator.initialize():
                self.accelerator = rocm_accelerator
                self.gpu_type = "AMD_ROCm"
                self.is_initialized = True
                self.logger.info("Accelerazione ROCm inizializzata con successo")
                return True

        # Fallback su CPU
        self.logger.info("Nessuna GPU compatibile rilevata, uso CPU")
        self.gpu_type = "CPU"
        self.is_initialized = True
        return False

    def get_accelerator(self) -> Optional[GPUAccelerator]:
        """Ottiene l'acceleratore GPU corrente."""
        return self.accelerator

    def get_gpu_info(self) -> Dict[str, Any]:
        """Ottiene informazioni sulla GPU."""
        if not self.is_initialized:
            self.initialize()

        if self.accelerator:
            info = self.accelerator.get_device_info()
        else:
            info = {
                'backend': 'CPU',
                'available': False,
                'device_name': 'CPU',
                'gpu_type': self.gpu_type
            }

        info.update({
            'gpu_type': self.gpu_type,
            'initialized': self.is_initialized
        })

        return info

    def is_gpu_accelerated(self) -> bool:
        """Verifica se l'accelerazione GPU è attiva."""
        return self.accelerator is not None and self.accelerator.is_available

    def get_memory_info(self) -> Dict[str, float]:
        """Ottiene informazioni sulla memoria GPU."""
        if self.accelerator:
            return self.accelerator.get_memory_info()
        return {
            'total_memory': 0.0,
            'free_memory': 0.0,
            'used_memory': 0.0
        }

    def optimize_frame_for_gpu(self, frame: np.ndarray) -> np.ndarray:
        """Ottimizza un frame per l'elaborazione GPU."""
        if self.accelerator:
            return self.accelerator.optimize_for_gpu(frame)
        return frame

    def log_gpu_status(self):
        """Logga lo stato della GPU."""
        info = self.get_gpu_info()
        memory = self.get_memory_info()

        self.logger.info(f"GPU Status: {info}")
        if memory['total_memory'] > 0:
            self.logger.info(f"GPU Memory: {memory['used_memory']:.2f}GB / {memory['total_memory']:.2f}GB")


# Istanza globale del gestore GPU
gpu_manager = GPUManager()

def get_gpu_manager() -> GPUManager:
    """Ottiene l'istanza globale del gestore GPU."""
    return gpu_manager

def is_gpu_available() -> bool:
    """Verifica se la GPU è disponibile per l'accelerazione."""
    return gpu_manager.is_gpu_accelerated()

def initialize_gpu() -> bool:
    """Inizializza l'accelerazione GPU."""
    return gpu_manager.initialize()