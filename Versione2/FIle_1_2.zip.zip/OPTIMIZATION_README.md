# 🎯 Assistente DSA - Documentazione Completa

**Assistente DSA** è un'applicazione desktop avanzata progettata per supportare persone con dislessia attraverso tecnologie di intelligenza artificiale, riconoscimento vocale, e interfacce adattive.

## 📋 Indice

- [Caratteristiche Principali](#-caratteristiche-principali)
- [Architettura del Software](#-architettura-del-software)
- [Installazione](#-installazione)
- [Utilizzo](#-utilizzo)
- [Configurazione](#-configurazione)
- [Moduli del Sistema](#-moduli-del-sistema)
- [Monitoraggio Sistema](#-monitoraggio-sistema)
- [Risoluzione Problemi](#-risoluzione-problemi)
- [Contribuzione](#-contribuzione)
- [Licenza](#-licenza)

## 🌟 Caratteristiche Principali

### 🎤 **Riconoscimento Vocale Avanzato**
- Supporto multilingua (Italiano, Inglese, Francese, Tedesco, Spagnolo)
- Modelli Vosk ottimizzati per diverse lingue
- Trascrizione in tempo reale con alta accuratezza

### 🧠 **Intelligenza Artificiale Integrata**
- Integrazione con Ollama per modelli AI locali
- Supporto per modelli Gemma, LLaVA, Mistral, e altri
- Elaborazione intelligente del testo per supporto alla lettura

### 📝 **Interfaccia Adattiva**
- Widget di testo trascinabili e personalizzabili
- Layout a tre colonne per organizzazione ottimale
- Temi personalizzabili (chiaro/scuro)
- Font e dimensioni adattabili

### 🔊 **Sintesi Vocale (TTS)**
- Motori TTS multipli (pyttsx3, edge-tts, piper, coqui)
- Controllo velocità, tono e pitch
- Lettura automatica dei contenuti

### 👁️ **Rilevamento Visivo**
- Riconoscimento facciale con MediaPipe
- Rilevamento mani e gesti
- Supporto GPU per accelerazione
- Emotion detection e analisi espressioni

### ⚡ **Monitoraggio Sistema**
- Monitoraggio CPU e temperatura in tempo reale
- Avvisi automatici per sovraccarico
- Protezione contro il surriscaldamento
- Terminazione sicura in caso di emergenza

## 🏗️ Architettura del Software

```
assistente_dsa/
├── main_app.py                 # Applicazione principale
├── setup_generici/             # Configurazioni e costanti
│   ├── constants.py           # Costanti centralizzate
│   └── settings.json          # Configurazioni utente
├── CPU_Check_Temperature/      # Monitoraggio sistema
├── EVENT_KEYBOARD/             # Scorciatoie tastiera
├── EVENT_MOUSE/                # Eventi mouse
├── TTS_to_READING/             # Lettura vocale
├── TTS_To_Text/                # Motori TTS
├── AI/                         # Intelligenza artificiale
├── Audio/                      # Elaborazione audio
├── Video/                      # Elaborazione video
├── UI/                         # Interfaccia utente
├── GPU/                        # Accelerazione GPU
├── NETWORK_LAN/                # Networking
├── ICO/                        # Icone e risorse
├── log/                        # File di log
└── saved_data/                 # Dati salvati
```

## 📦 Installazione

### Prerequisiti

**Sistema Operativo:**
- Linux (raccomandato)
- Windows 10/11
- macOS

**Python:**
- Python 3.8 o superiore
- pip per la gestione pacchetti

**Dipendenze Principali:**
```bash
pip install PyQt6
pip install psutil
pip install opencv-python
pip install speech_recognition
pip install pyttsx3
pip install requests
pip install numpy
```

### Installazione Automatica

1. **Clona il repository:**
```bash
git clone <repository-url>
cd assistente_dsa
```

2. **Installa le dipendenze:**
```bash
pip install -r requirements.txt
```

3. **Esegui l'applicazione:**
```bash
python main_app.py
```

### Installazione Manuale

Se preferisci installare manualmente:

```bash
# Dipendenze core
pip install PyQt6 psutil opencv-python

# Audio e TTS
pip install speech_recognition pyttsx3 simpleaudio

# AI e networking
pip install requests ollama

# Elaborazione dati
pip install numpy pandas

# Opzionali per funzionalità avanzate
pip install wmi          # Solo Windows
pip install torch        # Per modelli AI avanzati
```

## 🚀 Utilizzo

### Avvio Rapido

```bash
python main_app.py
```

### Interfaccia Principale

L'applicazione presenta una **interfaccia a tre colonne**:

1. **📝 Colonna A (Pensierini)**: Contenuti creativi e appunti
2. **🎯 Colonna B (Area Lavoro)**: Spazio di lavoro principale
3. **📋 Colonna C (Dettagli)**: Informazioni e dettagli

### Funzionalità Base

#### 🎤 **Riconoscimento Vocale**
1. Clicca il pulsante **"🎤 Voce"**
2. Parla chiaramente nel microfono
3. Il testo apparirà automaticamente nella colonna C

#### 🔊 **Lettura Vocale**
1. Scrivi o incolla testo in un widget
2. Clicca il pulsante **"🔊"** nel widget
3. L'applicazione leggerà il testo ad alta voce

#### 🧠 **AI Integration**
1. Scrivi un prompt nella colonna C
2. Clicca il pulsante **"🧠 AI"**
3. L'AI elaborerà il testo e fornirà una risposta

#### 💾 **Salvataggio**
- **Ctrl+S**: Salva il contenuto corrente
- **Menu File**: Opzioni avanzate di salvataggio

### Scorciatoie Tastiera

| Scorciatoia | Funzione |
|-------------|----------|
| `Ctrl+S` | Salva contenuto |
| `Ctrl+O` | Apri file |
| `F12` | Mostra/nascondi log |
| `Esc` | Chiudi dialoghi |

## ⚙️ Configurazione

### File di Configurazione

**`setup_generici/settings.json`** - Configurazioni utente

```json
{
    "theme": "Chiaro",
    "main_font_family": "Arial",
    "main_font_size": 12,
    "hand_detection_system": "Auto (Migliore)",
    "face_detection_system": "Auto (Migliore)",
    "gesture_system": "Auto (Migliore)",
    "cpu_monitoring_enabled": true,
    "temperature_monitoring_enabled": true,
    "ai_trigger": "++++"
}
```

### Configurazioni Principali

#### 🎨 **Tema e Aspetto**
- **Tema**: `Chiaro` o `Scuro`
- **Font**: Famiglia e dimensione personalizzabili
- **Layout**: Dimensioni finestra e widget

#### 🎤 **Audio**
- **Lingua microfono**: IT, EN, FR, DE, ES
- **Sensibilità**: Regolazione automatica
- **Qualità audio**: 16kHz, 16-bit

#### 🧠 **Intelligenza Artificiale**
- **Modello AI**: Gemma, LLaVA, Mistral
- **Trigger AI**: Sequenza per attivare l'AI
- **Timeout risposta**: 30 secondi

#### ⚡ **Monitoraggio Sistema**
- **CPU**: Soglia 95%, durata 30 secondi
- **Temperatura**: Soglia 80°C, durata 60 secondi
- **Segnale emergenza**: SIGTERM, SIGKILL

## 📚 Moduli del Sistema

### CPU_Check_Temperature
**Monitoraggio sistema e sicurezza**
- Monitoraggio CPU e temperatura
- Avvisi automatici
- Terminazione di emergenza

### EVENT_KEYBOARD
**Gestione input tastiera**
- Scorciatoie globali
- Gestione eventi tastiera
- Configurazione personalizzabile

### EVENT_MOUSE
**Gestione input mouse**
- Eventi drag & drop
- Menu contestuali
- Interazioni widget

### TTS_to_READING
**Lettura vocale**
- Gestione lettura testi
- Controllo thread TTS
- Fallback automatici

### TTS_To_Text
**Motori sintesi vocale**
- pyttsx3 (base)
- edge-tts (Microsoft)
- piper-tts (open source)
- coqui-tts (avanzato)

### AI
**Intelligenza artificiale**
- Integrazione Ollama
- Modelli locali
- Elaborazione testo

### Audio
**Elaborazione audio**
- Riconoscimento vocale
- Modelli Vosk
- Preprocessing audio

### Video
**Elaborazione video**
- Rilevamento facciale
- Rilevamento mani
- Emotion detection

### UI
**Interfaccia utente**
- Widget personalizzati
- Layout responsive
- Gestione temi

## 🔍 Monitoraggio Sistema

### CPU Monitoring
- **Utilizzo CPU**: Monitoraggio in tempo reale
- **Soglia critica**: 95% per 30+ secondi
- **Azione**: Invio segnale SIGTERM

### Temperature Monitoring
- **Sensori supportati**:
  - Linux: `/sys/class/thermal/thermal_zone*/temp`
  - Windows: WMI
  - psutil: sensori integrati
- **Soglie**:
  - Avviso: 80°C per 60+ secondi
  - Critico: 90°C (terminazione immediata)

### Log System
- **File log**: `log/app.log`
- **Livelli**: DEBUG, INFO, WARNING, ERROR, CRITICAL
- **Rotazione**: Automatica per evitare overflow

## 🛠️ Risoluzione Problemi

### Problemi Comuni

#### 🔊 **Audio non funziona**
```bash
# Verifica dispositivi audio
python -c "import speech_recognition as sr; print(sr.Microphone.list_microphone_names())"

# Test microfono
python -c "import pyaudio; p = pyaudio.PyAudio(); print('Audio OK')"
```

#### 🧠 **AI non risponde**
```bash
# Verifica Ollama
ollama list

# Test connessione
curl http://localhost:11434/api/tags
```

#### 📹 **Video non funziona**
```bash
# Verifica OpenCV
python -c "import cv2; print('OpenCV version:', cv2.__version__)"

# Test webcam
python -c "import cv2; cap = cv2.VideoCapture(0); print('Webcam OK' if cap.isOpened() else 'Webcam Error')"
```

#### ⚡ **CPU/Temperatura**
```bash
# Monitor manuale
python -c "import psutil; print(f'CPU: {psutil.cpu_percent()}%, Temp: {psutil.sensors_temperatures()}')"
```

### Log di Debug

Abilita il debug nel file di configurazione:

```json
{
    "log_level": "DEBUG",
    "debug_mode": true
}
```

### Reset Configurazioni

Per resetare tutte le configurazioni:

```bash
# Backup attuale
cp setup_generici/settings.json setup_generici/settings.json.backup

# Reset
rm setup_generici/settings.json
# Riavvia l'applicazione per rigenerare
```

## 🤝 Contribuzione

### Come Contribuire

1. **Fork** il repository
2. **Crea** un branch per la feature (`git checkout -b feature/nuova-funzionalita`)
3. **Commit** le modifiche (`git commit -am 'Aggiunta nuova funzionalita'`)
4. **Push** al branch (`git push origin feature/nuova-funzionalita`)
5. **Crea** una Pull Request

### Linee Guida

- **Codice**: Segui PEP 8
- **Documentazione**: Aggiorna i README
- **Test**: Aggiungi test per nuove funzionalità
- **Commit**: Messaggi chiari e descrittivi

### Aree di Sviluppo

- 🚀 **Nuovi motori TTS**
- 🧠 **Modelli AI avanzati**
- 👁️ **Miglioramento visione**
- 📱 **Supporto mobile**
- 🌐 **Traduzioni**

## 📄 Licenza

Questo progetto è distribuito sotto licenza **MIT**.

```
MIT License

Copyright (c) 2024 Assistente DSA

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
```

## 📞 Supporto

### Documentazione
- 📖 **README principale**: Questo file
- 📚 **Documentazione moduli**: In ogni cartella `README.md`
- 🔧 **Guide tecniche**: `OPTIMIZATION_README.md`

### Community
- 🐛 **Segnala bug**: GitHub Issues
- 💡 **Suggerimenti**: GitHub Discussions
- 🤝 **Contribuisci**: Pull Requests

### Contatti
- 📧 **Email**: [inserisci email]
- 🌐 **Website**: [inserisci sito web]
- 📱 **Social**: [inserisci social media]

---

**🎯 Assistente DSA** - Tecnologia al servizio dell'inclusione e dell'accessibilità