# mouse_events.py - Funzioni helper per la gestione degli eventi mouse

import logging
from PyQt6.QtCore import QEvent, Qt
from PyQt6.QtGui import QDrag, QPixmap
from PyQt6.QtCore import QMimeData
from PyQt6.QtWidgets import QApplication, QInputDialog, QMenu


def handle_draggable_mouse_press(widget, event):
    """Gestisce l'evento di pressione del mouse per i widget trascinabili."""
    if event.button() == Qt.MouseButton.LeftButton:
        widget.start_pos = event.pos()


def handle_draggable_mouse_move(widget, event):
    """Gestisce il movimento del mouse per i widget trascinabili."""
    if event.buttons() == Qt.MouseButton.LeftButton and hasattr(widget, 'start_pos') and widget.start_pos:
        distance = (event.pos() - widget.start_pos).manhattanLength()
        if distance > QApplication.startDragDistance():
            drag = QDrag(widget)
            mime = QMimeData()
            mime.setText(widget.text_label.text())
            drag.setMimeData(mime)
            drag.setPixmap(widget.grab())
            drag.exec(Qt.DropAction.CopyAction)  # Usa CopyAction per duplicare il testo


def show_draggable_context_menu(widget, pos):
    """Mostra il menu contestuale per i widget trascinabili."""
    context_menu = QMenu(widget)
    edit_action = context_menu.addAction("Modifica Testo")
    action = context_menu.exec(widget.mapToGlobal(pos))
    if action == edit_action:
        new_text, ok = QInputDialog.getMultiLineText(widget, "Modifica Testo", "Modifica il contenuto del widget:", widget.text_label.text())
        if ok:
            widget.text_label.setText(new_text)


def handle_main_window_resize(window, event):
    """Gestisce il resize della finestra principale."""
    window.video_background_label.setGeometry(window.rect())
    # Chiama il metodo originale della classe base
    from PyQt6.QtWidgets import QMainWindow
    QMainWindow.resizeEvent(window, event)


def handle_main_window_drag_enter(window, event):
    """Gestisce l'evento drag enter nella finestra principale."""
    if event.mimeData().hasText():
        event.acceptProposedAction()


def handle_main_window_drop(window, event):
    """Gestisce l'evento drop nella finestra principale."""
    if event.mimeData().hasText():
        text_to_append = event.mimeData().text()
        # Crea un nuovo widget trascinabile nella colonna B
        new_widget = window.create_draggable_text_widget(text_to_append)
        window.work_area_main_layout_b.addWidget(new_widget)
        event.acceptProposedAction()


def handle_main_window_event_filter(window, obj, event):
    """Gestisce il filtro eventi per la finestra principale."""
    if obj == window.work_area_main_scroll or obj == window.work_area_main_content:
        if event.type() == QEvent.Type.DragEnter:
            if event.mimeData().hasText():
                # Mostra il bordo tratteggiato durante il trascinamento
                window.work_area_main_scroll.setStyleSheet("""
                    QScrollArea {
                        background-color: transparent;
                        border: 3px dashed #4CAF50;
                        border-radius: 15px;
                    }
                """)
                event.acceptProposedAction()
                return True
        elif event.type() == QEvent.Type.Drop:
            if event.mimeData().hasText():
                text_to_append = event.mimeData().text()
                # Crea un nuovo widget trascinabile nella colonna B
                new_widget = window.create_draggable_text_widget(text_to_append)
                window.work_area_main_layout_b.addWidget(new_widget)

                # Ripristina il bordo normale dopo il drop
                window.work_area_main_scroll.setStyleSheet("""
                    QScrollArea {
                        background-color: transparent;
                        border: none;
                    }
                """)
                event.acceptProposedAction()
                return True
        elif event.type() == QEvent.Type.DragLeave:
            # Ripristina il bordo normale quando il trascinamento lascia l'area
            window.work_area_main_scroll.setStyleSheet("""
                QScrollArea {
                    background-color: transparent;
                    border: none;
                }
            """)
            return True

    return False