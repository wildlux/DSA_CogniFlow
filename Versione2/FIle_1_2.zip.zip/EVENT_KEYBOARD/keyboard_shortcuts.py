# keyboard_shortcuts.py - Gestione delle scorciatoie da tastiera

import logging
from PyQt6.QtGui import QShortcut, QKeySequence
from PyQt6.QtCore import Qt


class KeyboardShortcutsManager:
    """Gestore delle scorciatoie da tastiera per l'applicazione."""

    def __init__(self, parent_window):
        self.parent = parent_window
        self.shortcuts = {}
        self.setup_shortcuts()

    def setup_shortcuts(self):
        """Imposta tutte le scorciatoie da tastiera."""
        try:
            # Scorciatoia per salvare (Ctrl+S)
            self.shortcuts['save'] = QShortcut(QKeySequence("Ctrl+S"), self.parent)
            self.shortcuts['save'].activated.connect(self.parent.save_to_file)

            # Scorciatoia per aprire file (Ctrl+O)
            self.shortcuts['open'] = QShortcut(QKeySequence("Ctrl+O"), self.parent)
            self.shortcuts['open'].activated.connect(self.parent.open_file)

            # Scorciatoia per mostrare/nascondere log (F12)
            self.shortcuts['log'] = QShortcut(QKeySequence(Qt.Key.Key_F12), self.parent)
            self.shortcuts['log'].activated.connect(self.parent.toggle_log_visibility)

            logging.info("Scorciatoie da tastiera configurate con successo")

        except Exception as e:
            logging.error(f"Errore nella configurazione delle scorciatoie: {e}")

    def add_shortcut(self, name, key_sequence, callback):
        """Aggiunge una nuova scorciatoia da tastiera."""
        try:
            if name in self.shortcuts:
                logging.warning(f"Scorciatoia '{name}' già esistente, sovrascrivo")

            self.shortcuts[name] = QShortcut(QKeySequence(key_sequence), self.parent)
            self.shortcuts[name].activated.connect(callback)

            logging.info(f"Scorciatoia '{name}' aggiunta: {key_sequence}")

        except Exception as e:
            logging.error(f"Errore nell'aggiungere scorciatoia '{name}': {e}")

    def remove_shortcut(self, name):
        """Rimuove una scorciatoia da tastiera."""
        try:
            if name in self.shortcuts:
                # Disconnetti il segnale
                self.shortcuts[name].activated.disconnect()
                # Rimuovi dalla lista
                del self.shortcuts[name]
                logging.info(f"Scorciatoia '{name}' rimossa")
            else:
                logging.warning(f"Scorciatoia '{name}' non trovata")

        except Exception as e:
            logging.error(f"Errore nella rimozione della scorciatoia '{name}': {e}")

    def get_shortcuts_list(self):
        """Restituisce la lista delle scorciatoie configurate."""
        return list(self.shortcuts.keys())

    def get_shortcut_info(self, name):
        """Restituisce informazioni su una scorciatoia specifica."""
        if name in self.shortcuts:
            shortcut = self.shortcuts[name]
            return {
                'name': name,
                'key_sequence': shortcut.key().toString(),
                'enabled': shortcut.isEnabled()
            }
        return None

    def enable_shortcut(self, name, enabled=True):
        """Abilita o disabilita una scorciatoia."""
        try:
            if name in self.shortcuts:
                self.shortcuts[name].setEnabled(enabled)
                logging.info(f"Scorciatoia '{name}' {'abilitata' if enabled else 'disabilitata'}")
            else:
                logging.warning(f"Scorciatoia '{name}' non trovata")

        except Exception as e:
            logging.error(f"Errore nella modifica della scorciatoia '{name}': {e}")

    def cleanup(self):
        """Pulisce tutte le scorciatoie."""
        try:
            for name, shortcut in self.shortcuts.items():
                try:
                    shortcut.activated.disconnect()
                except:
                    pass  # Ignora errori nella disconnessione

            self.shortcuts.clear()
            logging.info("Scorciatoie da tastiera pulite")

        except Exception as e:
            logging.error(f"Errore nella pulizia delle scorciatoie: {e}")


# Funzioni helper per l'uso diretto
def setup_default_shortcuts(parent_window):
    """Configura le scorciatoie di default per una finestra."""
    return KeyboardShortcutsManager(parent_window)


def create_shortcut(parent, key_sequence, callback, name=None):
    """Crea una singola scorciatoia da tastiera."""
    try:
        shortcut = QShortcut(QKeySequence(key_sequence), parent)
        shortcut.activated.connect(callback)

        if name:
            logging.info(f"Scorciatoia '{name}' creata: {key_sequence}")

        return shortcut

    except Exception as e:
        logging.error(f"Errore nella creazione della scorciatoia: {e}")
        return None