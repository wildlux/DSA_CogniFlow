
''''
Cartella principale/
└─── assistente_dsa/
    ├── __init__.py
    ├── main_app.py
    ├── ollama_manager.py
    ├── speech_recognition_manager.py
    ├── tts_manager.py
    ├── visual_background.py
    ├── setup_generici/
    │   └── settings.json
    ├── Audio/ (file audio generati)
    ├── opencv_recognizer.py
    ├── vosk_model_manager
    └── media_pipe_recognizer.py ( to implement )

'''
#print ("ciao")

