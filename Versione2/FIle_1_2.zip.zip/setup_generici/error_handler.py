# error_handler.py

import logging
import traceback
from typing import Any, Callable, Optional, Dict, List
from functools import wraps

class ErrorHandler:
    """
    Gestore centralizzato degli errori per l'applicazione.

    Questa classe fornisce:
    - Logging strutturato degli errori
    - Validazione input
    - Gestione sicura delle eccezioni
    - Decoratori per la gestione degli errori
    """

    def __init__(self, logger_name: str = "ErrorHandler"):
        """
        Inizializza il gestore degli errori.

        Args:
            logger_name (str): Nome del logger da utilizzare
        """
        self.logger = logging.getLogger(logger_name)
        self.setup_logger()

    def setup_logger(self):
        """Configura il logger per la gestione degli errori."""
        if not self.logger.handlers:
            handler = logging.StreamHandler()
            formatter = logging.Formatter(
                '%(asctime)s - %(name)s - %(levelname)s - %(message)s'
            )
            handler.setFormatter(formatter)
            self.logger.addHandler(handler)
            self.logger.setLevel(logging.INFO)

    @staticmethod
    def safe_call(func: Callable, *args, **kwargs) -> tuple[bool, Any]:
        """
        Chiama una funzione in modo sicuro.

        Args:
            func (Callable): Funzione da chiamare
            *args: Argomenti posizionali
            **kwargs: Argomenti nominati

        Returns:
            tuple[bool, Any]: (successo, risultato)
        """
        try:
            result = func(*args, **kwargs)
            return True, result
        except Exception as e:
            return False, e

    def log_error(self, error: Exception, context: str = "", level: int = logging.ERROR):
        """
        Logga un errore con contesto.

        Args:
            error (Exception): L'errore da loggare
            context (str): Contesto in cui si è verificato l'errore
            level (int): Livello di logging
        """
        error_msg = f"Errore in {context}: {str(error)}"
        if context:
            error_msg = f"[{context}] {error_msg}"

        self.logger.log(level, error_msg)
        self.logger.log(level, f"Traceback: {traceback.format_exc()}")

    def validate_input(self, value: Any, expected_type: type,
                      min_val: Optional[Any] = None,
                      max_val: Optional[Any] = None,
                      allowed_values: Optional[List[Any]] = None) -> tuple[bool, Any]:
        """
        Valida un input secondo i parametri specificati.

        Args:
            value (Any): Valore da validare
            expected_type (type): Tipo atteso
            min_val (Optional[Any]): Valore minimo (per numeri)
            max_val (Optional[Any]): Valore massimo (per numeri)
            allowed_values (Optional[List[Any]]): Lista di valori ammessi

        Returns:
            tuple[bool, Any]: (valido, valore_convertito_o_errore)
        """
        try:
            # Controllo del tipo
            if not isinstance(value, expected_type):
                try:
                    # Prova a convertire il tipo
                    if expected_type == bool:
                        value = str(value).lower() in ('true', '1', 'yes', 'on')
                    elif expected_type in (int, float):
                        value = expected_type(value)
                    elif expected_type == str:
                        value = str(value)
                    else:
                        return False, f"Impossibile convertire a {expected_type.__name__}"
                except (ValueError, TypeError):
                    return False, f"Tipo non valido. Atteso {expected_type.__name__}"

            # Controllo dei valori ammessi
            if allowed_values is not None and value not in allowed_values:
                return False, f"Valore non ammesso. Valori validi: {allowed_values}"

            # Controllo dei limiti numerici
            if expected_type in (int, float):
                if min_val is not None and value < min_val:
                    return False, f"Valore troppo piccolo. Minimo: {min_val}"
                if max_val is not None and value > max_val:
                    return False, f"Valore troppo grande. Massimo: {max_val}"

            return True, value

        except Exception as e:
            return False, f"Errore nella validazione: {str(e)}"

    def validate_string(self, value: str, min_length: int = 0,
                       max_length: int = 1000,
                       allow_empty: bool = False) -> tuple[bool, str]:
        """
        Valida una stringa.

        Args:
            value (str): Stringa da validare
            min_length (int): Lunghezza minima
            max_length (int): Lunghezza massima
            allow_empty (bool): Permetti stringa vuota

        Returns:
            tuple[bool, str]: (valido, stringa_o_errore)
        """
        if not isinstance(value, str):
            return False, "Il valore deve essere una stringa"

        if not allow_empty and not value.strip():
            return False, "La stringa non può essere vuota"

        if len(value) < min_length:
            return False, f"Stringa troppo corta. Minimo {min_length} caratteri"

        if len(value) > max_length:
            return False, f"Stringa troppo lunga. Massimo {max_length} caratteri"

        return True, value

    def validate_number(self, value: Any, min_val: Optional[float] = None,
                       max_val: Optional[float] = None,
                       number_type: type = float) -> tuple[bool, Any]:
        """
        Valida un numero.

        Args:
            value (Any): Valore da validare
            min_val (Optional[float]): Valore minimo
            max_val (Optional[float]): Valore massimo
            number_type (type): Tipo di numero (int o float)

        Returns:
            tuple[bool, Any]: (valido, numero_o_errore)
        """
        if number_type not in (int, float):
            return False, "Tipo di numero non valido"

        valid, result = self.validate_input(value, number_type, min_val, max_val)
        return valid, result

    def validate_color(self, color: str) -> tuple[bool, str]:
        """
        Valida un colore in formato hex.

        Args:
            color (str): Colore da validare

        Returns:
            tuple[bool, str]: (valido, colore_o_errore)
        """
        if not isinstance(color, str):
            return False, "Il colore deve essere una stringa"

        # Rimuovi il # se presente
        if color.startswith('#'):
            color = color[1:]

        # Controlla se è un hex valido
        if len(color) not in (3, 6):
            return False, "Il colore deve essere in formato #RGB o #RRGGBB"

        try:
            int(color, 16)
            return True, f"#{color}"
        except ValueError:
            return False, "Il colore deve contenere solo caratteri esadecimali"

    def handle_exception(self, exception: Exception, context: str = "",
                        show_user: bool = True) -> str:
        """
        Gestisce un'eccezione in modo centralizzato.

        Args:
            exception (Exception): L'eccezione da gestire
            context (str): Contesto in cui si è verificata
            show_user (bool): Se mostrare l'errore all'utente

        Returns:
            str: Messaggio di errore formattato
        """
        error_msg = f"Errore in {context}: {str(exception)}" if context else str(exception)

        # Logga l'errore
        self.log_error(exception, context)

        # Restituisci un messaggio user-friendly
        if show_user:
            return self.get_user_friendly_message(exception)
        else:
            return error_msg

    def get_user_friendly_message(self, exception: Exception) -> str:
        """
        Converte un'eccezione in un messaggio user-friendly.

        Args:
            exception (Exception): L'eccezione da convertire

        Returns:
            str: Messaggio user-friendly
        """
        error_type = type(exception).__name__

        user_messages = {
            'FileNotFoundError': "File non trovato. Verifica il percorso del file.",
            'PermissionError': "Permesso negato. Verifica i permessi di accesso.",
            'ConnectionError': "Errore di connessione. Verifica la connessione internet.",
            'TimeoutError': "Timeout. L'operazione ha impiegato troppo tempo.",
            'ValueError': "Valore non valido. Verifica i dati inseriti.",
            'TypeError': "Tipo di dato non valido. Verifica il formato dei dati.",
            'ImportError': "Modulo non trovato. Verifica che tutte le dipendenze siano installate.",
            'OSError': "Errore del sistema operativo. Verifica le risorse disponibili.",
        }

        return user_messages.get(error_type, f"Si è verificato un errore: {str(exception)}")

# Decoratori per la gestione degli errori

def safe_operation(error_handler: Optional[ErrorHandler] = None,
                  context: str = "",
                  default_return: Any = None):
    """
    Decoratore per operazioni sicure.

    Args:
        error_handler (Optional[ErrorHandler]): Gestore degli errori
        context (str): Contesto dell'operazione
        default_return (Any): Valore di default da restituire in caso di errore
    """
    def decorator(func: Callable) -> Callable:
        @wraps(func)
        def wrapper(*args, **kwargs):
            try:
                return func(*args, **kwargs)
            except Exception as e:
                if error_handler:
                    error_handler.handle_exception(e, context or func.__name__)
                else:
                    print(f"Errore in {context or func.__name__}: {e}")
                return default_return
        return wrapper
    return decorator

def validate_input(error_handler: Optional[ErrorHandler] = None,
                  validation_rules: Optional[Dict] = None):
    """
    Decoratore per validare gli input delle funzioni.

    Args:
        error_handler (Optional[ErrorHandler]): Gestore degli errori
        validation_rules (Optional[Dict]): Regole di validazione per i parametri
    """
    def decorator(func: Callable) -> Callable:
        @wraps(func)
        def wrapper(*args, **kwargs):
            # Se non ci sono regole di validazione, esegui normalmente
            if not validation_rules:
                return func(*args, **kwargs)

            # Valida gli argomenti posizionali
            import inspect
            sig = inspect.signature(func)
            param_names = list(sig.parameters.keys())[1:]  # Salta 'self'

            for i, (arg, param_name) in enumerate(zip(args[1:], param_names)):
                if param_name in validation_rules:
                    rule = validation_rules[param_name]
                    valid, result = error_handler.validate_input(arg, **rule) if error_handler else (True, arg)
                    if not valid:
                        raise ValueError(f"Validazione fallita per {param_name}: {result}")
                    args = list(args)
                    args[i + 1] = result

            # Valida gli argomenti nominati
            for param_name, value in kwargs.items():
                if param_name in validation_rules:
                    rule = validation_rules[param_name]
                    valid, result = error_handler.validate_input(value, **rule) if error_handler else (True, value)
                    if not valid:
                        raise ValueError(f"Validazione fallita per {param_name}: {result}")
                    kwargs[param_name] = result

            return func(*args, **kwargs)
        return wrapper
    return decorator