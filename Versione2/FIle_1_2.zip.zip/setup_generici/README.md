# Setup Generici - Configurazioni e Setup

Questa cartella contiene script di setup, configurazioni generali e utilità per l'applicazione DSA.

## File contenuti:

- `fix_dependencies.py` - Script automatico per risolvere le dipendenze mancanti
- `config_manager.py` - Gestione centralizzata delle configurazioni
- `constants.py` - Costanti globali dell'applicazione
- `settings.json` - File di configurazione utente

## Funzionalità:

- Installazione automatica delle dipendenze mancanti
- Gestione centralizzata delle impostazioni
- Definizione di tutte le costanti dell'applicazione
- Configurazione utente persistente

## Utilizzo:

```python
# Eseguire il fix delle dipendenze
python setup_generici/fix_dependencies.py

# Caricare le costanti
from setup_generici.constants import WINDOW_DEFAULT_WIDTH, DEFAULT_FONT_SIZE

# Gestire le configurazioni
from setup_generici.config_manager import ConfigManager
config = ConfigManager()
```