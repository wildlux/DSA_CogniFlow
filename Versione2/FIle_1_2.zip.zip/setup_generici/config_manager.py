# config_manager.py

import json
import os
from typing import Dict, Any, Optional, Union

class ConfigManager:
    """
    Gestore centralizzato delle configurazioni dell'applicazione.

    Questa classe fornisce un'interfaccia unificata per:
    - Caricamento e salvataggio delle configurazioni
    - Validazione dei valori
    - Valori di default sicuri
    - Gestione degli errori
    """

    # Valori di default per tutte le configurazioni
    DEFAULT_CONFIG = {
    # Video e rilevamento
    'face_recognition': False,
    'hand_recognition': True,
    'gesture_recognition': True,
    'facial_expression': True,
    'timeout': 500,
    'drag_threshold': 6.0,
    'silence_timeout': 3.0,

    # Accelerazione GPU
    'gpu_acceleration': True,
    'gpu_backend': 'auto',  # 'auto', 'cuda', 'rocm', 'cpu'
    'gpu_memory_limit': 0.8,  # 80% della memoria GPU
    'gpu_filters_enabled': True,
    'gpu_face_detection': True,
    'gpu_hand_detection': True,

        # AI e modelli
        'ollama_model': 'llama3.2:latest',
        'ai_trigger': '++++',

        # Sintesi vocale
        'tts_engine': 'gTTS',
        'tts_voice_or_lang': 'Italiano (it)',
        'tts_gender': 'Femminile',
        'tts_speed': 1.0,
        'tts_pitch': 1.0,

        # Riconoscimento vocale
        'vosk_model': 'vosk-model-it-0.22',
        'stt_engine': 'SpeechRecognition',

        # Interfaccia utente
        'add_btn_color': '#4a90e2',
        'ai_btn_color': '#4a90e2',
        'voice_btn_color': '#4a90e2',
        'hands_btn_color': '#4a90e2',
        'face_btn_color': '#4a90e2',
        'clean_btn_color': '#4a90e2',
        'options_btn_color': '#4a90e2',
        'log_btn_color': '#4a90e2',
        'gestures_btn_color': '#4a90e2',
        'expressions_btn_color': '#4a90e2',

        # Font
        'main_font_family': 'Arial',
        'main_font_size': 12,
        'pensierini_font_family': 'Arial',
        'pensierini_font_size': 10,
        'workspace_font_family': 'Arial',
        'workspace_font_size': 11,
    }

    # Tipi di dati attesi per la validazione
    CONFIG_TYPES = {
        'face_recognition': bool,
        'hand_recognition': bool,
        'gesture_recognition': bool,
        'facial_expression': bool,
        'timeout': int,
        'drag_threshold': float,
        'silence_timeout': float,
        'ollama_model': str,
        'ai_trigger': str,
        'tts_engine': str,
        'tts_voice_or_lang': str,
        'tts_gender': str,
        'tts_speed': float,
        'tts_pitch': float,
        'vosk_model': str,
        'stt_engine': str,
        'add_btn_color': str,
        'ai_btn_color': str,
        'voice_btn_color': str,
        'hands_btn_color': str,
        'face_btn_color': str,
        'clean_btn_color': str,
        'options_btn_color': str,
        'log_btn_color': str,
        'gestures_btn_color': str,
        'expressions_btn_color': str,
    'main_font_family': str,
    'main_font_size': int,
    'pensierini_font_family': str,
    'pensierini_font_size': int,
    'workspace_font_family': str,
    'workspace_font_size': int,

    # Accelerazione GPU
    'gpu_acceleration': bool,
    'gpu_backend': str,
    'gpu_memory_limit': float,
    'gpu_filters_enabled': bool,
    'gpu_face_detection': bool,
    'gpu_hand_detection': bool,
    }

    def __init__(self, config_file: str = "settings.json"):
        """
        Inizializza il gestore delle configurazioni.

        Args:
            config_file (str): Percorso del file di configurazione
        """
        self.config_file = config_file
        self.config = {}
        self.load_config()

    def load_config(self) -> bool:
        """
        Carica la configurazione dal file.

        Returns:
            bool: True se il caricamento è riuscito
        """
        try:
            if os.path.exists(self.config_file):
                with open(self.config_file, 'r', encoding='utf-8') as f:
                    loaded_config = json.load(f)
                    # Valida e unisce con i default
                    self.config = self._validate_and_merge(loaded_config)
                    return True
            else:
                # Usa i valori di default se il file non esiste
                self.config = self.DEFAULT_CONFIG.copy()
                return True
        except Exception as e:
            print(f"Errore nel caricamento della configurazione: {e}")
            self.config = self.DEFAULT_CONFIG.copy()
            return False

    def save_config(self) -> bool:
        """
        Salva la configurazione nel file.

        Returns:
            bool: True se il salvataggio è riuscito
        """
        try:
            with open(self.config_file, 'w', encoding='utf-8') as f:
                json.dump(self.config, f, indent=4, ensure_ascii=False)
            return True
        except Exception as e:
            print(f"Errore nel salvataggio della configurazione: {e}")
            return False

    def get(self, key: str, default: Any = None) -> Any:
        """
        Ottiene un valore di configurazione.

        Args:
            key (str): Chiave della configurazione
            default (Any): Valore di default se la chiave non esiste

        Returns:
            Any: Il valore della configurazione
        """
        return self.config.get(key, default)

    def set(self, key: str, value: Any) -> bool:
        """
        Imposta un valore di configurazione.

        Args:
            key (str): Chiave della configurazione
            value (Any): Nuovo valore

        Returns:
            bool: True se l'impostazione è valida e riuscita
        """
        if key not in self.CONFIG_TYPES:
            print(f"Chiave di configurazione non valida: {key}")
            return False

        expected_type = self.CONFIG_TYPES[key]
        if not isinstance(value, expected_type):
            try:
                # Prova a convertire il tipo
                if expected_type == bool:
                    value = str(value).lower() in ('true', '1', 'yes', 'on')
                elif expected_type in (int, float):
                    value = expected_type(value)
                elif expected_type == str:
                    value = str(value)
            except (ValueError, TypeError):
                print(f"Impossibile convertire {value} nel tipo {expected_type.__name__}")
                return False

        self.config[key] = value
        return True

    def get_all(self) -> Dict[str, Any]:
        """
        Ottiene tutte le configurazioni.

        Returns:
            Dict[str, Any]: Dizionario con tutte le configurazioni
        """
        return self.config.copy()

    def reset_to_defaults(self):
        """Resetta tutte le configurazioni ai valori di default."""
        self.config = self.DEFAULT_CONFIG.copy()

    def update_from_dict(self, config_dict: Dict[str, Any]) -> bool:
        """
        Aggiorna la configurazione da un dizionario.

        Args:
            config_dict (Dict[str, Any]): Dizionario con le nuove configurazioni

        Returns:
            bool: True se l'aggiornamento è riuscito
        """
        success = True
        for key, value in config_dict.items():
            if not self.set(key, value):
                success = False
        return success

    def _validate_and_merge(self, loaded_config: Dict[str, Any]) -> Dict[str, Any]:
        """
        Valida e unisce la configurazione caricata con i valori di default.

        Args:
            loaded_config (Dict[str, Any]): Configurazione caricata dal file

        Returns:
            Dict[str, Any]: Configurazione validata e completa
        """
        result = self.DEFAULT_CONFIG.copy()

        for key, value in loaded_config.items():
            if key in self.CONFIG_TYPES:
                expected_type = self.CONFIG_TYPES[key]
                try:
                    if isinstance(value, expected_type):
                        result[key] = value
                    else:
                        # Prova a convertire
                        if expected_type == bool:
                            result[key] = str(value).lower() in ('true', '1', 'yes', 'on')
                        elif expected_type in (int, float):
                            result[key] = expected_type(value)
                        elif expected_type == str:
                            result[key] = str(value)
                        else:
                            print(f"Mantengo default per {key}: tipo non valido")
                except (ValueError, TypeError):
                    print(f"Mantengo default per {key}: conversione fallita")
            else:
                print(f"Chiave sconosciuta ignorata: {key}")

        return result

    def get_video_settings(self) -> Dict[str, Any]:
        """
        Ottiene le impostazioni relative al video e al rilevamento.

        Returns:
            Dict[str, Any]: Impostazioni video
        """
        video_keys = [
            'face_recognition', 'hand_recognition', 'gesture_recognition',
            'facial_expression', 'timeout', 'drag_threshold', 'silence_timeout'
        ]
        return {key: self.config[key] for key in video_keys}

    def get_ai_settings(self) -> Dict[str, Any]:
        """
        Ottiene le impostazioni relative all'AI.

        Returns:
            Dict[str, Any]: Impostazioni AI
        """
        ai_keys = ['ollama_model', 'ai_trigger']
        return {key: self.config[key] for key in ai_keys}

    def get_tts_settings(self) -> Dict[str, Any]:
        """
        Ottiene le impostazioni relative alla sintesi vocale.

        Returns:
            Dict[str, Any]: Impostazioni TTS
        """
        tts_keys = [
            'tts_engine', 'tts_voice_or_lang', 'tts_gender',
            'tts_speed', 'tts_pitch'
        ]
        return {key: self.config[key] for key in tts_keys}

    def get_ui_settings(self) -> Dict[str, Any]:
        """
        Ottiene le impostazioni relative all'interfaccia utente.

        Returns:
            Dict[str, Any]: Impostazioni UI
        """
        ui_keys = [
            'add_btn_color', 'ai_btn_color', 'voice_btn_color',
            'hands_btn_color', 'face_btn_color', 'clean_btn_color',
            'options_btn_color', 'log_btn_color', 'gestures_btn_color',
            'expressions_btn_color'
        ]
        return {key: self.config[key] for key in ui_keys}

    def get_font_settings(self) -> Dict[str, Any]:
        """
        Ottiene le impostazioni relative ai font.

        Returns:
            Dict[str, Any]: Impostazioni font
        """
        font_keys = [
            'main_font_family', 'main_font_size',
            'pensierini_font_family', 'pensierini_font_size',
            'workspace_font_family', 'workspace_font_size'
        ]
        return {key: self.config[key] for key in font_keys}

    def get_gpu_settings(self) -> Dict[str, Any]:
        """
        Ottiene le impostazioni relative all'accelerazione GPU.

        Returns:
            Dict[str, Any]: Impostazioni GPU
        """
        gpu_keys = [
            'gpu_acceleration', 'gpu_backend', 'gpu_memory_limit',
            'gpu_filters_enabled', 'gpu_face_detection', 'gpu_hand_detection'
        ]
        return {key: self.config[key] for key in gpu_keys}