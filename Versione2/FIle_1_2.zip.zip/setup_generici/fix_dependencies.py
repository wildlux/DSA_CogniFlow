#!/usr/bin/env python3
"""
Script per risolvere automaticamente le dipendenze mancanti
e sistemare gli errori critici nell'applicazione DSA
"""

import os
import sys
import subprocess
import importlib.util

def check_python_version():
    """Controlla la versione di Python."""
    print(f"🐍 Python version: {sys.version}")
    if sys.version_info < (3, 8):
        print("❌ Python 3.8+ richiesto")
        return False
    return True

def install_package(package_name, pip_name=None):
    """Installa un pacchetto Python."""
    if pip_name is None:
        pip_name = package_name

    try:
        print(f"📦 Installazione {package_name}...")
        subprocess.check_call([
            sys.executable, "-m", "pip", "install",
            pip_name, "--break-system-packages"
        ])
        print(f"✅ {package_name} installato con successo")
        return True
    except subprocess.CalledProcessError as e:
        print(f"❌ Errore nell'installazione di {package_name}: {e}")
        return False

def check_and_install_dependencies():
    """Controlla e installa le dipendenze necessarie."""
    dependencies = [
        ("PyQt6", "PyQt6"),
        ("opencv-python", "opencv-python"),
        ("numpy", "numpy"),
        ("speech_recognition", "SpeechRecognition"),
        ("pyttsx3", "pyttsx3"),
        ("gTTS", "gTTS"),
        ("requests", "requests"),
        ("simpleaudio", "simpleaudio"),
        ("vosk", "vosk"),
        ("mediapipe", "mediapipe"),
        ("pillow", "Pillow"),
    ]

    missing_deps = []

    for package_name, pip_name in dependencies:
        try:
            if package_name == "opencv-python":
                import cv2
            elif package_name == "speech_recognition":
                import speech_recognition
            elif package_name == "pyttsx3":
                import pyttsx3
            elif package_name == "gTTS":
                import gtts
            elif package_name == "simpleaudio":
                import simpleaudio
            elif package_name == "vosk":
                import vosk
            elif package_name == "mediapipe":
                import mediapipe
            elif package_name == "pillow":
                import PIL
            else:
                __import__(package_name.lower())

            print(f"✅ {package_name} già installato")
        except ImportError:
            print(f"❌ {package_name} mancante")
            missing_deps.append((package_name, pip_name))

    # Installa le dipendenze mancanti
    if missing_deps:
        print(f"\n📦 Installazione di {len(missing_deps)} dipendenze mancanti...")
        for package_name, pip_name in missing_deps:
            if not install_package(package_name, pip_name):
                print(f"⚠️  Impossibile installare {package_name}, potrebbe causare problemi")

    return len(missing_deps) == 0

def create_missing_files():
    """Crea i file mancanti per gli import."""
    files_to_create = [
        ("safe_qt_wrapper.py", """# ===========================================
# SAFE QT WRAPPER - GESTIONE SICURA DELLE OPERAZIONI QT
# ===========================================

class SafeQtWrapper:
    \"\"\"Wrapper sicuro per operazioni Qt che potrebbero fallire.\"\"\"

    @staticmethod
    def safe_getattr(obj, attr, default=None):
        \"\"\"Ottiene un attributo in modo sicuro.\"\"\"
        if obj is None:
            return default
        try:
            return getattr(obj, attr, default)
        except Exception:
            return default

    @staticmethod
    def safe_call(obj, method_name, *args, **kwargs):
        \"\"\"Chiama un metodo in modo sicuro.\"\"\"
        if obj is None:
            return None
        try:
            method = getattr(obj, method_name, None)
            if method and callable(method):
                return method(*args, **kwargs)
        except Exception:
            pass
        return None
"""),
        ("draggable_text_widget.py", """# ===========================================
# WIDGET TESTO TRASCINABILE - COMPONENTE UI INTERATTIVO
# ===========================================

import logging
from PyQt6.QtCore import Qt, QMimeData
from PyQt6.QtGui import QDrag
from PyQt6.QtWidgets import QFrame, QHBoxLayout, QLabel, QPushButton, QVBoxLayout, QMessageBox, QInputDialog

class DraggableTextWidget(QFrame):
    \"\"\"Widget di testo che può essere trascinato e rilasciato.\"\"\"

    def __init__(self, text, settings, parent=None):
        super().__init__(parent)

        # Configurazione dell'aspetto visivo del widget
        self.setFrameShape(QFrame.Shape.StyledPanel)
        self.setFrameShadow(QFrame.Shadow.Raised)
        self.setMinimumHeight(60)

        # Stile CSS per l'aspetto moderno e professionale
        self.setStyleSheet(\"\"\"
            QFrame {
                background: rgba(255, 255, 255, 0.7);
                border-radius: 15px;
                margin: 5px;
                color: black;
            }
            QPushButton {
                background-color: rgba(0, 0, 0, 0.2);
                border: 1px solid rgba(0, 0, 0, 0.3);
                border-radius: 12px;
                padding: 5px 10px;
                color: white;
                font-weight: bold;
            }
        \"\"\")

        self.settings = settings
        self.original_text = text

        layout = QHBoxLayout(self)
        self.text_label = QLabel(text)
        self.text_label.setStyleSheet("font-weight: bold; font-size: 12px;")
        self.text_label.setWordWrap(True)

        layout.addWidget(self.text_label, 1)

        button_layout = QVBoxLayout()
        self.read_button = QPushButton("🔊")
        self.read_button.setFixedSize(25, 25)
        self.read_button.setToolTip("Leggi testo")

        self.delete_button = QPushButton("❌")
        self.delete_button.setFixedSize(25, 25)
        self.delete_button.setToolTip("Elimina")

        button_layout.addWidget(self.read_button)
        button_layout.addWidget(self.delete_button)
        layout.addLayout(button_layout)

        self.setAcceptDrops(True)

    def mousePressEvent(self, a0):
        \"\"\"Gestisce l'evento di pressione del mouse.\"\"\"
        if a0 and a0.button() == Qt.MouseButton.LeftButton:
            self.start_pos = a0.pos()
        super().mousePressEvent(a0)

    def mouseMoveEvent(self, a0):
        \"\"\"Gestisce il movimento del mouse.\"\"\"
        if (a0 and hasattr(a0, 'buttons') and hasattr(a0, 'pos') and
            hasattr(self, 'start_pos') and self.start_pos is not None and self.text_label):

            try:
                if a0.buttons() == Qt.MouseButton.LeftButton:
                    current_pos = a0.pos()
                    if current_pos is not None:
                        distance = (current_pos - self.start_pos).manhattanLength()
                        if distance > 10:  # DRAG_DISTANCE_THRESHOLD
                            drag = QDrag(self)
                            mime = QMimeData()
                            mime.setText(self.text_label.text())
                            drag.setMimeData(mime)
                            drag.setPixmap(self.grab())
                            drag.exec(Qt.DropAction.CopyAction)
            except Exception as e:
                logging.error(f"Errore nel mouseMoveEvent: {e}")
        else:
            if hasattr(self, 'start_pos'):
                self.start_pos = None
        super().mouseMoveEvent(a0)
""")
    ]

    for filename, content in files_to_create:
        filepath = os.path.join(os.path.dirname(__file__), filename)
        if not os.path.exists(filepath):
            print(f"📝 Creazione {filename}...")
            with open(filepath, 'w', encoding='utf-8') as f:
                f.write(content)
            print(f"✅ {filename} creato")
        else:
            print(f"✅ {filename} già esistente")

def fix_critical_errors():
    """Sistema gli errori critici nel codice."""
    print("\n🔧 Correzione errori critici...")

    # File da controllare
    files_to_check = [
        "main_app_refactored.py",
        "constants.py",
        "safe_qt_wrapper.py",
        "draggable_text_widget.py"
    ]

    for filename in files_to_check:
        filepath = os.path.join(os.path.dirname(__file__), filename)
        if os.path.exists(filepath):
            print(f"🔍 Controllo {filename}...")

            # Controlla se il file può essere importato
            try:
                spec = importlib.util.spec_from_file_location(filename.replace('.py', ''), filepath)
                if spec and spec.loader:
                    module = importlib.util.module_from_spec(spec)
                    spec.loader.exec_module(module)
                    print(f"✅ {filename} può essere importato")
                else:
                    print(f"❌ {filename} non può essere caricato")
            except Exception as e:
                print(f"⚠️  {filename} ha errori: {e}")

def main():
    """Funzione principale."""
    print("🚀 DSA Dependency Fixer")
    print("=" * 50)

    # Controlla Python
    if not check_python_version():
        return

    # Crea file mancanti
    create_missing_files()

    # Controlla e installa dipendenze
    all_deps_ok = check_and_install_dependencies()

    # Sistema errori critici
    fix_critical_errors()

    print("\n" + "=" * 50)
    if all_deps_ok:
        print("✅ Tutte le dipendenze sono installate!")
        print("✅ File mancanti creati!")
        print("🎉 Il sistema è pronto per l'uso!")
    else:
        print("⚠️  Alcune dipendenze potrebbero non essere installate")
        print("📝 Controlla l'output sopra per i dettagli")

    print("\n💡 Prova a eseguire: python main_app_refactored.py")

if __name__ == "__main__":
    main()