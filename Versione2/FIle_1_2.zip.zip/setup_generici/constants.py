# constants.py - Costanti e impostazioni di default per l'applicazione

# Impostazioni di default dell'applicazione
DEFAULT_SETTINGS = {
    'theme': 'Chiaro',
    'main_font_family': 'Arial',
    'main_font_size': 12,
    'pensierini_font_family': 'Arial',
    'pensierini_font_size': 10,
    'hand_detection_system': 'Auto (Migliore)',
    'face_detection_system': 'Auto (Migliore)',
    'gesture_system': 'Auto (Migliore)',
    'hand_confidence': 50,
    'face_confidence': 50,
    'show_hand_landmarks': True,
    'show_expressions': True,
    'detect_glasses': True,
    'gesture_timeout': 3,
    'gesture_sensitivity': 5,
    'gpu_system': 'Auto (Migliore)',
    'gpu_memory_limit': 80,
    'gpu_filters': True,
    'interface_language': 'Italiano',
    'tts_language': 'it-IT',
    'tts_engine': 'pyttsx3',
    'tts_speed': 1.0,
    'tts_pitch': 1.0,
    'ai_trigger': '++++',
    'cpu_monitoring_enabled': True,
    'cpu_threshold_percent': 95.0,
    'cpu_high_duration_seconds': 30,
    'cpu_check_interval_seconds': 5,
    'cpu_signal_type': 'SIGTERM',
    'temperature_monitoring_enabled': True,
    'temperature_threshold_celsius': 80.0,
    'temperature_high_duration_seconds': 60,
    'temperature_critical_threshold': 90.0,
    'hand_detection': True,
    'face_detection': True,
    'selected_ai_model': 'gemma:2b'
}

# Costanti dell'applicazione
WINDOW_WIDTH = 1200
WINDOW_HEIGHT = 800
CONFIG_DIALOG_WIDTH = 1000
CONFIG_DIALOG_HEIGHT = 700
WIDGET_MIN_HEIGHT = 60
DEFAULT_FONT_SIZE = 12
DEFAULT_PENSIERINI_FONT_SIZE = 10

# File di configurazione
SETTINGS_FILE = "setup_generici/settings.json"
LOG_FILE = "log/app.log"