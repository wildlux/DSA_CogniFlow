# ===========================================
# WIDGET TESTO TRASCINABILE - COMPONENTE UI INTERATTIVO
# ===========================================

import logging
import re
from PyQt6.QtCore import Qt, QMimeData
from PyQt6.QtGui import QDrag
from PyQt6.QtWidgets import QFrame, QHBoxLayout, QLabel, QPushButton, QVBoxLayout, QMessageBox, QInputDialog

# Import local modules
from TTS_To_Text.tts_manager import TTSThread, VOCI_DI_SISTEMA

# Constants (defined locally to avoid import issues)
WIDGET_MIN_HEIGHT = 60
BUTTON_DEFAULT_SIZE = (25, 25)
DEFAULT_FONT_SIZE = 12
DEFAULT_TTS_SPEED = 1.0
DEFAULT_TTS_PITCH = 1.0
DRAG_DISTANCE_THRESHOLD = 10

WIDGET_STYLE_SHEET = """
    QFrame {
        background: rgba(255, 255, 255, 0.7);
        border-radius: 15px;
        margin: 5px;
        color: black;
    }
    QPushButton {
        background-color: rgba(0, 0, 0, 0.2);
        border: 1px solid rgba(0, 0, 0, 0.3);
        border-radius: 12px;
        padding: 5px 10px;
        color: white;
        font-weight: bold;
    }
    QPushButton:hover {
        background-color: rgba(0, 0, 0, 0.3);
    }
    QLabel {
        color: black;
    }
"""


class DraggableTextWidget(QFrame):
    """
    Widget di testo che può essere trascinato e rilasciato.

    Questa classe rappresenta i "pensierini" dell'interfaccia:
    - Rettangoli di testo colorati che contengono pensieri/idee
    - Possono essere trascinati nella colonna A
    - Possono essere trascinati nell'area di lavoro centrale
    - Supportano sintesi vocale del contenuto
    - Hanno un design moderno con angoli arrotondati
    """

    def __init__(self, text, settings, parent=None):
        """
        Inizializza il widget di testo trascinabile.

        Args:
            text (str): Il testo da visualizzare nel widget
            settings (dict): Impostazioni dell'applicazione
            parent (QWidget): Widget genitore
        """
        super().__init__(parent)

        # Configurazione dell'aspetto visivo del widget
        self.setFrameShape(QFrame.Shape.StyledPanel)
        self.setFrameShadow(QFrame.Shadow.Raised)
        self.setMinimumHeight(WIDGET_MIN_HEIGHT)

        # Stile CSS per l'aspetto moderno e professionale
        self.setStyleSheet(WIDGET_STYLE_SHEET)

        self.tts_thread = None
        self.is_reading = False
        self.settings = settings
        self.original_text = text

        layout = QHBoxLayout(self)
        self.text_label = QLabel(text)
        self.text_label.setStyleSheet(f"font-weight: bold; font-size: {DEFAULT_FONT_SIZE}px;")
        self.text_label.setWordWrap(True)
        self.text_label.setContextMenuPolicy(Qt.ContextMenuPolicy.CustomContextMenu)
        self.text_label.customContextMenuRequested.connect(self.show_context_menu)

        layout.addWidget(self.text_label, 1)

        button_layout = QVBoxLayout()
        self.read_button = QPushButton("🔊")
        self.read_button.setFixedSize(*BUTTON_DEFAULT_SIZE)
        self.read_button.setToolTip("Leggi testo")
        self.read_button.clicked.connect(self.toggle_read_text)

        self.delete_button = QPushButton("❌")
        self.delete_button.setFixedSize(*BUTTON_DEFAULT_SIZE)
        self.delete_button.setToolTip("Elimina")
        self.delete_button.clicked.connect(self.delete_self)

        button_layout.addWidget(self.read_button)
        button_layout.addWidget(self.delete_button)
        layout.addLayout(button_layout)

        self.setAcceptDrops(True)
        self.start_pos = None

    def show_context_menu(self, pos):
        """Mostra il menu contestuale per il widget."""
        from PyQt6.QtWidgets import QMenu

        context_menu = QMenu(self)
        edit_action = context_menu.addAction("Modifica Testo")
        action = context_menu.exec(self.mapToGlobal(pos))
        if action == edit_action:
            new_text, ok = QInputDialog.getMultiLineText(
                self, "Modifica Testo", "Modifica il contenuto del widget:",
                self.text_label.text()
            )
            if ok:
                self.text_label.setText(new_text)

    def mousePressEvent(self, a0):
        """Gestisce l'evento di pressione del mouse per iniziare il trascinamento."""
        if a0 and a0.button() == Qt.MouseButton.LeftButton:
            self.start_pos = a0.pos()
        super().mousePressEvent(a0)

    def mouseMoveEvent(self, a0):
        """Gestisce il movimento del mouse per il trascinamento."""
        if (a0 and hasattr(a0, 'buttons') and hasattr(a0, 'pos') and
                self.start_pos is not None and self.text_label):
            try:
                if a0.buttons() == Qt.MouseButton.LeftButton:
                    current_pos = a0.pos()
                    if current_pos is not None:
                        distance = (current_pos - self.start_pos).manhattanLength()
                        if distance > DRAG_DISTANCE_THRESHOLD:
                            drag = QDrag(self)
                            mime = QMimeData()
                            mime.setText(self.text_label.text())
                            drag.setMimeData(mime)
                            drag.setPixmap(self.grab())
                            drag.exec(Qt.DropAction.CopyAction)
            except Exception as e:
                logging.error(f"Errore nel mouseMoveEvent: {e}")
        else:
            # Reset start_pos se ci sono problemi
            self.start_pos = None
        super().mouseMoveEvent(a0)

    def toggle_read_text(self):
        """Avvia o ferma la lettura del testo usando il thread."""
        if not self.is_reading:
            self.start_reading()
        else:
            self.stop_reading()

    def start_reading(self):
        """Avvia il thread di lettura vocale."""
        if self.tts_thread and self.tts_thread.isRunning():
            return

        self.is_reading = True
        self.read_button.setText("⏹️")
        self.read_button.setStyleSheet("background-color: #e74c3c; color: white;")

        selected_engine = self.settings.get('tts_engine', 'pyttsx3')
        voice_or_lang_combo_text = self.settings.get('tts_voice_or_lang', 'it-IT')
        speed = self.settings.get('tts_speed', DEFAULT_TTS_SPEED)
        pitch = self.settings.get('tts_pitch', DEFAULT_TTS_PITCH)

        # Estrai l'ID della voce o il codice lingua in base al motore TTS
        voice_or_lang = ''
        if selected_engine == 'pyttsx3':
            # Cerca l'ID della voce basandosi sul nome selezionato
            selected_voice_info = next(
                (voice for voice in VOCI_DI_SISTEMA if voice['name'] == voice_or_lang_combo_text),
                None
            )
            voice_or_lang = selected_voice_info['id'] if selected_voice_info else 'fallback'
        elif selected_engine == 'gTTS':
            lang_code_match = re.search(r'\(([^)]+)\)', voice_or_lang_combo_text)
            voice_or_lang = lang_code_match.group(1) if lang_code_match else 'it'

        self.tts_thread = TTSThread(self.text_label.text(), selected_engine, voice_or_lang, speed, pitch)
        self.tts_thread.started_reading.connect(self.on_reading_started)
        self.tts_thread.finished_reading.connect(self.on_reading_finished)
        self.tts_thread.error_occurred.connect(self.on_reading_error)
        self.tts_thread.start()

    def stop_reading(self):
        """Ferma il thread di lettura vocale."""
        if self.tts_thread and self.tts_thread.isRunning():
            self.tts_thread.stop()
        self.is_reading = False
        self.read_button.setText("🔊")
        self.read_button.setStyleSheet("")
        logging.info("Lettura testo interrotta.")

    def on_reading_started(self):
        """Gestisce l'inizio della lettura."""
        logging.info("Lettura del testo iniziata.")

    def on_reading_finished(self):
        """Gestisce la fine della lettura."""
        self.is_reading = False
        self.read_button.setText("🔊")
        self.read_button.setStyleSheet("")
        logging.info("Lettura testo completata.")
        self.tts_thread = None

    def on_reading_error(self, message):
        """Gestisce gli errori durante la lettura."""
        self.is_reading = False
        self.read_button.setText("🔊")
        self.read_button.setStyleSheet("")
        logging.error(f"Errore durante la lettura vocale: {message}")
        self.tts_thread = None
        QMessageBox.critical(self, "Errore TTS", message)

    def delete_self(self):
        """Rimuove il widget dall'interfaccia."""
        if self.is_reading:
            self.stop_reading()
        self.setParent(None)
        self.deleteLater()
