# UI/interface_options.py
# Gestione delle opzioni e configurazioni dell'interfaccia utente

import os
import json
import logging
from typing import Dict, Any, Optional
from PyQt6.QtCore import QObject, pyqtSignal
from PyQt6.QtGui import QColor, QFont

class InterfaceOptions(QObject):
    """Gestore centralizzato delle opzioni dell'interfaccia utente."""

    # Segnali per notificare i cambiamenti
    themeChanged = pyqtSignal(str)
    fontChanged = pyqtSignal(QFont)
    colorChanged = pyqtSignal(str, QColor)
    layoutChanged = pyqtSignal(dict)

    def __init__(self):
        super().__init__()
        self.logger = logging.getLogger("InterfaceOptions")
        self.config_file = os.path.join(os.path.dirname(__file__), "interface_config.json")

        # Configurazioni di default
        self.default_options = {
            # Tema e aspetto
            "theme": "light",
            "accent_color": "#4a90e2",
            "background_color": "#f8f9fa",
            "text_color": "#2c3e50",
            "border_color": "#e1e8ed",

            # Font
            "main_font_family": "Arial",
            "main_font_size": 12,
            "pensierini_font_family": "Arial",
            "pensierini_font_size": 10,
            "monospace_font_family": "Consolas",

            # Layout
            "window_width": 1400,
            "window_height": 800,
            "sidebar_width": 300,
            "toolbar_height": 50,
            "statusbar_height": 30,

            # Comportamento
            "auto_save": True,
            "auto_save_interval": 300,  # secondi
            "show_toolbar": True,
            "show_statusbar": True,
            "show_sidebar": True,
            "confirm_on_exit": True,

            # Accessibilità
            "high_contrast": False,
            "large_text": False,
            "screen_reader": False,
            "keyboard_navigation": True,

            # Notifiche
            "show_notifications": True,
            "notification_duration": 3000,  # millisecondi
            "sound_effects": True,
            "animation_enabled": True,

            # Editor
            "word_wrap": True,
            "line_numbers": False,
            "syntax_highlighting": True,
            "auto_complete": True,
            "spell_check": True,

            # TTS Integration
            "tts_enabled": True,
            "tts_auto_read": False,
            "tts_speed": 1.0,
            "tts_pitch": 1.0,
            "tts_voice": "it-IT",

            # AI Integration
            "ai_enabled": True,
            "ai_auto_suggest": False,
            "ai_model": "llama2:7b",
            "ai_temperature": 0.7,

            # File management
            "default_save_format": "txt",
            "backup_enabled": True,
            "backup_interval": 3600,  # secondi
            "max_backups": 10
        }

        # Carica le opzioni
        self.options = self.load_options()

    def load_options(self) -> Dict[str, Any]:
        """Carica le opzioni dal file di configurazione."""
        try:
            if os.path.exists(self.config_file):
                with open(self.config_file, 'r', encoding='utf-8') as f:
                    loaded = json.load(f)
                    # Unisci con i default
                    self.default_options.update(loaded)
                    return self.default_options.copy()
            return self.default_options.copy()
        except Exception as e:
            self.logger.error(f"Errore nel caricamento delle opzioni: {e}")
            return self.default_options.copy()

    def save_options(self) -> bool:
        """Salva le opzioni correnti nel file."""
        try:
            with open(self.config_file, 'w', encoding='utf-8') as f:
                json.dump(self.options, f, indent=2, ensure_ascii=False)
            self.logger.info("Opzioni interfaccia salvate")
            return True
        except Exception as e:
            self.logger.error(f"Errore nel salvataggio delle opzioni: {e}")
            return False

    def get_option(self, key: str, default: Any = None) -> Any:
        """Ottiene il valore di un'opzione."""
        return self.options.get(key, default)

    def set_option(self, key: str, value: Any) -> bool:
        """Imposta il valore di un'opzione."""
        try:
            old_value = self.options.get(key)

            # Validazione del valore
            if not self._validate_option(key, value):
                self.logger.warning(f"Valore non valido per {key}: {value}")
                return False

            self.options[key] = value

            # Notifica i cambiamenti specifici
            if key == "theme":
                self.themeChanged.emit(value)
            elif key in ["main_font_family", "main_font_size", "pensierini_font_family", "pensierini_font_size"]:
                self._notify_font_change()
            elif key in ["accent_color", "background_color", "text_color", "border_color"]:
                self.colorChanged.emit(key, QColor(value))
            elif key in ["window_width", "window_height", "sidebar_width", "toolbar_height"]:
                self.layoutChanged.emit({key: value})

            # Salva automaticamente
            self.save_options()

            self.logger.info(f"Opzione aggiornata: {key} = {value}")
            return True

        except Exception as e:
            self.logger.error(f"Errore nell'impostazione dell'opzione {key}: {e}")
            return False

    def _validate_option(self, key: str, value: Any) -> bool:
        """Valida il valore di un'opzione."""
        validations = {
            "theme": lambda v: v in ["light", "dark", "high_contrast"],
            "accent_color": lambda v: self._is_valid_color(v),
            "background_color": lambda v: self._is_valid_color(v),
            "text_color": lambda v: self._is_valid_color(v),
            "border_color": lambda v: self._is_valid_color(v),
            "main_font_size": lambda v: isinstance(v, (int, float)) and 8 <= v <= 72,
            "pensierini_font_size": lambda v: isinstance(v, (int, float)) and 8 <= v <= 72,
            "window_width": lambda v: isinstance(v, int) and 800 <= v <= 3840,
            "window_height": lambda v: isinstance(v, int) and 600 <= v <= 2160,
            "tts_speed": lambda v: isinstance(v, (int, float)) and 0.1 <= v <= 3.0,
            "tts_pitch": lambda v: isinstance(v, (int, float)) and 0.1 <= v <= 3.0,
            "ai_temperature": lambda v: isinstance(v, (int, float)) and 0.0 <= v <= 2.0,
        }

        validator = validations.get(key)
        if validator:
            return validator(value)
        return True  # Se non c'è validazione specifica, accetta

    def _is_valid_color(self, color: str) -> bool:
        """Verifica se una stringa è un colore valido."""
        try:
            QColor(color)
            return True
        except:
            return False

    def _notify_font_change(self):
        """Notifica un cambiamento di font."""
        main_font = QFont(
            self.options.get("main_font_family", "Arial"),
            int(self.options.get("main_font_size", 12))
        )
        self.fontChanged.emit(main_font)

    def reset_to_defaults(self) -> bool:
        """Ripristina tutte le opzioni ai valori di default."""
        try:
            self.options = self.default_options.copy()
            self.save_options()
            self.logger.info("Opzioni ripristinate ai valori di default")
            return True
        except Exception as e:
            self.logger.error(f"Errore nel ripristino delle opzioni: {e}")
            return False

    def export_options(self, file_path: str) -> bool:
        """Esporta le opzioni in un file."""
        try:
            with open(file_path, 'w', encoding='utf-8') as f:
                json.dump(self.options, f, indent=2, ensure_ascii=False)
            self.logger.info(f"Opzioni esportate in: {file_path}")
            return True
        except Exception as e:
            self.logger.error(f"Errore nell'esportazione delle opzioni: {e}")
            return False

    def import_options(self, file_path: str) -> bool:
        """Importa le opzioni da un file."""
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                imported = json.load(f)

            # Valida le opzioni importate
            for key, value in imported.items():
                if not self._validate_option(key, value):
                    self.logger.warning(f"Opzione non valida ignorata: {key} = {value}")
                    continue
                self.options[key] = value

            self.save_options()
            self.logger.info(f"Opzioni importate da: {file_path}")
            return True
        except Exception as e:
            self.logger.error(f"Errore nell'importazione delle opzioni: {e}")
            return False

    def get_theme_colors(self) -> Dict[str, QColor]:
        """Ottiene i colori del tema corrente."""
        return {
            "accent": QColor(self.options.get("accent_color", "#4a90e2")),
            "background": QColor(self.options.get("background_color", "#f8f9fa")),
            "text": QColor(self.options.get("text_color", "#2c3e50")),
            "border": QColor(self.options.get("border_color", "#e1e8ed"))
        }

    def get_font_settings(self) -> Dict[str, QFont]:
        """Ottiene le impostazioni dei font."""
        return {
            "main": QFont(
                self.options.get("main_font_family", "Arial"),
                int(self.options.get("main_font_size", 12))
            ),
            "pensierini": QFont(
                self.options.get("pensierini_font_family", "Arial"),
                int(self.options.get("pensierini_font_size", 10))
            ),
            "monospace": QFont(
                self.options.get("monospace_font_family", "Consolas"),
                int(self.options.get("main_font_size", 12))
            )
        }

    def get_layout_settings(self) -> Dict[str, int]:
        """Ottiene le impostazioni di layout."""
        return {
            "window_width": self.options.get("window_width", 1400),
            "window_height": self.options.get("window_height", 800),
            "sidebar_width": self.options.get("sidebar_width", 300),
            "toolbar_height": self.options.get("toolbar_height", 50),
            "statusbar_height": self.options.get("statusbar_height", 30)
        }

    def get_accessibility_settings(self) -> Dict[str, bool]:
        """Ottiene le impostazioni di accessibilità."""
        return {
            "high_contrast": self.options.get("high_contrast", False),
            "large_text": self.options.get("large_text", False),
            "screen_reader": self.options.get("screen_reader", False),
            "keyboard_navigation": self.options.get("keyboard_navigation", True)
        }

    def get_tts_settings(self) -> Dict[str, Any]:
        """Ottiene le impostazioni TTS."""
        return {
            "enabled": self.options.get("tts_enabled", True),
            "auto_read": self.options.get("tts_auto_read", False),
            "speed": self.options.get("tts_speed", 1.0),
            "pitch": self.options.get("tts_pitch", 1.0),
            "voice": self.options.get("tts_voice", "it-IT")
        }

    def get_ai_settings(self) -> Dict[str, Any]:
        """Ottiene le impostazioni AI."""
        return {
            "enabled": self.options.get("ai_enabled", True),
            "auto_suggest": self.options.get("ai_auto_suggest", False),
            "model": self.options.get("ai_model", "llama2:7b"),
            "temperature": self.options.get("ai_temperature", 0.7)
        }

    def apply_theme(self, widget) -> None:
        """Applica il tema corrente a un widget."""
        colors = self.get_theme_colors()

        if self.options.get("theme") == "dark":
            # Tema scuro
            widget.setStyleSheet(f"""
                QWidget {{
                    background-color: #2b2b2b;
                    color: #ffffff;
                }}
                QPushButton {{
                    background-color: {colors['accent'].name()};
                    color: white;
                    border: none;
                    padding: 8px 16px;
                    border-radius: 4px;
                }}
                QPushButton:hover {{
                    background-color: {colors['accent'].lighter(110).name()};
                }}
                QTextEdit, QLineEdit {{
                    background-color: #3b3b3b;
                    color: #ffffff;
                    border: 1px solid {colors['border'].name()};
                }}
            """)
        else:
            # Tema chiaro
            widget.setStyleSheet(f"""
                QWidget {{
                    background-color: {colors['background'].name()};
                    color: {colors['text'].name()};
                }}
                QPushButton {{
                    background-color: {colors['accent'].name()};
                    color: white;
                    border: none;
                    padding: 8px 16px;
                    border-radius: 4px;
                }}
                QPushButton:hover {{
                    background-color: {colors['accent'].lighter(110).name()};
                }}
                QTextEdit, QLineEdit {{
                    background-color: white;
                    color: {colors['text'].name()};
                    border: 1px solid {colors['border'].name()};
                }}
            """)

# Istanza globale
interface_options = InterfaceOptions()

# Funzioni di utilità per retrocompatibilità
def get_option(key: str, default: Any = None) -> Any:
    """Funzione di compatibilità per ottenere un'opzione."""
    return interface_options.get_option(key, default)

def set_option(key: str, value: Any) -> bool:
    """Funzione di compatibilità per impostare un'opzione."""
    return interface_options.set_option(key, value)

def get_theme_colors() -> Dict[str, QColor]:
    """Funzione di compatibilità per ottenere i colori del tema."""
    return interface_options.get_theme_colors()

def get_font_settings() -> Dict[str, QFont]:
    """Funzione di compatibilità per ottenere le impostazioni dei font."""
    return interface_options.get_font_settings()

if __name__ == "__main__":
    print("🔧 Test Interface Options...")

    # Test opzioni
    print(f"Tema corrente: {interface_options.get_option('theme')}")
    print(f"Colore accent: {interface_options.get_option('accent_color')}")

    # Test colori
    colors = interface_options.get_theme_colors()
    print(f"Colore accent: {colors['accent'].name()}")

    # Test font
    fonts = interface_options.get_font_settings()
    print(f"Font principale: {fonts['main'].family()} {fonts['main'].pointSize()}")

    print("✅ Test completato")