# 🎨 UI - Interfaccia Utente dell'Assistente DSA

Questa cartella contiene tutti i componenti dell'interfaccia utente dell'Assistente DSA, organizzata in modo modulare e scalabile.

## 📁 Struttura della Cartella

```
UI/
├── __init__.py                    # Inizializzazione del modulo UI
├── README.md                     # Questa documentazione
├── main_interface.qml            # Interfaccia QML principale
├── main_interface_manager.py     # Gestore dell'interfaccia principale
├── interface_options.py          # Gestione delle opzioni dell'interfaccia
└── draggable_text_widget.py      # Widget di testo trascinabile
```

## 🏗️ Componenti Principali

### 1. **main_interface.qml**
**Interfaccia QML principale** per l'Assistente DSA.

**Caratteristiche:**
- Layout a tre colonne (controlli, editor, pensierini)
- Menu principale con tutte le funzionalità
- Barra degli strumenti con pulsanti rapidi
- Supporto per temi e personalizzazioni
- Design responsive e moderno

**Funzionalità:**
- Editor di testo principale
- Gestione dei pensierini
- Controlli TTS e AI
- Area di log integrata
- Menu contestuali

### 2. **main_interface_manager.py**
**Gestore dell'interfaccia principale** che coordina tutti i componenti UI.

**Responsabilità:**
- Inizializzazione dell'interfaccia
- Gestione dei temi e stili
- Coordinamento tra componenti
- Gestione degli eventi dell'interfaccia
- Auto-save e backup

**Caratteristiche:**
- Segnali per comunicazione con il resto dell'app
- Gestione centralizzata dello stato
- Timer per auto-save
- Integrazione con le opzioni dell'interfaccia

### 3. **interface_options.py**
**Sistema di gestione delle opzioni dell'interfaccia utente**.

**Funzionalità:**
- Configurazione temi (chiaro/scuro/con alto contrasto)
- Impostazioni font e tipografia
- Configurazione layout e dimensioni
- Opzioni di accessibilità
- Impostazioni TTS e AI integrate
- Salvataggio automatico delle preferenze

**Opzioni Disponibili:**
```python
# Tema e aspetto
"theme": "light" | "dark" | "high_contrast"
"accent_color": "#4a90e2"
"background_color": "#f8f9fa"

# Font
"main_font_family": "Arial"
"main_font_size": 12
"pensierini_font_size": 10

# Layout
"window_width": 1400
"window_height": 800
"sidebar_width": 300

# Accessibilità
"high_contrast": False
"large_text": False
"screen_reader": False

# TTS Integration
"tts_enabled": True
"tts_speed": 1.0
"tts_voice": "it-IT"

# AI Integration
"ai_enabled": True
"ai_model": "llama2:7b"
```

### 4. **draggable_text_widget.py**
**Widget di testo trascinabile** per i pensierini.

**Caratteristiche:**
- Testo trascinabile tra aree
- Supporto drag & drop
- Pulsanti per TTS e cancellazione
- Stili personalizzabili
- Integrazione con il sistema TTS

## 🎨 Sistema di Temi

### Temi Disponibili:
- **Light**: Tema chiaro predefinito
- **Dark**: Tema scuro per uso notturno
- **High Contrast**: Tema ad alto contrasto per accessibilità

### Personalizzazione Colori:
```python
# Colori configurabili
primaryColor: "#4a90e2"      # Colore principale
secondaryColor: "#f39c12"    # Colore secondario
successColor: "#27ae60"      # Colore successo
errorColor: "#e74c3c"        # Colore errore
backgroundColor: "#f8f9fa"   # Sfondo
textColor: "#2c3e50"         # Testo
```

## 🔧 Utilizzo

### Inizializzazione:
```python
from UI.main_interface_manager import create_interface_manager
from UI.interface_options import interface_options

# Crea il gestore dell'interfaccia
interface_manager = create_interface_manager(main_window)

# Applica le impostazioni
interface_manager._apply_interface_settings()
```

### Gestione Opzioni:
```python
from UI.interface_options import interface_options

# Ottieni un'opzione
theme = interface_options.get_option("theme")

# Imposta un'opzione
interface_options.set_option("theme", "dark")

# Ottieni i colori del tema
colors = interface_options.get_theme_colors()
```

### Gestione Testo:
```python
# Aggiungi un pensierino
widget = interface_manager.add_text_widget("Nuovo pensierino")

# Ottieni tutto il testo
all_text = interface_manager.get_all_text()

# Richiedi sintesi vocale
interface_manager.request_tts("Testo da sintetizzare")
```

## 🎯 Integrazione con il Sistema

### Segnali Disponibili:
```python
# Segnali del MainInterfaceManager
interface_manager.interfaceReady.connect(on_interface_ready)
interface_manager.textChanged.connect(on_text_changed)
interface_manager.ttsRequested.connect(on_tts_requested)
interface_manager.aiRequested.connect(on_ai_requested)
interface_manager.saveRequested.connect(on_save_requested)
```

### Integrazione TTS:
```python
# Il sistema TTS si integra automaticamente
tts_settings = interface_options.get_tts_settings()
# {'enabled': True, 'speed': 1.0, 'voice': 'it-IT', ...}
```

### Integrazione AI:
```python
# Il sistema AI si integra automaticamente
ai_settings = interface_options.get_ai_settings()
# {'enabled': True, 'model': 'llama2:7b', 'temperature': 0.7, ...}
```

## 📊 Caratteristiche Avanzate

### Auto-Save:
- Salvataggio automatico configurabile
- Timer personalizzabile
- Backup automatico

### Accessibilità:
- Supporto screen reader
- Navigazione tastiera
- Testo grande
- Alto contrasto

### Responsive Design:
- Layout adattivo
- Ridimensionamento dinamico
- Supporto schermi diversi

## 🔄 Estensibilità

### Aggiungere Nuovi Componenti:
1. Creare il componente nella cartella UI
2. Integrarlo nel `main_interface_manager.py`
3. Aggiungere le opzioni in `interface_options.py`
4. Documentare nel README

### Personalizzare l'Interfaccia:
1. Modificare `interface_options.py` per nuove opzioni
2. Aggiornare `main_interface_manager.py` per applicare le modifiche
3. Personalizzare `main_interface.qml` per il layout

## 🐛 Risoluzione Problemi

### Tema non applicato:
```python
# Forza l'applicazione del tema
interface_manager._apply_theme("light")
```

### Font non applicato:
```python
# Ricarica le impostazioni dei font
fonts = interface_options.get_font_settings()
interface_manager._apply_fonts(fonts)
```

### Layout non corretto:
```python
# Reimposta il layout
layout_settings = interface_options.get_layout_settings()
interface_manager._apply_layout(layout_settings)
```

## 📝 Note di Sviluppo

- **QML vs PyQt**: L'interfaccia è principalmente PyQt con supporto QML per future espansioni
- **Modularità**: Ogni componente è indipendente e riutilizzabile
- **Configurabilità**: Tutto è personalizzabile attraverso le opzioni
- **Performance**: Design ottimizzato per velocità e responsività

## 🎨 Prossimi Sviluppi

- [ ] Supporto completo QML/QtQuick
- [ ] Più temi personalizzabili
- [ ] Interfaccia touch-friendly
- [ ] Modalità presentazione
- [ ] Temi dinamici basati sull'ora

---

**L'interfaccia utente è ora completamente modulare e pronta per future espansioni!** 🎨✨