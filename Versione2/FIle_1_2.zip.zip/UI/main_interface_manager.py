# UI/main_interface_manager.py
# Gestore principale dell'interfaccia utente

import os
import logging
from typing import Dict, Any, Optional, List
from PyQt6.QtCore import QObject, pyqtSignal, QTimer
from PyQt6.QtWidgets import QApplication, QMainWindow, QWidget, QVBoxLayout, QHBoxLayout
from PyQt6.QtGui import QFont, QColor

from .interface_options import interface_options
from .draggable_text_widget import DraggableTextWidget

class MainInterfaceManager(QObject):
    """Gestore principale dell'interfaccia utente dell'Assistente DSA."""

    # Segnali per la comunicazione con il resto dell'applicazione
    interfaceReady = pyqtSignal()
    textChanged = pyqtSignal(str)
    ttsRequested = pyqtSignal(str, dict)
    aiRequested = pyqtSignal(str, dict)
    saveRequested = pyqtSignal()
    loadRequested = pyqtSignal(str)

    def __init__(self, main_window: QMainWindow):
        super().__init__()
        self.main_window = main_window
        self.logger = logging.getLogger("MainInterfaceManager")

        # Componenti dell'interfaccia
        self.text_widgets: List[DraggableTextWidget] = []
        self.current_text = ""
        self.is_initialized = False

        # Timer per auto-save
        self.auto_save_timer = QTimer()
        self.auto_save_timer.timeout.connect(self._auto_save)

        # Inizializza l'interfaccia
        self._initialize_interface()

    def _initialize_interface(self):
        """Inizializza l'interfaccia utente."""
        try:
            self.logger.info("Inizializzazione interfaccia principale...")

            # Applica le impostazioni dell'interfaccia
            self._apply_interface_settings()

            # Configura i segnali
            self._setup_signals()

            # Avvia l'auto-save se abilitato
            if interface_options.get_option("auto_save", True):
                interval = interface_options.get_option("auto_save_interval", 300) * 1000
                self.auto_save_timer.start(interval)

            self.is_initialized = True
            self.interfaceReady.emit()
            self.logger.info("Interfaccia principale inizializzata con successo")

        except Exception as e:
            self.logger.error(f"Errore nell'inizializzazione dell'interfaccia: {e}")

    def _apply_interface_settings(self):
        """Applica le impostazioni dell'interfaccia."""
        try:
            # Applica il tema
            theme = interface_options.get_option("theme", "light")
            self._apply_theme(theme)

            # Applica i font
            fonts = interface_options.get_font_settings()
            self._apply_fonts(fonts)

            # Configura il layout
            layout_settings = interface_options.get_layout_settings()
            self._apply_layout(layout_settings)

            # Configura l'accessibilità
            accessibility = interface_options.get_accessibility_settings()
            self._apply_accessibility(accessibility)

        except Exception as e:
            self.logger.error(f"Errore nell'applicazione delle impostazioni: {e}")

    def _apply_theme(self, theme: str):
        """Applica il tema all'interfaccia."""
        try:
            colors = interface_options.get_theme_colors()

            if theme == "dark":
                stylesheet = f"""
                    QMainWindow, QWidget {{
                        background-color: #2b2b2b;
                        color: #ffffff;
                    }}
                    QPushButton {{
                        background-color: {colors['accent'].name()};
                        color: white;
                        border: none;
                        padding: 8px 16px;
                        border-radius: 4px;
                    }}
                    QPushButton:hover {{
                        background-color: {colors['accent'].lighter(110).name()};
                    }}
                    QTextEdit, QLineEdit {{
                        background-color: #3b3b3b;
                        color: #ffffff;
                        border: 1px solid {colors['border'].name()};
                        border-radius: 4px;
                    }}
                    QGroupBox {{
                        font-weight: bold;
                        border: 2px solid {colors['accent'].name()};
                        border-radius: 8px;
                        margin-top: 1ex;
                    }}
                    QGroupBox::title {{
                        subcontrol-origin: margin;
                        left: 10px;
                        padding: 0 10px 0 10px;
                        color: {colors['accent'].name()};
                    }}
                """
            else:  # Light theme
                stylesheet = f"""
                    QMainWindow, QWidget {{
                        background-color: {colors['background'].name()};
                        color: {colors['text'].name()};
                    }}
                    QPushButton {{
                        background-color: {colors['accent'].name()};
                        color: white;
                        border: none;
                        padding: 8px 16px;
                        border-radius: 4px;
                    }}
                    QPushButton:hover {{
                        background-color: {colors['accent'].lighter(110).name()};
                    }}
                    QTextEdit, QLineEdit {{
                        background-color: white;
                        color: {colors['text'].name()};
                        border: 1px solid {colors['border'].name()};
                        border-radius: 4px;
                    }}
                    QGroupBox {{
                        font-weight: bold;
                        border: 2px solid {colors['accent'].name()};
                        border-radius: 8px;
                        margin-top: 1ex;
                    }}
                    QGroupBox::title {{
                        subcontrol-origin: margin;
                        left: 10px;
                        padding: 0 10px 0 10px;
                        color: {colors['accent'].name()};
                    }}
                """

            self.main_window.setStyleSheet(stylesheet)
            self.logger.info(f"Tema applicato: {theme}")

        except Exception as e:
            self.logger.error(f"Errore nell'applicazione del tema: {e}")

    def _apply_fonts(self, fonts: Dict[str, QFont]):
        """Applica i font all'interfaccia."""
        try:
            # Applica il font principale
            app = QApplication.instance()
            if app:
                app.setFont(fonts.get('main', QFont("Arial", 12)))

            self.logger.info("Font applicati all'interfaccia")

        except Exception as e:
            self.logger.error(f"Errore nell'applicazione dei font: {e}")

    def _apply_layout(self, layout_settings: Dict[str, int]):
        """Applica le impostazioni di layout."""
        try:
            # Ridimensiona la finestra principale
            width = layout_settings.get('window_width', 1400)
            height = layout_settings.get('window_height', 800)
            self.main_window.resize(width, height)

            self.logger.info(f"Layout applicato: {width}x{height}")

        except Exception as e:
            self.logger.error(f"Errore nell'applicazione del layout: {e}")

    def _apply_accessibility(self, accessibility: Dict[str, bool]):
        """Applica le impostazioni di accessibilità."""
        try:
            if accessibility.get('high_contrast', False):
                # Applica contrasto elevato
                self._apply_high_contrast()

            if accessibility.get('large_text', False):
                # Applica testo grande
                self._apply_large_text()

            self.logger.info("Impostazioni accessibilità applicate")

        except Exception as e:
            self.logger.error(f"Errore nell'applicazione dell'accessibilità: {e}")

    def _apply_high_contrast(self):
        """Applica il tema ad alto contrasto."""
        high_contrast_stylesheet = """
            QWidget {
                background-color: black;
                color: white;
            }
            QPushButton {
                background-color: yellow;
                color: black;
                border: 2px solid white;
                font-weight: bold;
            }
            QTextEdit, QLineEdit {
                background-color: black;
                color: white;
                border: 2px solid white;
            }
        """
        current_stylesheet = self.main_window.styleSheet()
        self.main_window.setStyleSheet(current_stylesheet + high_contrast_stylesheet)

    def _apply_large_text(self):
        """Applica testo di grandi dimensioni."""
        large_font = QFont("Arial", 16, QFont.Weight.Bold)
        app = QApplication.instance()
        if app:
            app.setFont(large_font)

    def _setup_signals(self):
        """Configura i segnali dell'interfaccia."""
        try:
            # Connetti i segnali delle opzioni dell'interfaccia
            interface_options.themeChanged.connect(self._on_theme_changed)
            interface_options.fontChanged.connect(self._on_font_changed)
            interface_options.colorChanged.connect(self._on_color_changed)
            interface_options.layoutChanged.connect(self._on_layout_changed)

            self.logger.info("Segnali dell'interfaccia configurati")

        except Exception as e:
            self.logger.error(f"Errore nella configurazione dei segnali: {e}")

    def _on_theme_changed(self, theme: str):
        """Gestisce il cambio di tema."""
        self._apply_theme(theme)

    def _on_font_changed(self, font: QFont):
        """Gestisce il cambio di font."""
        app = QApplication.instance()
        if app:
            app.setFont(font)

    def _on_color_changed(self, color_name: str, color: QColor):
        """Gestisce il cambio di colore."""
        self.logger.info(f"Colore cambiato: {color_name} = {color.name()}")

    def _on_layout_changed(self, layout_data: dict):
        """Gestisce il cambio di layout."""
        for key, value in layout_data.items():
            if key == "window_width" or key == "window_height":
                current_size = self.main_window.size()
                if key == "window_width":
                    self.main_window.resize(value, current_size.height())
                else:
                    self.main_window.resize(current_size.width(), value)

    def add_text_widget(self, text: str) -> DraggableTextWidget:
        """Aggiunge un nuovo widget di testo trascinabile."""
        try:
            if DraggableTextWidget:
                widget = DraggableTextWidget(text, interface_options.options)
                self.text_widgets.append(widget)
                self.logger.info(f"Nuovo widget di testo aggiunto: {text[:50]}...")
                return widget
            else:
                self.logger.error("DraggableTextWidget non disponibile")
                return None
        except Exception as e:
            self.logger.error(f"Errore nell'aggiunta del widget di testo: {e}")
            return None

    def remove_text_widget(self, widget: DraggableTextWidget):
        """Rimuove un widget di testo."""
        try:
            if widget in self.text_widgets:
                self.text_widgets.remove(widget)
                widget.deleteLater()
                self.logger.info("Widget di testo rimosso")
        except Exception as e:
            self.logger.error(f"Errore nella rimozione del widget di testo: {e}")

    def get_all_text(self) -> str:
        """Ottiene tutto il testo dall'interfaccia."""
        try:
            all_text = []

            # Aggiungi il testo principale
            if hasattr(self.main_window, 'work_area_main_text_edit'):
                main_text = self.main_window.work_area_main_text_edit.toPlainText()
                if main_text.strip():
                    all_text.append(f"Testo principale:\n{main_text}")

            # Aggiungi i pensierini
            if self.text_widgets:
                pensierini_text = []
                for i, widget in enumerate(self.text_widgets):
                    if hasattr(widget, 'text_label'):
                        widget_text = widget.text_label.text()
                        if widget_text.strip():
                            pensierini_text.append(f"{i+1}. {widget_text}")

                if pensierini_text:
                    all_text.append(f"\nPensierini:\n" + "\n".join(pensierini_text))

            return "\n\n".join(all_text) if all_text else ""

        except Exception as e:
            self.logger.error(f"Errore nel recupero del testo: {e}")
            return ""

    def set_text(self, text: str, area: str = "main"):
        """Imposta il testo in un'area specifica."""
        try:
            if area == "main" and hasattr(self.main_window, 'work_area_main_text_edit'):
                self.main_window.work_area_main_text_edit.setPlainText(text)
            elif area == "left" and hasattr(self.main_window, 'work_area_left_text_edit'):
                self.main_window.work_area_left_text_edit.setPlainText(text)

            self.logger.info(f"Testo impostato nell'area: {area}")

        except Exception as e:
            self.logger.error(f"Errore nell'impostazione del testo: {e}")

    def clear_all(self):
        """Pulisce tutto il contenuto dell'interfaccia."""
        try:
            # Pulisci il testo principale
            if hasattr(self.main_window, 'work_area_main_text_edit'):
                self.main_window.work_area_main_text_edit.clear()

            if hasattr(self.main_window, 'work_area_left_text_edit'):
                self.main_window.work_area_left_text_edit.clear()

            # Rimuovi tutti i pensierini
            for widget in self.text_widgets[:]:
                self.remove_text_widget(widget)

            self.logger.info("Interfaccia pulita completamente")

        except Exception as e:
            self.logger.error(f"Errore nella pulizia dell'interfaccia: {e}")

    def _auto_save(self):
        """Esegue il salvataggio automatico."""
        try:
            if interface_options.get_option("auto_save", True):
                self.saveRequested.emit()
                self.logger.debug("Auto-save eseguito")
        except Exception as e:
            self.logger.error(f"Errore nell'auto-save: {e}")

    def request_tts(self, text: str = None, options: Dict[str, Any] = None):
        """Richiede la sintesi vocale."""
        try:
            if text is None:
                text = self.get_all_text()

            if not text.strip():
                self.logger.warning("Nessun testo da sintetizzare")
                return

            if options is None:
                options = interface_options.get_tts_settings()

            self.ttsRequested.emit(text, options)
            self.logger.info("Richiesta TTS inviata")

        except Exception as e:
            self.logger.error(f"Errore nella richiesta TTS: {e}")

    def request_ai(self, prompt: str = None, options: Dict[str, Any] = None):
        """Richiede l'assistenza AI."""
        try:
            if prompt is None:
                prompt = self.get_all_text()

            if not prompt.strip():
                self.logger.warning("Nessun prompt per l'AI")
                return

            if options is None:
                options = interface_options.get_ai_settings()

            self.aiRequested.emit(prompt, options)
            self.logger.info("Richiesta AI inviata")

        except Exception as e:
            self.logger.error(f"Errore nella richiesta AI: {e}")

    def get_statistics(self) -> Dict[str, Any]:
        """Ottiene le statistiche dell'interfaccia."""
        try:
            return {
                "text_widgets_count": len(self.text_widgets),
                "main_text_length": len(self.get_all_text()),
                "theme": interface_options.get_option("theme"),
                "auto_save_enabled": interface_options.get_option("auto_save"),
                "tts_enabled": interface_options.get_option("tts_enabled"),
                "ai_enabled": interface_options.get_option("ai_enabled")
            }
        except Exception as e:
            self.logger.error(f"Errore nel recupero delle statistiche: {e}")
            return {}

# Istanza globale (da creare quando disponibile la main window)
interface_manager = None

def create_interface_manager(main_window: QMainWindow) -> MainInterfaceManager:
    """Crea l'istanza del gestore dell'interfaccia."""
    global interface_manager
    interface_manager = MainInterfaceManager(main_window)
    return interface_manager

def get_interface_manager() -> Optional[MainInterfaceManager]:
    """Ottiene l'istanza del gestore dell'interfaccia."""
    return interface_manager

if __name__ == "__main__":
    print("🖥️ Test Main Interface Manager...")

    # Test delle opzioni
    print(f"Tema corrente: {interface_options.get_option('theme')}")
    print(f"Font principale: {interface_options.get_font_settings()['main'].family()}")

    # Test dei colori
    colors = interface_options.get_theme_colors()
    print(f"Colore accent: {colors['accent'].name()}")

    print("✅ Test completato")