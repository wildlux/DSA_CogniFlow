# READING - Gestione della Lettura Vocale

Questo modulo gestisce la lettura vocale dei widget di testo nell'applicazione DSA.

## Funzionalità

### Lettura Vocale
- **Supporto multilingua**: Lettura in italiano, inglese, francese, tedesco, spagnolo
- **Controllo thread**: Gestione sicura dei thread TTS
- **Fallback automatico**: Selezione automatica di voci valide
- **Gestione errori**: Recupero graceful dagli errori TTS

### Integrazione con Widget
- **TextReaderManager**: Classe principale per la gestione della lettura
- **Connessioni automatiche**: Segnali per inizio, fine e errori
- **Aggiornamenti UI**: Modifica automatica dei pulsanti durante la lettura

## Utilizzo

```python
from TTS_to_READING.text_reader import TextReaderManager

# Inizializzazione
text_reader = TextReaderManager(settings, parent=self)

# Lettura di un widget
text_reader.toggle_read_text(text_widget)

# Pulizia risorse
text_reader.cleanup()
```

## Metodi Principali

- `toggle_read_text(widget)`: Avvia/ferma la lettura
- `start_reading(widget)`: Avvia la lettura vocale
- `stop_reading()`: Ferma la lettura vocale
- `cleanup()`: Pulisce le risorse

## Segnali Gestiti

- `started_reading`: Inizio della lettura
- `finished_reading`: Fine della lettura
- `error_occurred`: Errori durante la lettura

## Dipendenze

- **TTS.tts_manager**: Modulo per la sintesi vocale
- **PyQt6**: Per i segnali e l'integrazione UI

Il modulo è progettato per essere indipendente e riutilizzabile in altri contesti.