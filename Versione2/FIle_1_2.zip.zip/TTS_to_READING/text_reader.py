# text_reader.py - Gestione della lettura vocale per i widget di testo

import logging
from PyQt6.QtCore import QObject, pyqtSignal


class TextReaderManager(QObject):
    """Gestore della lettura vocale per i widget di testo."""

    def __init__(self, settings, parent=None):
        super().__init__(parent)
        self.settings = settings
        self.is_reading = False
        self.tts_thread = None

    def toggle_read_text(self, text_widget):
        """Avvia o ferma la lettura del testo usando il thread."""
        if not self.is_reading:
            self.start_reading(text_widget)
        else:
            self.stop_reading()

    def start_reading(self, text_widget):
        """Avvia il thread di lettura vocale."""
        if self.tts_thread and self.tts_thread.isRunning():
            return

        self.is_reading = True
        text_widget.read_button.setText("⏹️")
        text_widget.read_button.setStyleSheet("background-color: #e74c3c; color: white;")

        selected_voice = self.settings.get('tts_voice', 'it-IT')
        # Gestisci la voce in modo sicuro
        if selected_voice == 'Zephyr':
            selected_voice = 'it-IT'  # Fallback a una voce valida

        # Usa direttamente la voce selezionata senza mapping complesso
        # Il sistema TTS dovrebbe gestire direttamente i codici lingua
        # Se non funziona, usa una voce di fallback
        if selected_voice not in ['it-IT', 'en-US', 'en-GB', 'es-ES', 'fr-FR', 'de-DE']:
            selected_voice = 'it-IT'  # Fallback sicuro

        # Import del thread TTS (deve essere importato dove necessario)
        try:
            from TTS_To_Text.tts_manager import TTSThread
            self.tts_thread = TTSThread(text_widget.text_label.text(), selected_voice)
            self.tts_thread.started_reading.connect(lambda: self.on_reading_started(text_widget))
            self.tts_thread.finished_reading.connect(lambda: self.on_reading_finished(text_widget))
            self.tts_thread.error_occurred.connect(lambda msg: self.on_reading_error(text_widget, msg))
            self.tts_thread.start()
        except ImportError as e:
            logging.error(f"Errore nell'importazione TTSThread: {e}")
            self.on_reading_error(text_widget, "Modulo TTS non disponibile")

    def stop_reading(self):
        """Ferma il thread di lettura vocale."""
        if self.tts_thread:
            if self.tts_thread.isRunning():
                self.tts_thread.stop()
                # Attendi che il thread termini completamente
                if not self.tts_thread.wait(5000):  # Timeout di 5 secondi
                    logging.warning("Thread TTS non terminato entro il timeout")
            self.tts_thread = None
        self.is_reading = False
        logging.info("Lettura testo interrotta.")

    def on_reading_started(self, text_widget):
        """Gestisce l'inizio della lettura."""
        logging.info("Lettura del testo iniziata.")
        text_widget.read_button.setText("⏹️")
        text_widget.read_button.setStyleSheet("background-color: #e74c3c; color: white;")

    def on_reading_finished(self, text_widget):
        """Gestisce la fine della lettura."""
        self.is_reading = False
        text_widget.read_button.setText("🔊")
        text_widget.read_button.setStyleSheet("")
        logging.info("Lettura testo completata.")
        # Il thread verrà pulito automaticamente dal garbage collector
        # Non impostare a None qui per evitare problemi di concorrenza

    def on_reading_error(self, text_widget, message):
        """Gestisce gli errori durante la lettura."""
        self.is_reading = False
        text_widget.read_button.setText("🔊")
        text_widget.read_button.setStyleSheet("")
        logging.error(f"Errore durante la lettura vocale: {message}")
        self.tts_thread = None

    def cleanup(self):
        """Pulisce le risorse del gestore di lettura."""
        if self.is_reading:
            self.stop_reading()